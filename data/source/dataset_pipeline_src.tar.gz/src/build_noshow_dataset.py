"""Dataset 3 - appointment non-attendance prediction (Kaggle "Medical Appointment No Shows", real de-identified data).

Independent of the synthetic EHR datasets. The label is APPOINTMENT ATTENDANCE only; it says nothing about whether a
complete clinical follow-up obligation was fulfilled.

Prediction cutoff = the moment the appointment is scheduled (ScheduledDay). Only variables knowable then are features.
  * AppointmentDay is date-only (00:00:00Z) in the source -> waiting time is computed on calendar dates.
  * SMS_received is NOT knowable at scheduling time (reminders are sent later; send time undocumented) -> excluded from the
    primary feature set and exposed only as `sms_received__timing_uncertain`.
  * History features use only earlier appointments whose appointment DATE is strictly before this ScheduledDay's date.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import cfg_path, get_logger, hash_split, load_config, stable_uniform, write_json, write_table

log = get_logger("noshow")

FEATURES = ["age", "gender", "scholarship", "hypertension", "diabetes", "alcoholism", "handicap_level", "neighbourhood",
            "wait_days", "same_day", "scheduled_dow", "scheduled_hour", "appointment_dow", "prior_appointments",
            "prior_noshows", "prior_noshow_rate", "days_since_last_appointment"]
META = ["appointment_id", "patient_key", "scheduled_time_utc", "appointment_date", "split", "split_chrono"]
LABEL = "no_show"


def build(cfg=None):
    cfg = cfg or load_config()
    raw = cfg_path(cfg, "raw") / "noshow" / "KaggleV2-May-2016.csv"
    out = cfg_path(cfg, "processed") / "appointment_noshow"
    df = pd.read_csv(raw)
    n_src = len(df)
    audit = {"source_rows": n_src}
    if cfg["mode"] == "dev":       # representative subset: keep ALL appointments of a hash-selected patient sample
        frac = min(1.0, cfg["dev"]["max_noshow_rows"] / len(df))
        df = df[[stable_uniform(str(int(k)), "noshow_dev_subset") < frac for k in df.PatientId]]
    df = df.rename(columns={"PatientId": "patient_key", "AppointmentID": "appointment_id", "Gender": "gender", "ScheduledDay": "sched",
                            "AppointmentDay": "appt", "Age": "age", "Neighbourhood": "neighbourhood", "Scholarship": "scholarship",
                            "Hipertension": "hypertension", "Diabetes": "diabetes", "Alcoholism": "alcoholism", "Handcap": "handicap_level",
                            "SMS_received": "sms_received__timing_uncertain", "No-show": "no_show_raw"})
    audit["duplicate_rows_excluding_ids"] = int(df.drop(columns=["appointment_id"]).duplicated().sum())
    audit["duplicate_appointment_ids"] = int(df.appointment_id.duplicated().sum())
    df["sched"] = pd.to_datetime(df.sched, utc=True)
    df["appt"] = pd.to_datetime(df.appt, utc=True)
    df["sched_date"] = df.sched.dt.floor("D")
    df["wait_days"] = (df.appt - df.sched_date).dt.days
    audit["appointment_time_of_day_available"] = bool((df.appt.dt.hour != 0).any())
    audit["negative_wait_rows"] = int((df.wait_days < 0).sum())
    audit["negative_age_rows"] = int((df.age < 0).sum())
    audit["age_gt_110_rows"] = int((df.age > 110).sum())
    audit["missing_values"] = {c: int(v) for c, v in df.isna().sum().items() if v}
    audit["handicap_levels"] = {str(k): int(v) for k, v in df.handicap_level.value_counts().items()}
    bad = (df.wait_days < 0) | (df.age < 0)
    audit["dropped_invalid_rows"] = int(bad.sum())
    df = df[~bad].copy()
    df["patient_key"] = df.patient_key.astype("int64").astype(str)
    df[LABEL] = (df.no_show_raw == "Yes").astype(int)
    df["same_day"] = (df.wait_days == 0).astype(int)
    df["scheduled_dow"] = df.sched.dt.dayofweek
    df["scheduled_hour"] = df.sched.dt.hour
    df["appointment_dow"] = df.appt.dt.dayofweek
    df["appointment_date"] = df.appt.dt.strftime("%Y-%m-%d")
    df["scheduled_time_utc"] = df.sched.dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    # ---- history features (strictly earlier appointment dates relative to this scheduling date)
    df = df.sort_values(["patient_key", "appt", "sched", "appointment_id"]).reset_index(drop=True)
    prior_n = np.zeros(len(df), int)
    prior_ns = np.zeros(len(df), int)
    since = np.full(len(df), np.nan)
    for _, idx in df.groupby("patient_key").indices.items():
        if len(idx) == 1:
            continue
        g_appt = df.appt.values[idx]
        g_lab = df[LABEL].values[idx]
        g_sched = df.sched_date.values[idx]
        for j, i in enumerate(idx):
            known = g_appt < g_sched[j]
            if known.any():
                prior_n[i] = int(known.sum())
                prior_ns[i] = int(g_lab[known].sum())
                since[i] = (g_sched[j] - g_appt[known].max()) / np.timedelta64(1, "D")
    df["prior_appointments"] = prior_n
    df["prior_noshows"] = prior_ns
    df["prior_noshow_rate"] = (prior_ns + 0.2) / (prior_n + 1.0)       # smoothed toward the ~0.2 base rate
    df["days_since_last_appointment"] = since
    # ---- splits: patient-grouped (primary) and chronological (secondary)
    fr = cfg["splits"]["noshow_fractions"]
    df["split"] = [hash_split(k, fr, "noshow_patient_split") for k in df.patient_key]
    order = df.appt.rank(method="first", pct=True)
    df["split_chrono"] = np.where(order <= fr["train"], "train", np.where(order <= fr["train"] + fr["validation"], "validation", "test"))
    df = df.drop(columns=["sched", "appt", "sched_date", "no_show_raw"])
    cols = META + FEATURES + ["sms_received__timing_uncertain", LABEL]
    df = df[cols]
    # ---- integrity
    assert df.appointment_id.is_unique
    assert (df.wait_days >= 0).all() and (df.age >= 0).all()
    for sp in ("train", "validation", "test"):
        write_table(df[df.split == sp], out / f"{sp}")
        write_table(df[df.split_chrono == sp], out / f"chrono_{sp}")
    write_table(df, out / "all")
    # ---- subgroup distributions / bias screen
    ab = pd.cut(df.age, [-1, 17, 34, 49, 64, 200], labels=["0-17", "18-34", "35-49", "50-64", "65+"])
    sub = {}
    for name, key in [("gender", df.gender), ("age_band", ab), ("scholarship", df.scholarship), ("handicap_level", df.handicap_level),
                      ("hypertension", df.hypertension), ("diabetes", df.diabetes), ("wait_band", pd.cut(df.wait_days, [-1, 0, 3, 7, 14, 30, 400]).astype(str))]:
        g = df.groupby(key, observed=True)[LABEL].agg(["size", "mean"])
        sub[name] = {str(k): {"n": int(r["size"]), "no_show_rate": round(float(r["mean"]), 4)} for k, r in g.iterrows()}
    nb = df.groupby("neighbourhood")[LABEL].agg(["size", "mean"])
    sub["neighbourhood_summary"] = {
        "n_neighbourhoods": int(len(nb)), "n_with_lt_100_rows": int((nb["size"] < 100).sum()),
        "no_show_rate_min": round(float(nb[nb["size"] >= 100]["mean"].min()), 4), "no_show_rate_max": round(float(nb[nb["size"] >= 100]["mean"].max()), 4)}
    stats = {"audit": audit, "n_rows": int(len(df)), "no_show_rate": round(float(df[LABEL].mean()), 4),
             "by_split_patient_grouped": {k: {"n": int(v["size"]), "no_show_rate": round(float(v["mean"]), 4)} for k, v in df.groupby("split")[LABEL].agg(["size", "mean"]).iterrows()},
             "by_split_chronological": {k: {"n": int(v["size"]), "no_show_rate": round(float(v["mean"]), 4)} for k, v in df.groupby("split_chrono")[LABEL].agg(["size", "mean"]).iterrows()},
             "patients": int(df.patient_key.nunique()),
             "patients_spanning_multiple_splits_patient_grouped": int((df.groupby("patient_key").split.nunique() > 1).sum()),
             "subgroups": sub, "features": FEATURES, "split_strategy": "primary: patient-grouped hash 70/15/15 (column split); secondary: chronological by appointment date (column split_chrono)",
             "cutoff": "ScheduledDay (time the appointment is scheduled)"}
    write_json(stats, out / "noshow_stats.json")
    log.info("no-show: %d rows, no-show rate %.3f, dropped invalid %d", len(df), df[LABEL].mean(), audit["dropped_invalid_rows"])
    return stats


def run(cfg=None):
    return build(cfg)


if __name__ == "__main__":
    run()
