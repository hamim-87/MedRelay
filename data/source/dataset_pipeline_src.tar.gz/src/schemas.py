"""Canonical MedRelay entity schemas (Pydantic) + validation helpers.

Every canonical table is validated row-by-row against these models on a sample and
column-wise (required columns / allowed values) on the full table by `validate_table`.
Identifiers are namespaced by source: sh: (Synthetic Hospital), sy: (Synthea),
mts: (MTS-Dialog), aci: (ACI-Bench), sim: (generated scenario objects).
"""
from __future__ import annotations

from typing import Literal, Optional

import pandas as pd
from pydantic import BaseModel, ConfigDict, Field

Source = Literal["synthetic_hospital", "synthea", "mts_dialog", "aci_bench"]
Split = Literal["train", "validation", "test"]
Category = Literal[
    "appointment_referral", "laboratory_test", "imaging", "procedure", "medication_action",
    "patient_communication", "followup_review", "other_action", "no_action",
]
ACTION_CATEGORIES = [c for c in Category.__args__ if c != "no_action"]  # type: ignore[attr-defined]
ALL_CATEGORIES = list(Category.__args__)  # type: ignore[attr-defined]


class _Row(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Patient(_Row):
    patient_id: str
    source_dataset: Source
    source_patient_id: str
    split: Split
    official_split: Optional[str] = None       # raw split label from the source, if any
    split_origin: Literal["official", "hash_assigned"]
    sex: Optional[str] = None
    age: Optional[float] = None
    race_ethnicity: Optional[str] = None
    is_pseudo_patient: bool = False            # True for document-level pseudo patients (MTS/ACI)


class Encounter(_Row):
    encounter_id: str
    patient_id: str
    source_dataset: Source
    source_encounter_id: str
    event_time_utc: Optional[str] = None       # ISO-8601 UTC
    time_precision: Literal["datetime", "date", "none"]
    time_imputed: bool                         # True if event_time_utc was not in the source
    encounter_type: Optional[str] = None
    department: Optional[str] = None
    chief_complaint: Optional[str] = None
    encounter_order: Optional[int] = None


class Note(_Row):
    note_id: str
    encounter_id: Optional[str] = None
    patient_id: str
    source_dataset: Source
    text_kind: Literal["clinical_note", "dialogue", "section_summary", "visit_note"]
    section: Optional[str] = None              # for section-level notes (MTS)
    text: str
    split: Split
    official_split: Optional[str] = None
    provenance: str


class Obligation(_Row):
    obligation_id: str
    patient_id: str
    encounter_id: Optional[str] = None
    note_id: Optional[str] = None
    source_dataset: str
    category: Category
    description: str
    responsible_role: str
    created_time_utc: str
    due_time_utc: str
    due_time_imputed: bool
    depends_on: list[str] = Field(default_factory=list)
    evidence_text: Optional[str] = None
    evidence_span: Optional[tuple[int, int]] = None
    extraction_confidence: float
    annotation_provenance: str                 # e.g. rule_v1 / structured_order / synthetic_scenario
    label_tier: Literal["gold", "silver", "synthetic"]
    split: Split
    # scenario-layer extras
    step_type: Optional[str] = None
    chain_id: Optional[str] = None
    chain_position: Optional[int] = None
    seed_id: Optional[str] = None
    seed_kind: Optional[str] = None
    created_time_precision: Optional[str] = None


class ClinicalEvent(_Row):
    event_id: str
    patient_id: str
    encounter_id: Optional[str] = None
    obligation_id: Optional[str] = None
    event_type: str
    timestamp_utc: str
    evidence_source: str
    status: str
    provenance: Literal["documented_source", "inferred", "simulated"]
    verification: Optional[Literal["verified", "unverified", "inferred"]] = None
    payload: Optional[str] = None
    source_event_id: Optional[str] = None


class EvidenceLink(_Row):
    obligation_id: str
    event_id: str
    relationship: Literal["COMPLETED_BY", "EVIDENCED_BY", "CONTRADICTS", "REQUIRES_REVIEW", "POSSIBLE_MATCH"]
    match_confidence: float
    verification_state: Literal["verified", "unverified", "inferred", "contradicted"]
    link_time_utc: Optional[str] = None
    provenance: Optional[str] = None


def validate_rows(df: pd.DataFrame, model: type[BaseModel], sample: int = 2000, seed: int = 0) -> list[str]:
    """Validate a sample of rows against the pydantic model. Returns list of error strings."""
    errs: list[str] = []
    s = df if len(df) <= sample else df.sample(sample, random_state=seed)
    for i, rec in enumerate(s.to_dict("records")):
        rec = {k: (None if (not isinstance(v, (list, tuple)) and not hasattr(v, "__len__") and pd.isna(v)) else v) for k, v in rec.items()}
        rec = {k: (v.tolist() if hasattr(v, "tolist") else v) for k, v in rec.items()}
        try:
            model.model_validate(rec)
        except Exception as e:  # noqa: BLE001
            errs.append(f"row {i}: {str(e)[:300]}")
            if len(errs) >= 5:
                break
    return errs
