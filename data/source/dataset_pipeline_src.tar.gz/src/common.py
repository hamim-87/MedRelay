"""Shared helpers: config, paths, hashing, deterministic seeding, logging, IO."""
from __future__ import annotations

import hashlib
import json
import logging
import random
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import yaml

ROOT = Path(__file__).resolve().parent.parent
SPLITS = ("train", "validation", "test")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")


def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    p = Path(path) if path else ROOT / "config.yaml"
    if not p.is_absolute():
        p = ROOT / p
    with open(p) as f:
        return yaml.safe_load(f)


def cfg_path(cfg: dict, key: str) -> Path:
    p = ROOT / cfg["paths"][key]
    p.mkdir(parents=True, exist_ok=True)
    return p


def seed_everything(seed: int) -> np.random.Generator:
    random.seed(seed)
    np.random.seed(seed)
    return np.random.default_rng(seed)


def sha256_file(path: Path, chunk: int = 1 << 20) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while b := f.read(chunk):
            h.update(b)
    return h.hexdigest()


def stable_hash(s: str, salt: str = "") -> int:
    """Process-independent 64-bit hash (Python's hash() is salted per process)."""
    return int(hashlib.sha256((salt + s).encode()).hexdigest()[:16], 16)


def stable_uniform(s: str, salt: str = "") -> float:
    return stable_hash(s, salt) / float(1 << 64)


def hash_split(key: str, fractions: dict[str, float], salt: str) -> str:
    u = stable_uniform(key, salt)
    acc = 0.0
    for name in SPLITS:
        acc += fractions[name]
        if u < acc:
            return name
    return SPLITS[-1]


def write_table(df: pd.DataFrame, path: Path, csv_sample: int | None = 200) -> None:
    """Parquet + (optional) small CSV sample for inspection."""
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(path.with_suffix(".parquet"), index=False)
    if csv_sample:
        df.head(csv_sample).to_csv(path.with_name(path.stem + ".sample.csv"), index=False)


def write_json(obj: Any, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=str, sort_keys=False)


def read_json(path: Path) -> Any:
    with open(path) as f:
        return json.load(f)


def iso_utc(ts: pd.Series) -> pd.Series:
    return pd.to_datetime(ts, utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
