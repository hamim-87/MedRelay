"""Aggregate measured statistics into reports/dataset_statistics.json and render the documentation set
(docs/DATASET_CARD.md, docs/LABEL_DEFINITIONS.md, docs/PROVENANCE.md, annotation guide). Every number comes from the
produced artefacts -- nothing is typed in by hand.
"""
from __future__ import annotations

import json

import pandas as pd

from .common import ROOT, cfg_path, get_logger, load_config, read_json, write_json
from .generate_scenarios import COMPLETION_EVENT, PROFILES
from .schemas import ALL_CATEGORIES

log = get_logger("reports")


def collect(cfg) -> dict:
    interim, proc, rep = cfg_path(cfg, "interim"), cfg_path(cfg, "processed"), cfg_path(cfg, "reports")
    audit = read_json(rep / "source_audit.json")
    pats = pd.read_parquet(interim / "patients.parquet")
    enc = pd.read_parquet(interim / "encounters.parquet")
    notes = pd.read_parquet(interim / "notes.parquet", columns=["note_id", "source_dataset", "text_kind", "split"])
    sc = interim / "scenarios"
    obl = pd.read_parquet(sc / "obligations.parquet")
    gt = pd.read_parquet(sc / "ground_truth.parquet")
    links = pd.read_parquet(sc / "evidence_links.parquet")
    ev = pd.read_parquet(sc / "events.parquet")
    A = {sp: pd.read_parquet(proc / "action_classification" / f"{sp}.parquet") for sp in ("train", "validation", "test")}
    Aall = pd.read_parquet(proc / "action_classification" / "all_with_exclusions.parquet")
    risk = {sp: pd.read_parquet(proc / "followup_risk" / f"features_{sp}.parquet") for sp in ("train", "validation", "test")}
    rstats = read_json(proc / "followup_risk" / "risk_stats.json")
    nstats = read_json(proc / "appointment_noshow" / "noshow_stats.json")
    gstats = read_json(proc / "evidence_graph" / "graph_stats.json")
    sstats = read_json(proc / "event_stream" / "stream_stats.json")
    astats = read_json(interim / "action_stats.json")
    val = read_json(rep / "validation_results.json") if (rep / "validation_results.json").exists() else {}
    base = read_json(rep / "baseline_results.json") if (rep / "baseline_results.json").exists() else {}

    nr = gt[~gt.documented_root]
    sh_a, sy_a = audit["synthetic_hospital"], audit["synthea"]
    raw_counts = {
        "synthetic_hospital": {"patients": sh_a["tables"]["patient_profiles.db:patients"]["rows"], "encounters": sh_a["tables"]["patient_profiles.db:encounters"]["rows"],
                               "notes": sh_a["notes"]["n"], "imaging_orders": sh_a["notes"]["imaging_orders"]},
        "synthea_csv": {"patients": sy_a["tables"]["patients.csv"]["rows"], "encounters": sy_a["tables"]["encounters.csv"]["rows"],
                        "observations": sy_a["tables"]["observations.csv"]["rows"], "medications": sy_a["tables"]["medications.csv"]["rows"],
                        "procedures": sy_a["tables"]["procedures.csv"]["rows"], "careplans": sy_a["tables"]["careplans.csv"]["rows"],
                        "fhir_document_reference_notes": sy_a["notes"]["fhir_document_references"]},
        "mts_dialog": {k: v["rows"] for k, v in audit["mts_dialog"]["files"].items()},
        "aci_bench": {k: v["rows"] for k, v in audit["aci_bench"]["files"].items()},
        "noshow": {"rows": audit["noshow"]["profile"]["rows"]},
    }
    comp_verified = links[(links.relationship == "COMPLETED_BY") & (links.verification_state == "verified")].obligation_id.nunique()
    n_nonroot = len(nr)
    verified_nonroot = nr.obligation_id.isin(links[(links.relationship == "COMPLETED_BY") & (links.verification_state == "verified")].obligation_id).sum()
    depth = {}
    par = dict(zip(obl.obligation_id, obl.depends_on))

    def dp(o):
        if o not in depth:
            depth[o] = 1 + max((dp(p) for p in par[o]), default=0)
        return depth[o]
    dh = pd.Series([dp(o) for o in par]).value_counts().sort_index()
    chain_len = obl.groupby("chain_id").size()
    oi = obl.set_index("obligation_id")
    cross = int(sum(oi.at[o, "chain_id"] != oi.at[p, "chain_id"] for o, ds in par.items() for p in ds))
    rk = pd.concat(risk.values())
    miss = {c: round(float(rk[c].isna().mean()), 4) for c in rk.columns if rk[c].isna().any()}
    st = {
        "mode": cfg["mode"], "seed": cfg["seed"],
        "total_source_records": raw_counts,
        "canonical": {
            "patients": {k: {kk: int(vv) for kk, vv in v.items()} for k, v in pats.groupby(["source_dataset", "split"]).size().unstack(fill_value=0).to_dict("index").items()},
            "encounters": enc.groupby(["source_dataset"]).size().to_dict(), "notes": {f"{a}:{b}": int(n) for (a, b), n in notes.groupby(["source_dataset", "text_kind"]).size().items()},
            "n_patients": int(len(pats)), "n_encounters": int(len(enc)), "n_notes": int(len(notes)),
            "pseudo_patients_(document-level MTS/ACI)": int(pats.is_pseudo_patient.sum())},
        "valid_records_after_cleaning": {"noshow_rows": nstats["n_rows"], "noshow_dropped_invalid": nstats["audit"]["dropped_invalid_rows"],
                                         "action_examples_after_leakage_exclusion": astats["n_after_leakage_exclusion"],
                                         "action_examples_excluded_as_duplicates": astats["n_segments_all"] - astats["n_after_leakage_exclusion"]},
        "action_classification": {
            "counts_by_split": astats["by_split"], "label_counts_by_split": astats["label_counts_by_split"], "label_counts_total": astats["label_counts"],
            "actionable_examples(any non no_action label)": int(sum(int((df.labels.map(lambda l: list(l) != ["no_action"])).sum()) for df in A.values())),
            "positive_fraction_by_source": astats["positive_fraction_by_source"], "tier_counts": astats["tier_counts"], "gold_examples": astats["n_gold"],
            "review_queue_size": astats["n_review_queue"],
            "needs_review_rate": round(float(Aall.needs_review.mean()), 4),
            "actionable_language_share_of_documents (rule-based candidates)": {
                "synthetic_hospital_notes": audit["synthetic_hospital"]["actionable_language"]["share_documents_with_directive_candidate"],
                "mts_summaries": audit["mts_dialog"]["actionable_language_in_section_summaries"]["share_documents_with_directive_candidate"],
                "mts_doctor_turns": audit["mts_dialog"]["actionable_language_in_doctor_turns"]["share_documents_with_directive_candidate"],
                "aci_notes": audit["aci_bench"]["actionable_language_in_notes"]["share_documents_with_directive_candidate"],
                "aci_doctor_turns": audit["aci_bench"]["actionable_language_in_doctor_turns"]["share_documents_with_directive_candidate"]}},
        "obligations": {
            "n_seeds": astats["n_seeds"], "seeds_by_kind": astats["seeds_by_kind"], "n_obligations_generated": int(len(obl)),
            "n_non_documented_root_obligations": int(n_nonroot), "by_category": obl.category.value_counts().to_dict(),
            "outcomes_all": gt.outcome_label.value_counts().to_dict(), "outcomes_excluding_documented_roots": nr.outcome_label.value_counts().to_dict(),
            "simulated_completed": int((nr.outcome_label == "completed").sum()), "simulated_missed(overdue_unresolved)": int((nr.outcome_label == "overdue_unresolved").sum()),
            "simulated_late_completion_within_overdue": int(nr.resolved_late.sum()),
            "pct_with_verified_completion_evidence_excl_roots": round(100 * float(verified_nonroot) / n_nonroot, 2),
            "pct_with_verified_completion_evidence_all": round(100 * float(comp_verified) / len(obl), 2),
            "n_chains": int(obl.chain_id.nunique()), "chain_length_distribution": chain_len.value_counts().sort_index().to_dict(),
            "dependency_depth_distribution": dh.to_dict(), "n_dependency_edges": int(sum(len(v) for v in par.values())), "n_cross_chain_dependency_edges": cross,
            "scenario_profiles(non-root obligations)": nr.scenario_profile.value_counts().to_dict(),
            "events": {"n": int(len(ev)), "by_provenance": ev.provenance.value_counts().to_dict()}},
        "followup_risk": {"rows": rstats["n_rows"], "by_split": rstats["by_split"], "outcome_label_counts": rstats["outcome_label_counts"],
                          "binary_counts": rstats["binary_counts"], "categories": rstats["categories"],
                          "missing_rate_of_features_(NaN by design)": {k: v for k, v in miss.items() if k not in ("outcome_label", "label_binary")},
                          "unknown_label_rate(unverified+censored share)": round(float(rk.outcome_label.isin(["unverified", "censored_or_unknown"]).mean()), 4)},
        "appointment_noshow": {k: nstats[k] for k in ("n_rows", "no_show_rate", "by_split_patient_grouped", "by_split_chronological", "patients", "split_strategy", "cutoff")} | {
            "audit": nstats["audit"]},
        "evidence_graph": gstats, "event_stream": sstats,
        "validation_summary": val.get("summary"), "baselines": {
            "followup_risk_test_pr_auc": {k: v["pr_auc"] for k, v in base.get("followup_risk", {}).get("models", {}).items()},
            "noshow_test_pr_auc": {k: v["pr_auc"] for k, v in base.get("appointment_noshow", {}).get("splits", {}).get("split", {}).get("models", {}).items()},
            "action_gold_available": base.get("action_extraction", {}).get("gold_available")},
    }
    return st


def render_docs(cfg, st):
    docs = cfg_path(cfg, "docs")
    man = read_json(cfg_path(cfg, "raw") / "MANIFEST.json")
    rows = ["| file | source | version | retrieved (UTC) | size (B) | records | sha256 | license / restrictions | nature |", "|---|---|---|---|---|---|---|---|---|"]
    for k, v in man["files"].items():
        if "extracted from" in v["url"]:
            continue
        rows.append(f"| `{k}` | {v['source']} | {str(v['version'])[:48]} | {v['retrieved_at_utc']} | {v['size_bytes']:,} | {v['record_count']} | `{v['sha256']}` | {v['license'][:110]} | {v['nature'][:70]} |")
    prov = f"""# PROVENANCE

All raw files are stored **unmodified** under `data/raw/` and re-verified by SHA-256 on every validation run
(`reports/dataset_quality.md`, check Q14). The manifest is `data/raw/MANIFEST.json`.

Download failures at last run: **{man.get('failures') or 'none'}**.

{chr(10).join(rows)}

## Origin URLs
""" + "\n".join(f"- `{k}` <- {v['url']}" for k, v in man["files"].items() if "extracted from" not in v["url"]) + """

## Derived-data provenance
| artefact | provenance tag | meaning |
|---|---|---|
| canonical patients/encounters/notes | `documented_source` | copied from the source; date-only times flagged `time_imputed=True` |
| action examples | `label_tier=silver`, `label_method=rule_v1` / `synthea_template_rule` | rule-proposed, **not reviewed**; `gold` exists only for rows in `data/annotations/reviewed/*.csv` |
| obligations (chain position 0) | `extracted_rule` / `documented_source` | from rule extraction or documented orders/results |
| obligations (other chain positions), all events not copied from a source event | `simulated` | generated by `src/generate_scenarios.py` (seeded) |
| graph/stream records | inherited per record, plus `is_simulated` on the stream | |

**No cross-dataset patient linkage exists.** MTS-Dialog and ACI-Bench records are document-level pseudo-patients (`is_pseudo_patient=True`)
with *simulated* anchor dates (`created_time_precision=simulated`); the simulated follow-up layer attached to them is a generated scenario.
"""
    (docs / "PROVENANCE.md").write_text(prov)

    lab = """# LABEL DEFINITIONS

## Dataset 1 - action categories (multi-label; `labels` list and `y_<category>` columns)
| category | meaning (instruction/order language directed at a future action) | NOT this |
|---|---|---|
| appointment_referral | refer/consult a specialist, schedule or arrange an appointment/visit | merely mentioning a past consult |
| laboratory_test | order/repeat/check blood, urine, culture, A1c ... | lab values already resulted/reported |
| imaging | order/schedule x-ray, CT, MRI, ultrasound, echo ... | imaging result narrative |
| procedure | schedule/recommend a surgery, biopsy, endoscopy, injection, ECG ... | risks of a procedure |
| medication_action | start/stop/adjust/continue/refill a drug, medication reconciliation | home-medication lists, past exposure |
| patient_communication | notify/call/instruct/counsel the patient, return precautions | questions to the patient |
| followup_review | follow up/recheck/re-evaluate/review results in a timeframe | past visits |
| other_action | admit/discharge, diet/exercise/lifestyle directive, supportive care | |
| no_action | none of the above (includes completed-result records, history, questions, risks) | |

`tense` values: `directive` (forward-looking/orders), `historical`, `record` (documented completion or result), `question`, `none`.
Silver labels come from `src/action_rules.py` (rule ids in `rules`, per-category evidence spans in `evidence_spans`, offsets in `char_start/char_end` relative to
`span_basis`). Section headers of MTS-Dialog (PLAN, DISPOSITION ...) are note-section labels and are **not** used as action labels.
Tiers: `gold` = human-reviewed with `reviewer_id`+`reviewed_at`; `silver` = rule-proposed; `synthetic` = generated text (none in this release).

## Dataset 2 - outcome labels (per obligation; defined by the event history, see `generate_scenarios.label_node`)
| label | definition |
|---|---|
| completed | a verified completion-evidence event for this step exists at or before the deadline, with no conflicting secondary record |
| overdue_unresolved | no completion evidence by the deadline AND the deadline miss is documented (task-tracker snapshot `open` at deadline+1h, or documented no-show/cancellation), OR completion evidence only appears after the deadline (`resolved_late=True`) |
| unverified | completion evidence conflicts with a secondary record, or no completion and no status evidence at all (documentation gap) despite full observation |
| censored_or_unknown | the observation window ended before the deadline could be resolved |

Binary target `label_binary`: 1 = overdue_unresolved, 0 = completed; **unverified and censored_or_unknown are excluded** (never treated as failures).
`assessment_time` = created + U(0.2, 0.8) x (deadline - created), seeded per obligation; only obligations without completion evidence at that time are kept.
The risk question: *given only events <= assessment_time, will the obligation be unresolved at its deadline?* Deterministic overdue rules (flag only after the deadline) are
reported separately in the baselines and cannot provide early warning.

## Dataset 3 - `no_show`
1 = patient did not attend the scheduled appointment (`No-show = Yes` in the source). It is an attendance label, **not** a follow-up-completion label.

## Evidence verification states
`verified` (documented evidence), `unverified` (weak/secondary), `inferred` (derived relation, e.g. a later documented encounter inside the window, confidence 0.3),
`contradicted` (conflicting secondary record).
"""
    (docs / "LABEL_DEFINITIONS.md").write_text(lab)

    guide = f"""# ANNOTATION GUIDE & REVIEW PROCESS (action classification)

Purpose: turn rule-proposed **silver** labels into **gold** labels through genuine human review. LLM-generated labels must NOT be written as gold unless an
independent human review step is recorded.

1. Open `data/processed/action_classification/review_queue.csv` ({st['action_classification']['review_queue_size']} rows: uncertain rule outputs + a stratified random audit sample).
2. For each row read `text` (and its `source_dataset`/`section`) and decide the label set using `LABEL_DEFINITIONS.md`:
   * label **forward-looking instructions/orders only**; completed results, history, questions and risk statements are `no_action`;
   * multi-label is allowed; use `|` to separate (e.g. `laboratory_test|followup_review`);
   * one sentence = one decision; do not use neighbouring context to invent an instruction.
3. Fill `labels` (required), `reviewer_id` (a stable id or initials), `reviewed_at` (ISO date) and optionally `reviewer_comment`.
4. Save the completed file as `data/annotations/reviewed/<name>.csv` (keep columns `example_id,labels,reviewer_id,reviewed_at`).
5. Re-run `python -m src.pipeline --config config.yaml --steps extract_actions,baseline_check,validate`. Rows with all three fields filled become `label_tier=gold`
   (`label_method=human_review:<file>`); the baseline then reports rule/keyword/TF-IDF precision, recall and F1 **against gold**.
6. Quality: double-annotate >= 10% of rows and report agreement (Cohen's kappa) before using gold for model selection. The pipeline requires at least
   {cfg['thresholds']['min_gold_for_eval']} gold rows to compute gold metrics.

Current state: **{st['action_classification']['gold_examples']} gold rows** (no human review has been performed in this release).
"""
    (docs / "ANNOTATION_GUIDE.md").write_text(guide)
    ad = cfg_path(cfg, "processed") / "action_classification"
    ad.mkdir(parents=True, exist_ok=True)
    (ad / "ANNOTATION_GUIDE.md").write_text(guide)

    o, a, f, n = st["obligations"], st["action_classification"], st["followup_risk"], st["appointment_noshow"]
    nsub = read_json(cfg_path(cfg, "processed") / "appointment_noshow" / "noshow_stats.json")["subgroups"]
    bl = (read_json(cfg_path(cfg, "reports") / "baseline_results.json") if (cfg_path(cfg, "reports") / "baseline_results.json").exists() else {})
    sub_rows = ["| subgroup | level | n | no-show rate |", "|---|---|---|---|"]
    for g in ("gender", "age_band", "scholarship", "handicap_level", "hypertension", "diabetes", "wait_band"):
        for lvl, v in nsub[g].items():
            sub_rows.append(f"| {g} | {lvl} | {v['n']} | {v['no_show_rate']} |")
    nb = nsub["neighbourhood_summary"]
    fl = bl.get("appointment_noshow", {}).get("splits", {}).get("split", {}).get("xgboost_subgroups_test", {})
    flag_rows = ["| subgroup | level | n (test) | prevalence | mean predicted | share flagged at top-20% risk | PR-AUC |", "|---|---|---|---|---|---|---|"]
    for g, d in fl.items():
        for lvl, v in d.items():
            flag_rows.append(f"| {g} | {lvl} | {v['n']} | {v['prevalence']} | {v['mean_pred']} | {v['flagged_rate@top20pct']} | {v['pr_auc']} |")
    bias = "\n".join(["## No-show subgroup distribution & bias screen (real data; descriptive, not causal)", "", "\n".join(sub_rows), "",
                      f"Neighbourhoods: {nb['n_neighbourhoods']} ({nb['n_with_lt_100_rows']} with <100 rows); neighbourhood no-show rate ranges {nb['no_show_rate_min']}-{nb['no_show_rate_max']} among neighbourhoods with >=100 rows. "
                      "Neighbourhood, age, gender and the welfare flag (`scholarship`) are demographic/geographic proxies; the baseline model is **not** equalised across groups. "
                      "Baseline subgroup behaviour on the held-out patient-grouped test split (XGBoost sanity model):", "", "\n".join(flag_rows), "",
                      "Differences in the share flagged at a fixed top-20% cut-off show the model concentrates flags in some age groups. **Do not use a model trained on this data to deny, delay or deprioritise care**; "
                      "any deployment needs fairness evaluation on local data and clinical governance.", ""])
    card = f"""# DATASET CARD - MedRelay follow-up datasets (mode: {st['mode']}, seed {st['seed']})

**Purpose.** Reliable, leakage-checked training/evaluation data for MedRelay: clinical-action extraction, unresolved follow-up risk, a temporal evidence graph and a
real-time replay stream. **Not for clinical use. Not clinically validated.**

## What is real, synthetic, annotated, generated
| dataset | nature | used for |
|---|---|---|
| Synthetic Hospital v1.3 | synthetic (LLM-assisted) | notes, imaging orders, documented labs/imaging, official patient splits |
| Synthea sample | synthetic (rule-based) | timestamped encounters/labs/meds/procedures/care plans; FHIR notes |
| MTS-Dialog | annotated (human summaries of dialogues) | action-language variety (silver labels only) |
| ACI-Bench | annotated (clinician notes of simulated visits) | action-language variety (silver labels only), CC BY 4.0 |
| Kaggle No-Show | **real**, de-identified | appointment non-attendance baseline (independent of everything else) |
| follow-up scenarios (obligations, events, outcomes) | **generated** (seeded simulator) | risk prediction, graph, replay |

## Sizes (measured)
* Source records: {json.dumps(st['total_source_records'])}
* Canonical: {st['canonical']['n_patients']} patients ({st['canonical']['pseudo_patients_(document-level MTS/ACI)']} are document-level pseudo-patients), {st['canonical']['n_encounters']} encounters, {st['canonical']['n_notes']} notes.
* Action classification: {a['counts_by_split']} examples after duplicate/near-duplicate exclusion; label counts {a['label_counts_total']}; tiers {a['tier_counts']}; **gold = {a['gold_examples']}**.
* Obligations: {o['n_obligations_generated']} in {o['n_chains']} chains; non-root outcomes {o['outcomes_excluding_documented_roots']}; verified-evidence share {o['pct_with_verified_completion_evidence_excl_roots']}% (excluding documented roots).
* Dependency depth distribution {o['dependency_depth_distribution']}; {o['n_cross_chain_dependency_edges']} cross-chain dependency edges.
* Risk dataset: {f['rows']} assessments; by split {f['by_split']}; outcomes {f['outcome_label_counts']}; binary {f['binary_counts']}.
* No-show: {n['n_rows']} rows, no-show rate {n['no_show_rate']}; patient-grouped split {n['by_split_patient_grouped']}; chronological {n['by_split_chronological']}.
* Graph: {st['evidence_graph']['n_nodes']} nodes / {st['evidence_graph']['n_edges']} edges. Event stream: {st['event_stream']['n_deliveries']} deliveries.

## Splits
Official splits are preserved (Synthetic Hospital: train->train, public->validation, heldout->test, **never trained on**; MTS/ACI: official partitions, test sets -> `test`).
Synthea (no official split) and No-Show use deterministic patient-level hash assignment (70/15/15). Splits are assigned **before** scenario generation and reused by every
artefact for the same patient. Exact/near-duplicate action texts are removed from lower-precedence splits (train > validation > test).

## Intended use
Train/evaluate (1) a multi-label action classifier, (2) a follow-up failure risk model, (3) appointment attendance risk (separate), (4) graph/replay consumers.

## Limitations & assumptions (read before use)
1. **No human-reviewed (gold) action labels exist**; silver labels are rule-based and noisy (an informal developer read-through of samples found false positives such as past-tense statements and some multi-label ASR run-ons; precision has NOT been measured).
2. Synthetic Hospital provides only month-granular dates (all on the 15th); sub-day times for it are imputed. Plan sections exist in ~17% of its notes and are mostly narrative.
3. Synthea/SH contain **no** appointment, task, result-review or patient-notification events. Every follow-up event after the seed is **simulated**; outcome rates (e.g. overdue share) are
   simulation parameters, not epidemiology. Model scores on this data show pipeline soundness, not real-world effectiveness.
4. Behaviour profiles (scenario types) are generator-specific templates; they are kept in a hidden ground-truth file, but a model can still learn the generator's causal structure.
5. MTS/ACI-derived obligations are anchored to simulated dates and are single-document pseudo-patients (history features are empty for them).
6. Category skew: result-review/notification chains dominate the risk rows (see `reports/dataset_quality.md`, Q12).
7. Synthea timelines span decades (earliest 1942); replays should time-compress or filter by date.
8. No-show data: Brazilian public-hospital appointments from 2016; neighbourhood/age/gender are demographic proxies - subgroup rates in `reports/dataset_statistics.json`; do not use to deny or deprioritise care.
9. Rule extraction thresholds, scenario probabilities and censoring rates are in `src/` and `config.yaml`.

""" + bias + """
## Loading
See README.md ("Loading datasets"). Hidden fields live only in `followup_risk/ground_truth_hidden.parquet` and `event_stream/ground_truth_*.jsonl`.
"""
    (docs / "DATASET_CARD.md").write_text(card)


def render_baselines(cfg):
    rep = cfg_path(cfg, "reports")
    bp = rep / "baseline_results.json"
    if not bp.exists():
        return
    b = read_json(bp)
    L = ["# Baseline sanity checks (NOT production models)", "",
         f"Protocol: {b['protocol']}. `test_used_for_model_selection = {b['test_used_for_model_selection']}`.", "",
         "## 1. Action extraction", ""]
    a = b["action_extraction"]
    L += [f"* examples: {a['n']}; **gold (human-reviewed) available: {a['gold_available']}** -> {a['gold_evaluation']}", f"* {a['interpretation']}", "",
          "| model (agreement with SILVER labels, test) | micro P | micro R | micro F1 | macro F1 |", "|---|---|---|---|---|"]
    for k, lab in (("keyword_baseline_agreement_with_silver_test", "keyword baseline"), ("tfidf_logreg_agreement_with_silver_test", "TF-IDF + logistic regression")):
        m = a[k]
        L.append(f"| {lab} | {m['micro']['precision']} | {m['micro']['recall']} | {m['micro']['f1']} | {m['macro']['f1']} |")
    r = b["followup_risk"]
    L += ["", "## 2. Follow-up failure risk (SIMULATED data; held-out synthetic patients; test split)", "",
          f"n={r['n']}, positive rate={r['positive_rate']}", "", "| model | ROC-AUC | PR-AUC | Brier | ECE | F1@0.5 |", "|---|---|---|---|---|---|"]
    for k, v in r["models"].items():
        if k.endswith("_validation"):
            continue
        L.append(f"| {k} | {v['roc_auc']} | {v['pr_auc']} | {v['brier']} | {v['ece']} | {v['f1@0.5']} |")
    L += ["", f"Top XGBoost features: {[(round(x, 3), f) for x, f in r['top_features_xgboost'][:6]]}", "", r["interpretation"], "",
          "## 3. Appointment no-show (real data; not clinically validated)", ""]
    for col, sp in b["appointment_noshow"]["splits"].items():
        L += [f"### split = `{col}` (n={sp['n']}, test prevalence {sp['prevalence_test']})", "", "| model | ROC-AUC | PR-AUC | Brier | ECE |", "|---|---|---|---|---|"]
        for k, v in sp["models"].items():
            L.append(f"| {k} | {v['roc_auc']} | {v['pr_auc']} | {v['brier']} | {v['ece']} |")
        L.append("")
    (rep / "baseline_results.md").write_text("\n".join(L))


def run(cfg=None):
    cfg = cfg or load_config()
    render_baselines(cfg)
    st = collect(cfg)
    write_json(st, cfg_path(cfg, "reports") / "dataset_statistics.json")
    render_docs(cfg, st)
    log.info("wrote dataset_statistics.json and docs")
    return st


if __name__ == "__main__":
    run()
