"""Single entry point:  python -m src.pipeline --config config.yaml --all

Steps (in order): download, audit, normalize, extract_actions, generate_scenarios, build_risk_dataset, build_noshow_dataset,
build_graph, build_event_stream, baseline_check, validate, make_reports.
`--mode dev` runs a small representative subset into dev_run/ (raw downloads are shared); `--mode full` (default from config) uses every available record.
"""
from __future__ import annotations

import argparse
import copy
import importlib
import json
import time

from .common import ROOT, load_config, seed_everything, write_json

STEPS = ["download", "audit", "normalize", "extract_actions", "generate_scenarios", "build_risk_dataset", "build_noshow_dataset",
         "build_graph", "build_event_stream", "baseline_check", "validate", "make_reports"]


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--all", action="store_true", help="run every step")
    ap.add_argument("--steps", default="", help="comma-separated subset of: " + ",".join(STEPS))
    ap.add_argument("--mode", choices=["dev", "full"], default=None, help="override config mode")
    ap.add_argument("--skip-download", action="store_true")
    a = ap.parse_args(argv)
    cfg = load_config(a.config)
    if a.mode:
        cfg["mode"] = a.mode
    if cfg["mode"] == "dev":       # keep dev outputs apart from full outputs; raw data is shared
        cfg = copy.deepcopy(cfg)
        for k in ("interim", "processed", "reports", "docs"):
            cfg["paths"][k] = f"dev_run/{cfg['paths'][k]}"
    seed_everything(cfg["seed"])
    steps = STEPS if a.all or not a.steps else [s for s in a.steps.split(",") if s]
    if a.skip_download and "download" in steps:
        steps.remove("download")
    unknown = set(steps) - set(STEPS)
    if unknown:
        raise SystemExit(f"unknown steps: {unknown}")
    log = {"mode": cfg["mode"], "seed": cfg["seed"], "steps": {}}
    t_all = time.time()
    for s in steps:
        t0 = time.time()
        mod = importlib.import_module(f"src.{s}")
        try:
            res = mod.run(cfg)
            status = "ok"
            if s == "validate" and isinstance(res, dict) and res.get("FAIL"):
                status = "validation_failed"
        except Exception as e:  # noqa: BLE001
            log["steps"][s] = {"status": "error", "error": repr(e), "seconds": round(time.time() - t0, 1)}
            write_json(log, ROOT / cfg["paths"]["reports"] / "pipeline_run.json")
            raise
        log["steps"][s] = {"status": status, "seconds": round(time.time() - t0, 1)}
    log["total_seconds"] = round(time.time() - t_all, 1)
    write_json(log, ROOT / cfg["paths"]["reports"] / "pipeline_run.json")
    print(json.dumps(log, indent=2))
    return 1 if any(v["status"] == "validation_failed" for v in log["steps"].values()) else 0


if __name__ == "__main__":
    raise SystemExit(main())
