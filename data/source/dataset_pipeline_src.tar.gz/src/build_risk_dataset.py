"""Dataset 2 - follow-up failure risk prediction.

Question: given only information available at `assessment_time`, how likely is the obligation to remain
unresolved when its deadline arrives?

* assessment_time is drawn per obligation at a seeded fraction (config) of [created, deadline].
* Only obligations still OPEN at assessment_time (no completion evidence yet) are included -- asking whether an
  already-completed obligation will be unresolved at its deadline is moot.
* Every feature is computed from events with timestamp <= assessment_time (own obligation, its dependency ancestors,
  and the same patient's other chains). The label comes from the outcome derived from events AFTER the cutoff.
* Hidden generator fields (scenario profile, latent completion, outcome reason ...) are written to a separate
  ground-truth file and never appear in model-input files.
"""
from __future__ import annotations

import json
from collections import defaultdict

import numpy as np
import pandas as pd

from .common import cfg_path, get_logger, load_config, stable_uniform, write_json, write_table
from .generate_scenarios import COMPLETION_EVENT

log = get_logger("risk")

REVIEW_STEPS = {"result_reviewed", "report_reviewed", "post_procedure_review", "medication_reviewed"}
META_COLUMNS = ["obligation_id", "patient_id", "chain_id", "split", "source_dataset", "assessment_time_utc", "deadline_utc"]
LABEL_COLUMNS = ["outcome_label", "label_binary"]
FEATURE_SPEC = {
    "category": "task category of the obligation",
    "step_type": "step within the follow-up chain (e.g. result_reviewed)",
    "responsible_role": "role responsible for completing the obligation",
    "origin_encounter_type": "encounter type of the originating encounter (or 'none')",
    "origin_department": "department (or encounter class) of the originating encounter (or 'none')",
    "chain_position": "0-based position in the dependency chain",
    "chain_length": "number of obligations in the chain",
    "window_hours": "hours between obligation creation and deadline",
    "hours_to_deadline": "deadline minus assessment_time, hours",
    "elapsed_fraction": "(assessment_time - created) / window",
    "deadline_dow": "day of week of deadline (0=Mon)",
    "deadline_is_weekend": "deadline falls on Sat/Sun",
    "n_dependencies": "number of direct dependencies",
    "n_incomplete_dependencies": "direct dependencies without completion evidence at assessment_time",
    "n_incomplete_ancestors": "all transitive ancestors without completion evidence at assessment_time",
    "parent_state": "none | completed | pending (state of the direct parent(s) at assessment_time)",
    "hours_since_parent_completed": "hours since latest direct parent completion evidence (NaN if none)",
    "n_events_so_far": "events on this obligation and its ancestors up to assessment_time",
    "hours_since_last_event": "hours since the latest such event (hours since creation if none)",
    "no_events_yet": "1 if there is no event on the chain yet",
    "n_reminders": "reminder events so far",
    "n_contact_attempts": "contact attempts so far",
    "has_scheduled_appointment": "an appointment_scheduled event exists on the chain",
    "appointment_minus_deadline_hours": "scheduled appointment time minus deadline, hours (NaN if none scheduled)",
    "n_reschedules": "reschedule events so far",
    "has_cancellation": "cancellation event so far",
    "ack_state": "not_applicable | awaiting_result | not_viewed | viewed_unacknowledged",
    "n_verified_events": "verified events so far",
    "n_unverified_events": "unverified events so far",
    "has_conflicting_record": "a conflicting secondary record exists so far",
    "evidence_uncertainty": "(unverified + conflicting) / events so far (0 if none)",
    "has_documented_source_evidence": "chain includes a documented source-dataset event",
    "extraction_confidence": "confidence of the originating extraction (1.0 for structured/documented)",
    "prior_n_due": "patient's other-chain obligations already past deadline at assessment_time",
    "prior_n_completed_ontime": "of those, completed on time per evidence available at assessment_time",
    "prior_completion_rate": "Laplace-smoothed on-time completion rate of prior obligations",
    "prior_noshow_count": "documented no-show events for the patient so far",
    "n_concurrent_open": "patient's other open obligations (created, not past deadline, no completion) at assessment_time",
    "n_concurrent_open_same_role": "same, restricted to the same responsible role",
    "role_handoffs": "number of responsible-role changes along the chain up to this obligation",
    "own_n_events": "events on THIS obligation only (independent-task view) up to assessment_time",
    "own_hours_since_last_event": "hours since the latest event on this obligation only (hours since creation if none)",
    "own_no_events": "1 if this obligation itself has no event yet",
    "own_n_reminders": "reminder events on this obligation only",
    "own_n_contact_attempts": "contact attempts on this obligation only",
    "own_viewed": "1 if a result/medication was opened (viewed) on this obligation",
    "own_has_cancellation": "cancellation event on this obligation only",
    "n_encounters_since_origin": "patient's encounters after the originating encounter up to assessment_time",
    "n_department_transitions_since_origin": "of those, encounters in a different department/class than the origin",
}
FEATURE_COLUMNS = list(FEATURE_SPEC)
# Feature groups used by the downstream experiments (independent-task vs dependency-aware graph systems, ablations).
FEATURE_GROUPS = {
    "task": ["category", "step_type", "responsible_role", "origin_encounter_type", "origin_department", "window_hours", "hours_to_deadline",
             "elapsed_fraction", "deadline_dow", "deadline_is_weekend", "extraction_confidence"],
    "own_events": ["own_n_events", "own_hours_since_last_event", "own_no_events", "own_n_reminders", "own_n_contact_attempts", "own_viewed", "own_has_cancellation"],
    "workload_history": ["prior_n_due", "prior_n_completed_ontime", "prior_completion_rate", "prior_noshow_count", "n_concurrent_open",
                         "n_concurrent_open_same_role", "n_encounters_since_origin", "n_department_transitions_since_origin"],
    "graph_dependency": ["chain_position", "chain_length", "n_dependencies", "n_incomplete_dependencies", "n_incomplete_ancestors", "parent_state",
                         "hours_since_parent_completed", "role_handoffs"],
    "graph_temporal": ["n_events_so_far", "hours_since_last_event", "no_events_yet", "n_reminders", "n_contact_attempts", "has_scheduled_appointment",
                       "appointment_minus_deadline_hours", "n_reschedules", "has_cancellation"],
    "evidence": ["ack_state", "n_verified_events", "n_unverified_events", "has_conflicting_record", "evidence_uncertainty", "has_documented_source_evidence"],
}
FORBIDDEN_IN_MODEL_INPUT = [
    "scenario_profile", "latent_completion_time", "latent_completed", "doc_lost", "blocked_by_upstream", "observation_end",
    "outcome_reason", "resolved_late", "completion_event_time", "documented_root", "outcome_label", "label_binary",
    "failure_injected", "final_status",
]


def _hours(a, b):
    return (a - b).total_seconds() / 3600.0


def build(cfg=None):
    cfg = cfg or load_config()
    interim = cfg_path(cfg, "interim")
    sc = interim / "scenarios"
    out = cfg_path(cfg, "processed") / "followup_risk"
    obl = pd.read_parquet(sc / "obligations.parquet")
    ev = pd.read_parquet(sc / "events.parquet")
    gt = pd.read_parquet(sc / "ground_truth.parquet")
    enc = pd.read_parquet(interim / "encounters.parquet")
    for c in ("created_time_utc", "due_time_utc"):
        obl[c] = pd.to_datetime(obl[c], utc=True)
    ev["ts"] = pd.to_datetime(ev.timestamp_utc, utc=True)
    enc["ts"] = pd.to_datetime(enc.event_time_utc, utc=True)
    lo, hi = cfg["scenarios"]["assessment_fraction_range"]

    ob = obl.set_index("obligation_id")
    ctype = ob.step_type.map(COMPLETION_EVENT)
    ev["is_completion"] = ev.event_type.values == ctype.reindex(ev.obligation_id).values
    comp_time = ev[ev.is_completion].groupby("obligation_id").ts.min().to_dict()
    ev_by_ob = {k: g.sort_values("ts") for k, g in ev.groupby("obligation_id")}
    parents = {k: list(v) for k, v in ob.depends_on.to_dict().items()}

    def ancestors(oid, memo={}):
        if oid in memo:
            return memo[oid]
        res = []
        for p in parents[oid]:
            res.append(p)
            res.extend(ancestors(p))
        memo[oid] = list(dict.fromkeys(res))
        return memo[oid]

    enc_by_pat = {p: g.sort_values("ts") for p, g in enc.groupby("patient_id")}
    enc_idx = enc.set_index("encounter_id")
    noshow = ev[ev.event_type == "visit_no_show"].groupby("patient_id").ts.apply(list).to_dict()
    gt_i = gt.set_index("obligation_id")
    rows = []
    for pid, g in obl.groupby("patient_id", sort=False):
        g = g.sort_values(["due_time_utc", "obligation_id"])
        clen = g.chain_id.value_counts().to_dict()
        others = g[["obligation_id", "chain_id", "created_time_utc", "due_time_utc", "responsible_role"]].to_dict("records")
        for r in g.itertuples():
            if gt_i.at[r.obligation_id, "documented_root"]:
                continue
            f = lo + (hi - lo) * stable_uniform(r.obligation_id, f"assess{cfg['seed']}")
            A = r.created_time_utc + (r.due_time_utc - r.created_time_utc) * f
            ct = comp_time.get(r.obligation_id)
            if ct is not None and ct <= A:
                continue                          # already resolved at assessment time
            D = r.due_time_utc
            anc = ancestors(r.obligation_id)
            chain_ids = [r.obligation_id] + anc
            evs = [e for oid in chain_ids if oid in ev_by_ob for e in ev_by_ob[oid].itertuples() if e.ts <= A]
            evs.sort(key=lambda e: e.ts)
            direct = parents[r.obligation_id]
            inc_dep = sum(1 for p in direct if not (comp_time.get(p) is not None and comp_time[p] <= A))
            inc_anc = sum(1 for p in anc if not (comp_time.get(p) is not None and comp_time[p] <= A))
            if not direct:
                pstate, hs_parent = "none", np.nan
            else:
                ptimes = [comp_time[p] for p in direct if comp_time.get(p) is not None and comp_time[p] <= A]
                pstate = "completed" if len(ptimes) == len(direct) else "pending"
                hs_parent = _hours(A, max(ptimes)) if len(ptimes) == len(direct) else np.nan
            own = [e for e in evs if e.obligation_id == r.obligation_id]
            appt = [e for e in evs if e.event_type in ("appointment_scheduled", "appointment_rescheduled")]
            appt_h = np.nan
            if appt:
                pl = json.loads(appt[-1].payload or "{}")
                if "appointment_time" in pl:
                    appt_h = _hours(pd.Timestamp(pl["appointment_time"]), D)
            if r.step_type in REVIEW_STEPS:
                if any(e.event_type in ("result_opened", "medication_opened") for e in own):
                    ack = "viewed_unacknowledged"
                elif pstate in ("completed",):
                    ack = "not_viewed"
                else:
                    ack = "awaiting_result"
            else:
                ack = "not_applicable"
            nv = sum(1 for e in evs if e.verification == "verified")
            nu = sum(1 for e in evs if e.verification != "verified")
            conflict = any(e.event_type == "conflicting_record" for e in evs)
            # patient history (other chains only)
            due_prior = ont = 0
            conc = conc_role = 0
            for o in others:
                if o["chain_id"] == r.chain_id:
                    continue
                if o["created_time_utc"] > A:
                    continue
                oc = comp_time.get(o["obligation_id"])
                done = oc is not None and oc <= A
                if o["due_time_utc"] < A:
                    due_prior += 1
                    if done and oc <= o["due_time_utc"]:
                        ont += 1
                elif not done:
                    conc += 1
                    conc_role += int(o["responsible_role"] == r.responsible_role)
            ns = sum(1 for t in noshow.get(pid, []) if t <= A)
            # department/role transitions
            n_enc = n_dep = 0
            origin_type = origin_dept = "none"
            if r.encounter_id in enc_idx.index:
                oe = enc_idx.loc[r.encounter_id]
                origin_type = str(oe.encounter_type)
                origin_dept = str(oe.department) if pd.notna(oe.department) else str(oe.encounter_type)
                eg = enc_by_pat.get(pid)
                if eg is not None:
                    later = eg[(eg.ts > oe.ts) & (eg.ts <= A)]
                    n_enc = len(later)
                    cur = later.department.where(later.department.notna(), later.encounter_type)
                    n_dep = int((cur.astype(str) != origin_dept).sum())
            chain_nodes = [r.obligation_id] + anc
            roles = [ob.at[o, "responsible_role"] for o in sorted(chain_nodes, key=lambda o: ob.at[o, "chain_position"])]
            handoffs = sum(1 for a, b in zip(roles, roles[1:]) if a != b)
            last_ev = max((e.ts for e in evs), default=None)
            last_own = own[-1].ts if own else None
            rows.append(dict(
                own_n_events=len(own), own_hours_since_last_event=_hours(A, last_own) if last_own is not None else _hours(A, r.created_time_utc),
                own_no_events=int(len(own) == 0), own_n_reminders=sum(e.event_type == "reminder_sent" for e in own),
                own_n_contact_attempts=sum(e.event_type == "contact_attempt" for e in own),
                own_viewed=int(any(e.event_type in ("result_opened", "medication_opened") for e in own)),
                own_has_cancellation=int(any(e.event_type == "appointment_cancelled" for e in own)),
                obligation_id=r.obligation_id, patient_id=pid, chain_id=r.chain_id, split=r.split, source_dataset=r.source_dataset,
                assessment_time_utc=A.strftime("%Y-%m-%dT%H:%M:%SZ"), deadline_utc=D.strftime("%Y-%m-%dT%H:%M:%SZ"),
                category=r.category, step_type=r.step_type, responsible_role=r.responsible_role,
                origin_encounter_type=origin_type, origin_department=origin_dept, chain_position=int(r.chain_position),
                chain_length=int(clen[r.chain_id]),
                window_hours=_hours(D, r.created_time_utc), hours_to_deadline=_hours(D, A),
                elapsed_fraction=_hours(A, r.created_time_utc) / max(_hours(D, r.created_time_utc), 1e-6),
                deadline_dow=int(D.dayofweek), deadline_is_weekend=int(D.dayofweek >= 5),
                n_dependencies=len(direct), n_incomplete_dependencies=inc_dep, n_incomplete_ancestors=inc_anc,
                parent_state=pstate, hours_since_parent_completed=hs_parent, n_events_so_far=len(evs),
                hours_since_last_event=_hours(A, last_ev) if last_ev is not None else _hours(A, r.created_time_utc),
                no_events_yet=int(len(evs) == 0),
                n_reminders=sum(e.event_type == "reminder_sent" for e in evs),
                n_contact_attempts=sum(e.event_type == "contact_attempt" for e in evs),
                has_scheduled_appointment=int(bool(appt)), appointment_minus_deadline_hours=appt_h,
                n_reschedules=sum(e.event_type == "appointment_rescheduled" for e in evs),
                has_cancellation=int(any(e.event_type == "appointment_cancelled" for e in evs)),
                ack_state=ack, n_verified_events=nv, n_unverified_events=nu, has_conflicting_record=int(conflict),
                evidence_uncertainty=(nu / len(evs)) if evs else 0.0,
                has_documented_source_evidence=int(any(e.provenance == "documented_source" for e in evs)),
                extraction_confidence=float(r.extraction_confidence), prior_n_due=due_prior, prior_n_completed_ontime=ont,
                prior_completion_rate=(ont + 1) / (due_prior + 2), prior_noshow_count=ns, n_concurrent_open=conc,
                n_concurrent_open_same_role=conc_role, role_handoffs=handoffs, n_encounters_since_origin=n_enc,
                n_department_transitions_since_origin=n_dep))
    X = pd.DataFrame(rows)
    lab = gt[["obligation_id", "outcome_label"]]
    X = X.merge(lab, on="obligation_id", how="left")
    X["label_binary"] = X.outcome_label.map({"completed": 0, "overdue_unresolved": 1}).astype("Int64")
    assert set(FEATURE_COLUMNS).issubset(X.columns), set(FEATURE_COLUMNS) - set(X.columns)
    hidden = gt[gt.obligation_id.isin(X.obligation_id)].copy()
    cols = META_COLUMNS + FEATURE_COLUMNS + LABEL_COLUMNS
    X = X[cols]
    for sp in ("train", "validation", "test"):
        s = X[X.split == sp]
        write_table(s, out / f"features_{sp}")
        write_table(s[s.label_binary.notna()], out / f"binary_{sp}")
    write_table(hidden, out / "ground_truth_hidden")
    spec = {"meta_columns": META_COLUMNS, "feature_columns": FEATURE_COLUMNS, "feature_groups": FEATURE_GROUPS, "label_columns": LABEL_COLUMNS,
            "forbidden_in_model_input": FORBIDDEN_IN_MODEL_INPUT, "feature_definitions": FEATURE_SPEC,
            "categorical_columns": ["category", "step_type", "responsible_role", "origin_encounter_type", "origin_department", "parent_state", "ack_state"],
            "binary_target": "label_binary (1 = overdue_unresolved, 0 = completed); unverified & censored_or_unknown are excluded from binary training",
            "assessment_rule": f"assessment_time = created + U{tuple(cfg['scenarios']['assessment_fraction_range'])} * (deadline - created), seeded per obligation; only obligations without completion evidence at assessment_time are included",
            "excluded_demographics": "age/sex/race are deliberately NOT features (bias risk, not needed)"}
    write_json(spec, out / "feature_spec.json")
    stats = {
        "n_rows": int(len(X)), "by_split": X.split.value_counts().to_dict(),
        "outcome_label_counts": X.outcome_label.value_counts().to_dict(),
        "binary_counts": {sp: {str(k): int(v) for k, v in X[(X.split == sp) & X.label_binary.notna()].label_binary.value_counts().items()} for sp in ("train", "validation", "test")},
        "categories": X.category.value_counts().to_dict(),
        "n_open_excluded_already_complete_at_assessment": int((~obl.obligation_id.isin(X.obligation_id)).sum() - int(gt.documented_root.sum())),
    }
    write_json(stats, out / "risk_stats.json")
    log.info("risk dataset: %d rows; outcomes %s", len(X), stats["outcome_label_counts"])
    return stats


def run(cfg=None):
    return build(cfg)


if __name__ == "__main__":
    run()
