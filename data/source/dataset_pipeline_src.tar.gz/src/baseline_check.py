"""Minimal validation baselines. These are DATASET SANITY CHECKS, not MedRelay production models.

Rules followed
* hyper-parameters are fixed a priori; the validation split is used only for XGBoost early stopping;
  the test split is touched once for final reporting (test_used_for_model_selection=False).
* Action extraction: precision/recall/F1 against GOLD (human-reviewed) labels is computed only if enough gold exists;
  otherwise it is reported as not computable. Agreement with SILVER labels measures consistency/learnability only.
* Follow-up risk results are on SIMULATED data and say nothing about real clinical effectiveness.
* No-show results are on real appointment data but are not clinically validated and must not be used to deny care.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (average_precision_score, brier_score_loss, f1_score, precision_recall_fscore_support, precision_score,
                             recall_score, roc_auc_score)
from sklearn.multiclass import OneVsRestClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from xgboost import XGBClassifier

from .common import cfg_path, get_logger, load_config, read_json, write_json
from .schemas import ALL_CATEGORIES

log = get_logger("baseline")
SEED = 20261017

KEYWORDS = {  # deliberately simple, independent of src/action_rules.py regexes
    "laboratory_test": ["lab", "blood test", "cbc", "panel", "urinalysis", "culture", "a1c", "bloodwork", "blood work", "level"],
    "imaging": ["x-ray", "xray", "mri", "ct ", "ct scan", "ultrasound", "echo", "mammogram", "imaging", "scan"],
    "procedure": ["surgery", "biopsy", "procedure", "scope", "catheter", "injection", "excision", "repair"],
    "appointment_referral": ["refer", "appointment", "consult"],
    "medication_action": ["mg", "start", "prescrib", "medication", "continue", "dose", "antibiotic", "tablet"],
    "patient_communication": ["advised", "instructed", "call", "contact", "notify", "educat", "counsel"],
    "followup_review": ["follow up", "follow-up", "recheck", "return in", "reassess", "re-evaluate", "next visit"],
    "other_action": ["admit", "discharge", "diet", "exercise", "avoid", "monitor", "rest"],
}


def multilabel_matrix(series):
    return np.array([[int(c in list(ls)) for c in ALL_CATEGORIES] for ls in series])


def prf(y, p, names):
    pr, rc, f1, sup = precision_recall_fscore_support(y, p, average=None, zero_division=0)
    out = {n: {"precision": round(float(a), 4), "recall": round(float(b), 4), "f1": round(float(c), 4), "support": int(d)} for n, a, b, c, d in zip(names, pr, rc, f1, sup)}
    out["micro"] = {k: round(float(v), 4) for k, v in zip(("precision", "recall", "f1"), precision_recall_fscore_support(y, p, average="micro", zero_division=0)[:3])}
    out["macro"] = {k: round(float(v), 4) for k, v in zip(("precision", "recall", "f1"), precision_recall_fscore_support(y, p, average="macro", zero_division=0)[:3])}
    return out


def keyword_predict(texts):
    P = np.zeros((len(texts), len(ALL_CATEGORIES)), int)
    for i, t in enumerate(texts):
        tl = t.lower()
        hit = False
        for j, c in enumerate(ALL_CATEGORIES[:-1] if ALL_CATEGORIES[-1] == "no_action" else ALL_CATEGORIES):
            if c in KEYWORDS and any(k in tl for k in KEYWORDS[c]):
                P[i, j] = 1
                hit = True
        if not hit:
            P[i, ALL_CATEGORIES.index("no_action")] = 1
    return P


def action_baselines(cfg):
    ac = cfg_path(cfg, "processed") / "action_classification"
    S = {sp: pd.read_parquet(ac / f"{sp}.parquet") for sp in ("train", "validation", "test")}
    Y = {sp: multilabel_matrix(df.labels) for sp, df in S.items()}
    res = {"label_tier_of_targets": "silver (rule-proposed) unless noted; see gold section", "n": {sp: int(len(df)) for sp, df in S.items()}}
    gold = pd.concat([df[df.label_tier == "gold"] for df in S.values()])
    res["gold_available"] = int(len(gold))
    res["gold_evaluation"] = ("not computable: fewer than min_gold_for_eval human-reviewed examples exist; fill data/annotations/reviewed/*.csv from review_queue.csv "
                              "and re-run the pipeline") if len(gold) < cfg["thresholds"]["min_gold_for_eval"] else "see rule_v1_vs_gold"
    for sp in ("validation", "test"):
        res[f"keyword_baseline_agreement_with_silver_{sp}"] = prf(Y[sp], keyword_predict(S[sp].text.tolist()), ALL_CATEGORIES)
    vec = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True, max_features=50000)
    Xtr = vec.fit_transform(S["train"].text)
    keep = [j for j in range(Y["train"].shape[1]) if Y["train"][:, j].sum() > 0]
    clf = OneVsRestClassifier(LogisticRegression(C=2.0, class_weight="balanced", max_iter=2000, random_state=SEED)).fit(Xtr, Y["train"][:, keep])
    for sp in ("validation", "test"):
        P = np.zeros_like(Y[sp])
        P[:, keep] = clf.predict(vec.transform(S[sp].text))
        res[f"tfidf_logreg_agreement_with_silver_{sp}"] = prf(Y[sp], P, ALL_CATEGORIES)
    res["interpretation"] = ("Scores are agreement with rule-generated SILVER labels. They show the labels are learnable/consistent, NOT that they are correct. "
                             "The rule proposer's own output vs gold is the number that matters and is pending human review.")
    if len(gold) >= cfg["thresholds"]["min_gold_for_eval"]:
        yg = multilabel_matrix(gold.labels)
        res["rule_v1_vs_gold"] = prf(yg, multilabel_matrix(gold.silver_labels), ALL_CATEGORIES)
        res["keyword_baseline_vs_gold"] = prf(yg, keyword_predict(gold.text.tolist()), ALL_CATEGORIES)
        Pg = np.zeros_like(yg)
        Pg[:, keep] = clf.predict(vec.transform(gold.text))
        res["tfidf_logreg_vs_gold"] = prf(yg, Pg, ALL_CATEGORIES)
    return res


def ece(y, p, bins=10):
    edges = np.linspace(0, 1, bins + 1)
    idx = np.clip(np.digitize(p, edges) - 1, 0, bins - 1)
    tot, rows = 0.0, []
    for b in range(bins):
        m = idx == b
        if m.sum() == 0:
            continue
        tot += m.mean() * abs(p[m].mean() - y[m].mean())
        rows.append({"bin": b, "n": int(m.sum()), "mean_pred": round(float(p[m].mean()), 4), "frac_pos": round(float(y[m].mean()), 4)})
    return float(tot), rows


def bin_metrics(y, p, thr=0.5):
    e, rows = ece(y, p)
    pred = (p >= thr).astype(int)
    return {"roc_auc": round(float(roc_auc_score(y, p)), 4) if len(set(y)) > 1 else None, "pr_auc": round(float(average_precision_score(y, p)), 4),
            "prevalence": round(float(y.mean()), 4), "brier": round(float(brier_score_loss(y, p)), 4), "ece": round(e, 4),
            "precision@0.5": round(float(precision_score(y, pred, zero_division=0)), 4), "recall@0.5": round(float(recall_score(y, pred, zero_division=0)), 4),
            "f1@0.5": round(float(f1_score(y, pred, zero_division=0)), 4), "n": int(len(y)), "calibration_bins": rows}


def _prep_lr(cat, num):
    return ColumnTransformer([("c", OneHotEncoder(handle_unknown="ignore", min_frequency=30), cat),
                              ("n", make_pipeline(SimpleImputer(strategy="median"), StandardScaler()), num)])


def _xgb(Xtr, ytr, Xva, yva, cat, vocab):
    """vocab: category vocabularies shared across splits (levels only, no label information)."""
    def p(X):
        X = X.copy()
        for c in cat:
            X[c] = pd.Categorical(X[c], categories=vocab[c])
        return X
    Xtr_, Xva_ = p(Xtr), p(Xva)
    m = XGBClassifier(n_estimators=600, max_depth=4, learning_rate=0.05, subsample=0.8, colsample_bytree=0.8, min_child_weight=5,
                      enable_categorical=True, tree_method="hist", early_stopping_rounds=30, eval_metric="aucpr", random_state=SEED, n_jobs=4)
    m.fit(Xtr_, ytr, eval_set=[(Xva_, yva)], verbose=False)
    return m, p


def risk_baselines(cfg):
    fr = cfg_path(cfg, "processed") / "followup_risk"
    spec = read_json(fr / "feature_spec.json")
    F, cat = spec["feature_columns"], spec["categorical_columns"]
    num = [c for c in F if c not in cat]
    B = {sp: pd.read_parquet(fr / f"binary_{sp}.parquet") for sp in ("train", "validation", "test")}
    y = {sp: df.label_binary.astype(int).values for sp, df in B.items()}
    res = {"data": "SIMULATED follow-up scenarios (not real clinical outcomes)", "n": {sp: int(len(v)) for sp, v in y.items()},
           "positive_rate": {sp: round(float(v.mean()), 4) for sp, v in y.items()}, "models": {}}
    te = B["test"]
    base = float(y["train"].mean())
    res["models"]["majority_class(train prior)"] = bin_metrics(y["test"], np.full(len(te), base))
    # deadline-only logistic (time features only)
    tcols = ["hours_to_deadline", "window_hours", "elapsed_fraction"]
    lr_t = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000, random_state=SEED)).fit(B["train"][tcols], y["train"])
    res["models"]["deadline_only_logreg"] = bin_metrics(y["test"], lr_t.predict_proba(te[tcols])[:, 1])
    # deterministic rules (no learning)
    res["models"]["rule: overdue-now (hours_to_deadline<=0)"] = bin_metrics(y["test"], (te.hours_to_deadline <= 0).astype(float).values)
    res["models"]["rule: any incomplete dependency"] = bin_metrics(y["test"], (te.n_incomplete_dependencies > 0).astype(float).values)
    lr = make_pipeline(_prep_lr(cat, num), LogisticRegression(C=1.0, max_iter=2000, random_state=SEED)).fit(B["train"][F], y["train"])
    res["models"]["logreg_all_features"] = bin_metrics(y["test"], lr.predict_proba(te[F])[:, 1])
    res["models"]["logreg_all_features_validation"] = bin_metrics(y["validation"], lr.predict_proba(B["validation"][F])[:, 1])
    vocab = {c: sorted(pd.concat([B[sp][c] for sp in B]).astype(str).unique()) for c in cat}
    m, prep = _xgb(B["train"][F], y["train"], B["validation"][F], y["validation"], cat, vocab)
    px = m.predict_proba(prep(te[F]))[:, 1]
    res["models"]["xgboost_all_features"] = bin_metrics(y["test"], px)
    res["models"]["xgboost_all_features_validation"] = bin_metrics(y["validation"], m.predict_proba(prep(B["validation"][F]))[:, 1])
    res["xgboost_best_iteration"] = int(m.best_iteration)
    res["xgboost_by_source_dataset_test"] = {s: bin_metrics(y["test"][te.source_dataset.values == s], px[te.source_dataset.values == s])
                                             for s in te.source_dataset.unique() if (te.source_dataset == s).sum() > 100 and len(set(y["test"][te.source_dataset.values == s])) > 1}
    res["top_features_xgboost"] = sorted(zip(map(float, m.feature_importances_), F), reverse=True)[:8]
    res["interpretation"] = ("A learned model beating deadline-only/majority/rule baselines shows the simulated events carry signal for the label. Because the generator is "
                             "seeded and its causal structure is known, this is a pipeline sanity check, not evidence of real-world predictive validity.")
    return res


def noshow_baselines(cfg):
    ns = cfg_path(cfg, "processed") / "appointment_noshow"
    df = pd.read_parquet(ns / "all.parquet")
    from .build_noshow_dataset import FEATURES
    cat = ["gender", "neighbourhood"]
    num = [c for c in FEATURES if c not in cat]
    out = {"note": "real appointment data; not clinically validated; do not use to deny care", "features": FEATURES, "splits": {}}
    for col in ("split", "split_chrono"):
        tr, va, te = (df[df[col] == s] for s in ("train", "validation", "test"))
        ytr, yva, yte = tr.no_show.values, va.no_show.values, te.no_show.values
        r = {"n": {"train": len(tr), "validation": len(va), "test": len(te)}, "prevalence_test": round(float(yte.mean()), 4), "models": {}}
        r["models"]["majority(prevalence)"] = bin_metrics(yte, np.full(len(te), ytr.mean()))
        lr = make_pipeline(_prep_lr(cat, num), LogisticRegression(C=1.0, max_iter=3000, random_state=SEED)).fit(tr[FEATURES], ytr)
        plr = lr.predict_proba(te[FEATURES])[:, 1]
        r["models"]["logreg"] = bin_metrics(yte, plr)
        vocab = {c: sorted(df[c].astype(str).unique()) for c in cat}
        m, prep = _xgb(tr[FEATURES], ytr, va[FEATURES], yva, cat, vocab)
        px = m.predict_proba(prep(te[FEATURES]))[:, 1]
        r["models"]["xgboost"] = bin_metrics(yte, px)
        r["xgboost_best_iteration"] = int(m.best_iteration)
        if col == "split":
            age_band = pd.cut(te.age, [-1, 17, 34, 49, 64, 200], labels=["0-17", "18-34", "35-49", "50-64", "65+"])
            sub = {}
            for name, key in (("gender", te.gender), ("age_band", age_band), ("scholarship", te.scholarship), ("handicap_level>0", (te.handicap_level > 0).astype(int))):
                d = {}
                for k in pd.unique(key.dropna()):
                    mk = (key == k).values
                    if mk.sum() < 200 or len(set(yte[mk])) < 2:
                        continue
                    d[str(k)] = {"n": int(mk.sum()), "prevalence": round(float(yte[mk].mean()), 4), "mean_pred": round(float(px[mk].mean()), 4),
                                 "pr_auc": round(float(average_precision_score(yte[mk], px[mk])), 4), "roc_auc": round(float(roc_auc_score(yte[mk], px[mk])), 4),
                                 "flagged_rate@top20pct": round(float((px[mk] >= np.quantile(px, 0.8)).mean()), 4)}
                sub[name] = d
            r["xgboost_subgroups_test"] = sub
        out["splits"][col] = r
    out["note_sms"] = "sms_received__timing_uncertain is excluded from features (timing relative to the prediction cutoff is undocumented)."
    return out


def run(cfg=None):
    cfg = cfg or load_config()
    rep = cfg_path(cfg, "reports")
    res = {"test_used_for_model_selection": False,
           "protocol": "hyper-parameters fixed a priori; validation used only for XGBoost early stopping; test evaluated once",
           "action_extraction": action_baselines(cfg), "followup_risk": risk_baselines(cfg), "appointment_noshow": noshow_baselines(cfg)}
    write_json(res, rep / "baseline_results.json")
    r = res["followup_risk"]["models"]
    log.info("risk test PR-AUC: majority %.3f deadline-only %.3f logreg %.3f xgb %.3f", r["majority_class(train prior)"]["pr_auc"],
             r["deadline_only_logreg"]["pr_auc"], r["logreg_all_features"]["pr_auc"], r["xgboost_all_features"]["pr_auc"])
    nsr = res["appointment_noshow"]["splits"]["split"]["models"]
    log.info("no-show test PR-AUC: prevalence %.3f logreg %.3f xgb %.3f", nsr["majority(prevalence)"]["pr_auc"], nsr["logreg"]["pr_auc"], nsr["xgboost"]["pr_auc"])
    return res


if __name__ == "__main__":
    run()
