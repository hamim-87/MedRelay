"""Dataset 5 - real-time event replay stream (JSONL) + separate ground truth for evaluation.

Live stream records never carry outcomes or generator flags. Delivery imperfections are injected deterministically:
  late events (ingest delayed hours..days -> out of order), duplicate deliveries (same event_id, delivery_attempt=2),
  and naturally unresolved dependencies (upstream steps that never complete).
`event_time_utc` is when the event happened; `ingest_time_utc` is when the service receives it. The file is sorted by
ingest time (stream_seq), which is the order a replay service should consume.
"""
from __future__ import annotations

import json

import numpy as np
import pandas as pd

from .common import cfg_path, get_logger, load_config, stable_hash, write_json

log = get_logger("stream")
LATE_P, DUP_P, LATE_OB_P = 0.06, 0.03, 0.03


def _fmt(t: pd.Timestamp) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%SZ")


def build(cfg=None):
    cfg = cfg or load_config()
    interim = cfg_path(cfg, "interim")
    sc = interim / "scenarios"
    out = cfg_path(cfg, "processed") / "event_stream"
    obl = pd.read_parquet(sc / "obligations.parquet")
    ev = pd.read_parquet(sc / "events.parquet")
    gt = pd.read_parquet(sc / "ground_truth.parquet")
    enc = pd.read_parquet(interim / "encounters.parquet")
    seed = cfg["seed"]
    recs = []

    def rng_for(key):
        return np.random.default_rng(stable_hash(key, f"stream{seed}"))

    def add(event_id, etype, ts, patient_id, encounter_id, obligation_id, payload, provenance, simulated, split, source_dataset, kind="normal"):
        r = rng_for(event_id)
        t = pd.Timestamp(ts)
        anomalies = []
        if kind == "tick":
            ing = t
        else:
            late_p = LATE_OB_P if etype == "obligation_created" else LATE_P
            if r.random() < late_p:
                ing = t + pd.Timedelta(hours=float(r.uniform(2, 120)))
                anomalies.append("late")
            else:
                ing = t + pd.Timedelta(seconds=float(np.exp(np.log(20) + 0.8 * r.standard_normal())))
        base = dict(event_id=event_id, patient_id=patient_id, encounter_id=encounter_id, obligation_id=obligation_id,
                    event_time_utc=_fmt(t), event_type=etype, payload=payload, provenance=provenance, is_simulated=bool(simulated),
                    split=split, source_dataset=source_dataset)
        recs.append(dict(base, ingest_time_utc=_fmt(ing), delivery_attempt=1, _anom=anomalies))
        if kind != "tick" and r.random() < DUP_P:
            recs.append(dict(base, ingest_time_utc=_fmt(ing + pd.Timedelta(seconds=float(r.uniform(1, 600)))), delivery_attempt=2,
                             _anom=["duplicate"]))

    pat_split = dict(zip(obl.patient_id, obl.split))
    # ALL encounters of every patient with an obligation are streamed, so a consumer can rebuild encounter-based features exactly
    for r in enc[enc.patient_id.isin(set(obl.patient_id))].itertuples():
        add(f"{r.encounter_id}:start", "encounter_start", r.event_time_utc, r.patient_id, r.encounter_id, None,
            {"encounter_type": r.encounter_type, "department": r.department, "time_precision": r.time_precision,
             "time_imputed": bool(r.time_imputed)}, "documented_source", False, pat_split[r.patient_id], r.source_dataset)
    chain_len = obl.groupby("chain_id").size().to_dict()
    for r in obl.itertuples():
        documented0 = r.chain_position == 0 and r.seed_kind in ("documented_lab_result", "structured_order", "documented_careplan", "text_extracted")
        add(f"{r.obligation_id}:created", "obligation_created", r.created_time_utc, r.patient_id, r.encounter_id, r.obligation_id,
            {"category": r.category, "step_type": r.step_type, "description": r.description, "responsible_role": r.responsible_role,
             "due_time_utc": r.due_time_utc, "depends_on": list(r.depends_on), "extraction_confidence": float(r.extraction_confidence),
             "label_tier": r.label_tier, "due_time_imputed": bool(r.due_time_imputed), "chain_id": r.chain_id,
             "chain_position": int(r.chain_position), "chain_length": int(chain_len[r.chain_id]), "source_dataset": r.source_dataset,
             "created_time_utc": r.created_time_utc},
            "extracted_rule" if r.seed_kind == "text_extracted" and r.chain_position == 0 else ("documented_source" if documented0 else "simulated"),
            not documented0, r.split, r.source_dataset)
        add(f"{r.obligation_id}:deadline", "deadline_reached", r.due_time_utc, r.patient_id, r.encounter_id, r.obligation_id,
            {"due_time_utc": r.due_time_utc}, "simulated", True, r.split, r.source_dataset, kind="tick")
    split_of = dict(zip(obl.obligation_id, obl.split))
    src_of = dict(zip(obl.obligation_id, obl.source_dataset))
    for r in ev.itertuples():
        add(r.event_id, r.event_type, r.timestamp_utc, r.patient_id, r.encounter_id, r.obligation_id,
            {"status": r.status, "evidence_source": r.evidence_source, "verification": r.verification,
             "details": json.loads(r.payload or "{}"), "source_event_id": r.source_event_id},
            r.provenance, r.provenance == "simulated", split_of[r.obligation_id], src_of[r.obligation_id])
    df = pd.DataFrame(recs)
    df["_t"] = pd.to_datetime(df.ingest_time_utc, utc=True)
    df = df.sort_values(["_t", "event_id", "delivery_attempt"], kind="mergesort").reset_index(drop=True)
    df["stream_seq"] = np.arange(len(df))
    df["delivery_id"] = df.event_id + "#" + df.delivery_attempt.astype(str)
    live_cols = ["stream_seq", "delivery_id", "event_id", "delivery_attempt", "patient_id", "encounter_id", "obligation_id",
                 "event_time_utc", "ingest_time_utc", "event_type", "payload", "provenance", "is_simulated", "split", "source_dataset"]
    out.mkdir(parents=True, exist_ok=True)

    def dump(frame, path):
        with open(path, "w") as f:
            for rec in frame[live_cols].to_dict("records"):
                rec = {k: (None if (not isinstance(v, (dict, list)) and pd.isna(v)) else v) for k, v in rec.items()}
                f.write(json.dumps(rec, default=str) + "\n")

    dump(df, out / "event_stream.jsonl")
    for sp in ("train", "validation", "test"):
        dump(df[df.split == sp], out / f"event_stream_{sp}.jsonl")
    # ---- ground truth (separate file; never joined into the live payload)
    g = gt.merge(obl[["obligation_id", "category", "step_type"]], on="obligation_id")
    comp = g.completion_event_time
    g["deterministic_overdue_rule_flags_at_deadline"] = ((comp.isna()) | (pd.to_datetime(comp, utc=True) > pd.to_datetime(g.deadline, utc=True))).astype(bool)
    keep = ["obligation_id", "patient_id", "split", "category", "step_type", "deadline", "outcome_label", "outcome_reason", "resolved_late",
            "completion_event_time", "scenario_profile", "latent_completed", "latent_completion_time", "doc_lost", "blocked_by_upstream",
            "observation_end", "documented_root", "deterministic_overdue_rule_flags_at_deadline"]
    with open(out / "ground_truth_obligations.jsonl", "w") as f:
        for rec in g[keep].to_dict("records"):
            rec = {k: (None if (not isinstance(v, (dict, list)) and pd.isna(v)) else (bool(v) if isinstance(v, (np.bool_,)) else v)) for k, v in rec.items()}
            f.write(json.dumps(rec, default=str) + "\n")
    anom = df[df._anom.map(len) > 0][["delivery_id", "event_id", "event_type", "obligation_id", "event_time_utc", "ingest_time_utc", "_anom"]]
    with open(out / "ground_truth_delivery_anomalies.jsonl", "w") as f:
        for rec in anom.to_dict("records"):
            rec["anomalies"] = rec.pop("_anom")
            f.write(json.dumps(rec) + "\n")
    # out-of-order measure: records whose event_time is earlier than an already-delivered record of the same obligation
    ooo = 0
    last = {}
    for r in df[["obligation_id", "event_time_utc"]].itertuples(index=False):
        k = r.obligation_id
        if k is None or pd.isna(k):
            continue
        if k in last and r.event_time_utc < last[k]:
            ooo += 1
        last[k] = max(last.get(k, r.event_time_utc), r.event_time_utc)
    stats = {"n_deliveries": int(len(df)), "n_logical_events": int(df.event_id.nunique()),
             "by_type": df.event_type.value_counts().to_dict(),
             "n_late": int(df._anom.map(lambda a: "late" in a).sum()), "n_duplicates": int(df._anom.map(lambda a: "duplicate" in a).sum()),
             "n_out_of_order_deliveries_per_obligation": int(ooo),
             "n_simulated_events": int(df[df.delivery_attempt == 1].is_simulated.sum()),
             "n_obligations_never_completed_in_stream": int(((g.completion_event_time.isna()) & (~g.documented_root)).sum()),
             "anomaly_rates_config": {"late": LATE_P, "duplicate": DUP_P, "late_obligation_created": LATE_OB_P}}
    write_json(stats, out / "stream_stats.json")
    log.info("event stream: %d deliveries (%d logical events), %d late, %d duplicates", len(df), stats["n_logical_events"], stats["n_late"], stats["n_duplicates"])
    return stats


def run(cfg=None):
    return build(cfg)


if __name__ == "__main__":
    run()
