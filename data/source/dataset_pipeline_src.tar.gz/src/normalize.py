"""Normalize raw sources into canonical MedRelay tables under data/interim/.

Outputs (parquet):
  patients, encounters, notes, note_sections, source_events
Namespaces: sh: (Synthetic Hospital)  sy: (Synthea)  mts: (MTS-Dialog)  aci: (ACI-Bench)

Rules
- Official splits are preserved (SH: train/public/heldout; MTS & ACI: file-level). Mapping to the
  generic names: train->train, public/validation/valid->validation, heldout/test*->test.
  Synthea has no official split, so patients are hash-assigned (documented, deterministic).
- Date-only timestamps are never silently upgraded: time_precision="date" and time_imputed=True
  mark the 09:00:00Z convention used for ordering.
- No identifiers (names, SSN, addresses...) are carried over from Synthea.
"""
from __future__ import annotations

import base64
import json
import re
import sqlite3
import zipfile

import pandas as pd

from .common import ROOT, cfg_path, get_logger, hash_split, load_config, write_table
from .schemas import Encounter, Note, Patient, validate_rows

log = get_logger("normalize")

SH_SPLIT_MAP = {"train": "train", "public": "validation", "heldout": "test"}
MTS_SPLIT = {"MTS-Dialog-TrainingSet": ("train", "train"), "MTS-Dialog-ValidationSet": ("validation", "validation"),
             "MTS-Dialog-TestSet-1-MEDIQA-Chat-2023": ("test", "test1_mediqa_chat"),
             "MTS-Dialog-TestSet-2-MEDIQA-Sum-2023": ("test", "test2_mediqa_sum")}
ACI_SPLIT = {"train": ("train", "train"), "valid": ("validation", "valid"),
             "clinicalnlp_taskB_test1": ("test", "test1"), "clinicalnlp_taskC_test2": ("test", "test2"),
             "clef_taskC_test3": ("test", "test3")}


def _ro(path):
    return sqlite3.connect(f"file:{path}?mode=ro", uri=True)


def _date_to_ts(d: str) -> str:
    return f"{d}T09:00:00Z"


# --------------------------------------------------------------------------- Dataset A
def normalize_synthetic_hospital(cfg, raw, limit):
    p = _ro(raw / "synthetic_hospital" / "patient_profiles.db")
    b = _ro(raw / "synthetic_hospital" / "benchmark_v1.3.db")
    pat = pd.read_sql("select * from patients", p)
    enc = pd.read_sql("select * from encounters", p)
    gt = pd.read_sql("select patient_id, split from benchmark_ground_truth", b)
    sp = gt.groupby("patient_id")["split"].agg(lambda s: sorted(set(s)))
    multi = sp[sp.map(len) > 1]
    if len(multi):
        raise ValueError(f"{len(multi)} patients have >1 official split label")
    pat["official_split"] = pat.patient_id.map(sp.map(lambda x: x[0]))
    if pat.official_split.isna().any():
        raise ValueError("patients without official split label in benchmark_ground_truth")
    if limit:  # dev subset, stratified over the official splits
        pat = pat.sort_values("patient_id")
        pat = pd.concat([g.head(max(1, limit * len(g) // len(pat))) for _, g in pat.groupby("official_split")])
        enc = enc[enc.patient_id.isin(pat.patient_id)]
    patients = pd.DataFrame({
        "patient_id": "sh:P" + pat.patient_id.astype(str), "source_dataset": "synthetic_hospital",
        "source_patient_id": pat.patient_id.astype(str), "split": pat.official_split.map(SH_SPLIT_MAP),
        "official_split": pat.official_split, "split_origin": "official", "sex": pat.sex,
        "age": pat.age.astype(float), "race_ethnicity": pat.race_ethnicity, "is_pseudo_patient": False})
    enc = enc.sort_values(["patient_id", "encounter_order"])
    encounters = pd.DataFrame({
        "encounter_id": "sh:E" + enc.encounter_id.astype(str), "patient_id": "sh:P" + enc.patient_id.astype(str),
        "source_dataset": "synthetic_hospital", "source_encounter_id": enc.encounter_id.astype(str),
        "event_time_utc": enc.encounter_date.map(_date_to_ts), "time_precision": "date", "time_imputed": True,
        "encounter_type": enc.encounter_type, "department": enc.department, "chief_complaint": enc.chief_complaint,
        "encounter_order": enc.encounter_order.astype(int)})
    smap = dict(zip(patients.patient_id, patients.split))
    omap = dict(zip(patients.patient_id, patients.official_split))
    notes = pd.DataFrame({
        "note_id": "sh:N" + enc.encounter_id.astype(str), "encounter_id": encounters.encounter_id.values,
        "patient_id": encounters.patient_id.values, "source_dataset": "synthetic_hospital",
        "text_kind": "clinical_note", "section": None, "text": enc.note_text.values})
    notes["split"] = notes.patient_id.map(smap)
    notes["official_split"] = notes.patient_id.map(omap)
    notes["provenance"] = "synthetic_hospital/patient_profiles.db:encounters.note_text (LLM-assisted synthetic)"
    sec = pd.read_sql("select encounter_id, section_type, section_text, section_order from encounter_ehr_sections", b)
    sec = sec[sec.encounter_id.astype(str).isin(enc.encounter_id.astype(str))]
    note_sections = pd.DataFrame({
        "section_id": "sh:S" + sec.encounter_id.astype(str) + "_" + sec.section_order.astype(str),
        "note_id": "sh:N" + sec.encounter_id.astype(str), "section_type": sec.section_type,
        "section_order": sec.section_order, "text": sec.section_text})
    # documented structured events
    ev = []
    ev.append(pd.DataFrame({
        "event_id": "sh:ev:enc" + enc.encounter_id.astype(str), "patient_id": encounters.patient_id.values,
        "encounter_id": encounters.encounter_id.values, "event_type": "encounter_start",
        "timestamp_utc": encounters.event_time_utc.values, "time_precision": "date",
        "description": enc.encounter_type.values, "code": None, "status": "documented", "value": None}))
    imo = pd.read_sql("select * from imaging_orders", b)
    imo = imo[imo.encounter_id.astype(str).isin(enc.encounter_id.astype(str))]
    pid_of = dict(zip(enc.encounter_id.astype(str), "sh:P" + enc.patient_id.astype(str)))
    ev.append(pd.DataFrame({
        "event_id": "sh:ev:imo" + imo.order_id.astype(str), "patient_id": imo.encounter_id.astype(str).map(pid_of),
        "encounter_id": "sh:E" + imo.encounter_id.astype(str), "event_type": "imaging_order_documented",
        "timestamp_utc": imo.order_datetime.map(lambda d: _date_to_ts(str(d)[:10])), "time_precision": "date",
        "description": (imo.modality.astype(str) + "/" + imo.body_region.astype(str) + ": " + imo.clinical_indication.astype(str)),
        "code": imo.order_priority, "status": "ordered", "value": None}))
    labs = sec[sec.section_type == "labs"]
    ev.append(pd.DataFrame({
        "event_id": "sh:ev:lab" + labs.encounter_id.astype(str), "patient_id": labs.encounter_id.astype(str).map(pid_of),
        "encounter_id": "sh:E" + labs.encounter_id.astype(str), "event_type": "lab_result_documented",
        "timestamp_utc": encounters.set_index("encounter_id").loc["sh:E" + labs.encounter_id.astype(str), "event_time_utc"].values,
        "time_precision": "date", "description": labs.section_text.str.slice(0, 200).values, "code": None,
        "status": "resulted", "value": None}))
    imaging = sec[sec.section_type == "imaging"]
    ev.append(pd.DataFrame({
        "event_id": "sh:ev:img" + imaging.encounter_id.astype(str), "patient_id": imaging.encounter_id.astype(str).map(pid_of),
        "encounter_id": "sh:E" + imaging.encounter_id.astype(str), "event_type": "imaging_result_documented",
        "timestamp_utc": encounters.set_index("encounter_id").loc["sh:E" + imaging.encounter_id.astype(str), "event_time_utc"].values,
        "time_precision": "date", "description": imaging.section_text.str.slice(0, 200).values, "code": None,
        "status": "resulted", "value": None}))
    events = pd.concat(ev, ignore_index=True)
    events["source_dataset"] = "synthetic_hospital"
    # imaging orders joined to documented text (kept for the benchmark-order check in extract_actions)
    imo_out = imo.assign(note_id="sh:N" + imo.encounter_id.astype(str), patient_id=imo.encounter_id.astype(str).map(pid_of))
    return patients, encounters, notes, note_sections, events, imo_out


# --------------------------------------------------------------------------- Dataset B
def _syn_ts(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, utc=True, errors="coerce").dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def normalize_synthea(cfg, raw, limit):
    d = raw / "synthea" / "csv"
    pat = pd.read_csv(d / "patients.csv")
    pat = pat.sort_values("Id")
    if limit:
        pat = pat.head(limit)
    keep = set(pat.Id)
    fr = cfg["splits"]["synthea_fractions"]
    patients = pd.DataFrame({
        "patient_id": "sy:P" + pat.Id, "source_dataset": "synthea", "source_patient_id": pat.Id,
        "split": [hash_split(i, fr, "synthea_patient_split") for i in pat.Id], "official_split": None,
        "split_origin": "hash_assigned", "sex": pat.GENDER,
        "age": ((pd.Timestamp("2026-01-01") - pd.to_datetime(pat.BIRTHDATE)).dt.days / 365.25).round(1),
        "race_ethnicity": pat.RACE.astype(str) + "/" + pat.ETHNICITY.astype(str), "is_pseudo_patient": False})
    enc = pd.read_csv(d / "encounters.csv")
    enc = enc[enc.PATIENT.isin(keep)].sort_values(["PATIENT", "START"])
    enc["order"] = enc.groupby("PATIENT").cumcount()
    encounters = pd.DataFrame({
        "encounter_id": "sy:E" + enc.Id, "patient_id": "sy:P" + enc.PATIENT, "source_dataset": "synthea",
        "source_encounter_id": enc.Id, "event_time_utc": _syn_ts(enc.START), "time_precision": "datetime",
        "time_imputed": False, "encounter_type": enc.ENCOUNTERCLASS, "department": None,
        "chief_complaint": enc.REASONDESCRIPTION, "encounter_order": enc.order})
    ev = []

    def add(df, ts, etype, desc, code, status, value=None, tprec="datetime", eid_prefix=""):
        ev.append(pd.DataFrame({
            "event_id": eid_prefix + pd.Series(range(len(df)), index=df.index).astype(str),
            "patient_id": "sy:P" + df.PATIENT, "encounter_id": ("sy:E" + df.ENCOUNTER) if "ENCOUNTER" in df else None,
            "event_type": etype, "timestamp_utc": ts, "time_precision": tprec,
            "description": desc, "code": code, "status": status, "value": value}))

    add(enc.assign(ENCOUNTER=enc.Id), encounters.event_time_utc, "encounter_start", enc.DESCRIPTION, enc.CODE.astype(str),
        "documented", eid_prefix="sy:ev:enc")
    obs = pd.read_csv(d / "observations.csv", low_memory=False)
    obs = obs[obs.PATIENT.isin(keep) & (obs.CATEGORY == "laboratory")]
    add(obs, _syn_ts(obs.DATE), "lab_result_available", obs.DESCRIPTION, obs.CODE.astype(str), "resulted",
        (obs.VALUE.astype(str) + " " + obs.UNITS.fillna("").astype(str)).str.strip(), eid_prefix="sy:ev:obs")
    med = pd.read_csv(d / "medications.csv")
    med = med[med.PATIENT.isin(keep)]
    add(med, _syn_ts(med.START), "medication_started", med.DESCRIPTION, med.CODE.astype(str), "active", eid_prefix="sy:ev:medstart")
    med2 = med[med.STOP.notna()]
    add(med2, _syn_ts(med2.STOP), "medication_stopped", med2.DESCRIPTION, med2.CODE.astype(str), "stopped", eid_prefix="sy:ev:medstop")
    pr = pd.read_csv(d / "procedures.csv")
    pr = pr[pr.PATIENT.isin(keep)]
    add(pr, _syn_ts(pr.START), "procedure_performed", pr.DESCRIPTION, pr.CODE.astype(str), "completed", eid_prefix="sy:ev:proc")
    cp = pd.read_csv(d / "careplans.csv")
    cp = cp[cp.PATIENT.isin(keep)]
    add(cp, _syn_ts(cp.START), "careplan_started", cp.DESCRIPTION, cp.CODE.astype(str), "active", tprec="date", eid_prefix="sy:ev:cpstart")
    cp2 = cp[cp.STOP.notna()]
    add(cp2, _syn_ts(cp2.STOP), "careplan_stopped", cp2.DESCRIPTION, cp2.CODE.astype(str), "stopped", tprec="date", eid_prefix="sy:ev:cpstop")
    im = pd.read_csv(d / "imaging_studies.csv")
    im = im[im.PATIENT.isin(keep)]
    add(im, _syn_ts(im.DATE), "imaging_performed", im.MODALITY_DESCRIPTION.astype(str) + ": " + im.BODYSITE_DESCRIPTION.astype(str),
        im.MODALITY_CODE.astype(str), "completed", eid_prefix="sy:ev:img")
    imu = pd.read_csv(d / "immunizations.csv")
    imu = imu[imu.PATIENT.isin(keep)]
    add(imu, _syn_ts(imu.DATE), "immunization_given", imu.DESCRIPTION, imu.CODE.astype(str), "completed", eid_prefix="sy:ev:imm")
    events = pd.concat(ev, ignore_index=True)
    events["source_dataset"] = "synthea"
    # ---- notes: FHIR DocumentReference clinical notes
    smap = dict(zip(patients.patient_id, patients.split))
    rows = []
    with zipfile.ZipFile(raw / "synthea" / "synthea_sample_data_fhir_latest.zip") as z:
        for nm in z.namelist():
            if not nm.endswith(".json"):
                continue
            bundle = json.loads(z.read(nm))
            for e in bundle.get("entry", []):
                r = e["resource"]
                if r["resourceType"] != "DocumentReference":
                    continue
                pid = r["subject"]["reference"].replace("urn:uuid:", "")
                if pid not in keep:
                    continue
                encid = r["context"]["encounter"][0]["reference"].replace("urn:uuid:", "")
                text = base64.b64decode(r["content"][0]["attachment"]["data"]).decode("utf-8")
                rows.append((f"sy:N{r['id']}", f"sy:E{encid}", f"sy:P{pid}", text))
    notes = pd.DataFrame(rows, columns=["note_id", "encounter_id", "patient_id", "text"])
    notes["source_dataset"] = "synthea"
    notes["text_kind"] = "clinical_note"
    notes["section"] = None
    notes["split"] = notes.patient_id.map(smap)
    notes["official_split"] = None
    notes["provenance"] = "synthea FHIR R4 DocumentReference (base64 text/plain), templated by the Synthea simulator"
    return patients, encounters, notes, events


# --------------------------------------------------------------------------- Dataset C / E
def normalize_mts(raw):
    pats, notes = [], []
    for stem, (split, osplit) in MTS_SPLIT.items():
        df = pd.read_csv(raw / "mts_dialog" / f"{stem}.csv")
        for r in df.itertuples():
            pid = f"mts:{osplit}:{r.ID}"
            pats.append(dict(patient_id=pid, source_dataset="mts_dialog", source_patient_id=f"{osplit}:{r.ID}", split=split,
                             official_split=osplit, split_origin="official", sex=None, age=None, race_ethnicity=None,
                             is_pseudo_patient=True))
            base = dict(encounter_id=None, patient_id=pid, source_dataset="mts_dialog", split=split, official_split=osplit)
            notes.append(dict(base, note_id=f"mts:D{osplit}:{r.ID}", text_kind="dialogue", section=r.section_header,
                              text=str(r.dialogue).replace("\r\n", "\n"),
                              provenance=f"MTS-Dialog {stem}.csv:dialogue (section_header={r.section_header})"))
            notes.append(dict(base, note_id=f"mts:S{osplit}:{r.ID}", text_kind="section_summary", section=r.section_header,
                              text=str(r.section_text).replace("\r\n", "\n"),
                              provenance=f"MTS-Dialog {stem}.csv:section_text (human summary; section_header is NOT a follow-up label)"))
    return pd.DataFrame(pats), pd.DataFrame(notes)


def normalize_aci(raw):
    pats, notes = [], []
    for stem, (split, osplit) in ACI_SPLIT.items():
        df = pd.read_csv(raw / "aci_bench" / f"{stem}.csv")
        for r in df.itertuples():
            pid = f"aci:{osplit}:{r.encounter_id}"
            pats.append(dict(patient_id=pid, source_dataset="aci_bench", source_patient_id=f"{osplit}:{r.encounter_id}", split=split,
                             official_split=osplit, split_origin="official", sex=None, age=None, race_ethnicity=None,
                             is_pseudo_patient=True))
            base = dict(encounter_id=None, patient_id=pid, source_dataset="aci_bench", split=split, official_split=osplit, section=None)
            notes.append(dict(base, note_id=f"aci:D{osplit}:{r.encounter_id}", text_kind="dialogue", text=str(r.dialogue),
                              provenance=f"ACI-Bench {stem}.csv:dialogue (subset={r.dataset})"))
            notes.append(dict(base, note_id=f"aci:N{osplit}:{r.encounter_id}", text_kind="visit_note", text=str(r.note),
                              provenance=f"ACI-Bench {stem}.csv:note (clinician-authored; subset={r.dataset})"))
    return pd.DataFrame(pats), pd.DataFrame(notes)


# --------------------------------------------------------------------------- driver
def run(cfg=None):
    cfg = cfg or load_config()
    raw, interim = cfg_path(cfg, "raw"), cfg_path(cfg, "interim")
    dev = cfg["mode"] == "dev"
    d = cfg["dev"]
    log.info("normalizing (mode=%s)", cfg["mode"])
    shp, she, shn, shs, shev, imo = normalize_synthetic_hospital(cfg, raw, d["max_sh_patients"] if dev else None)
    syp, sye, syn, syev = normalize_synthea(cfg, raw, d["max_synthea_patients"] if dev else None)
    mtp, mtn = normalize_mts(raw)
    acp, acn = normalize_aci(raw)

    patients = pd.concat([shp, syp, mtp, acp], ignore_index=True)
    encounters = pd.concat([she, sye], ignore_index=True)
    notes = pd.concat([shn, syn, mtn, acn], ignore_index=True)
    events = pd.concat([shev, syev], ignore_index=True)
    events["provenance"] = "documented_source"
    events["obligation_id"] = None

    # integrity checks on the canonical tables (hard failures)
    for name, df, key in [("patients", patients, "patient_id"), ("encounters", encounters, "encounter_id"),
                          ("notes", notes, "note_id"), ("events", events, "event_id")]:
        dup = df[key].duplicated().sum()
        if dup:
            raise ValueError(f"{name}: {dup} duplicate {key}")
    for name, errs in [("patients", validate_rows(patients, Patient)), ("encounters", validate_rows(encounters, Encounter)),
                       ("notes", validate_rows(notes, Note))]:
        if errs:
            raise ValueError(f"{name} schema errors: {errs}")
    miss = set(encounters.patient_id) - set(patients.patient_id)
    if miss:
        raise ValueError(f"{len(miss)} encounters reference unknown patients")
    miss = set(notes.patient_id) - set(patients.patient_id)
    if miss:
        raise ValueError(f"{len(miss)} notes reference unknown patients")

    write_table(patients, interim / "patients")
    write_table(encounters, interim / "encounters")
    write_table(notes, interim / "notes")
    write_table(shs, interim / "note_sections")
    write_table(events, interim / "source_events")
    write_table(imo, interim / "sh_imaging_orders")
    log.info("patients=%d encounters=%d notes=%d events=%d", len(patients), len(encounters), len(notes), len(events))
    return {"patients": len(patients), "encounters": len(encounters), "notes": len(notes), "events": len(events)}


if __name__ == "__main__":
    run()
