"""Idempotent, checksum-verified downloader with retries/timeouts and a provenance manifest.

Raw files are stored unmodified under data/raw/<source>/. A manifest at
data/raw/MANIFEST.json records, per file: source, URL, commit/version, retrieval time,
license, SHA-256, size, format, record count and nature (real/synthetic/annotated).
Re-running skips files whose on-disk SHA-256 matches the manifest (no re-download).
"""
from __future__ import annotations

import csv
import datetime as dt
import gzip
import io
import json
import shutil
import sqlite3
import subprocess
import time
import zipfile
from pathlib import Path

import requests

from .common import ROOT, cfg_path, get_logger, load_config, read_json, sha256_file, write_json

log = get_logger("download")
RAW_BASE = "https://raw.githubusercontent.com/{repo}/{commit}/{path}"


def _rel(p: Path) -> str:
    try:
        return str(p.relative_to(ROOT))
    except ValueError:
        return str(p)


def _count_records(path: Path) -> int | None:
    """Best-effort record count by format; None if not applicable."""
    try:
        suf = path.suffix.lower()
        if suf == ".csv":
            csv.field_size_limit(1 << 30)
            with open(path, newline="", encoding="utf-8", errors="replace") as f:
                return max(sum(1 for _ in csv.reader(f)) - 1, 0)
        if suf == ".jsonl":
            with open(path, "rb") as f:
                return sum(1 for _ in f)
        if suf == ".db":
            con = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
            tabs = [r[0] for r in con.execute("select name from sqlite_master where type='table'")]
            n = {t: con.execute(f'select count(*) from "{t}"').fetchone()[0] for t in tabs}
            con.close()
            return sum(n.values())
        if suf == ".zip":
            with zipfile.ZipFile(path) as z:
                return len(z.namelist())
    except Exception as e:  # noqa: BLE001
        log.warning("record count failed for %s: %s", path, e)
    return None


def _http_download(url: str, dest: Path, retries: int, timeout: int, backoff: float) -> None:
    tmp = dest.with_suffix(dest.suffix + ".part")
    last: Exception | None = None
    for attempt in range(1, retries + 1):
        try:
            with requests.get(url, stream=True, timeout=timeout) as r:
                r.raise_for_status()
                dest.parent.mkdir(parents=True, exist_ok=True)
                with open(tmp, "wb") as f:
                    for chunk in r.iter_content(1 << 20):
                        f.write(chunk)
                expected = r.headers.get("Content-Length")
                if expected and not r.headers.get("Content-Encoding") and tmp.stat().st_size != int(expected):
                    raise IOError(f"size mismatch {tmp.stat().st_size} != {expected}")
            tmp.replace(dest)
            return
        except Exception as e:  # noqa: BLE001
            last = e
            log.warning("attempt %d/%d failed for %s: %s", attempt, retries, url, e)
            time.sleep(backoff * attempt)
    raise RuntimeError(f"download failed after {retries} attempts: {url}: {last}")


class Manifest:
    def __init__(self, path: Path):
        self.path = path
        self.data = read_json(path) if path.exists() else {"files": {}, "failures": []}

    def get(self, key: str):
        return self.data["files"].get(key)

    def put(self, key: str, rec: dict):
        self.data["files"][key] = rec
        self.save()

    def fail(self, source: str, url: str, err: str):
        self.data["failures"] = [f for f in self.data["failures"] if f["url"] != url]
        self.data["failures"].append({"source": source, "url": url, "error": err,
                                      "time": dt.datetime.now(dt.timezone.utc).isoformat()})
        self.save()

    def clear_fail(self, url: str):
        self.data["failures"] = [f for f in self.data["failures"] if f["url"] != url]

    def save(self):
        write_json(self.data, self.path)


def _fetch(man: Manifest, cfg: dict, *, source: str, key: str, url: str, dest: Path, meta: dict,
           downloader=None) -> bool:
    dl = cfg["download"]
    rec = man.get(key)
    if rec and dest.exists() and sha256_file(dest) == rec["sha256"]:
        changed = False
        if not rec.get("format"):             # backfill for extension-less files such as LICENSE
            rec["format"], changed = "txt", True
        for k in ("license", "nature", "version"):       # keep provenance text in sync with config
            if meta.get(k) and rec.get(k) != meta[k]:
                rec[k], changed = meta[k], True
        if changed:
            man.put(key, rec)
        log.info("cached  %s", key)
        return True
    try:
        if downloader:
            downloader(dest)
        else:
            _http_download(url, dest, dl["retries"], dl["timeout_s"], dl["backoff_s"])
    except Exception as e:  # noqa: BLE001
        log.error("FAILED %s: %s", key, e)
        man.fail(source, url, str(e))
        return False
    man.clear_fail(url)
    man.put(key, {
        "source": source, "url": url, "local_path": _rel(dest),
        "retrieved_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "sha256": sha256_file(dest), "size_bytes": dest.stat().st_size,
        "format": dest.suffix.lstrip(".").lower() or "txt", "record_count": _count_records(dest), **meta,
    })
    log.info("fetched %s (%d bytes)", key, dest.stat().st_size)
    return True


def _kaggle_download(slug: str, dest: Path) -> None:
    out = dest.parent
    out.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(["kaggle", "datasets", "download", "-d", slug, "-p", str(out), "--force"],
                       capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        raise RuntimeError(f"kaggle CLI failed: {r.stderr.strip() or r.stdout.strip()}")
    if not dest.exists():
        raise RuntimeError(f"expected {dest} after kaggle download; got {[p.name for p in out.iterdir()]}")


def kaggle_version(slug: str) -> str | None:
    """Best-effort version marker for a Kaggle dataset: its lastUpdated timestamp from the public listing."""
    try:
        owner, name = slug.split("/")
        r = subprocess.run(["kaggle", "datasets", "list", "--user", owner, "-s", name, "--csv"], capture_output=True, text=True, timeout=60)
        if r.returncode:
            return None
        rows = list(csv.DictReader(io.StringIO(r.stdout)))
        for row in rows:
            if row.get("ref") == slug:
                return f"kaggle lastUpdated={row['lastUpdated']} size={row['size']}"
    except Exception:  # noqa: BLE001
        return None
    return None


def kaggle_license(slug: str) -> str | None:
    """License name from the dataset's public Kaggle metadata (via the Kaggle CLI)."""
    import tempfile
    try:
        with tempfile.TemporaryDirectory() as td:
            r = subprocess.run(["kaggle", "datasets", "metadata", slug, "-p", td], capture_output=True, text=True, timeout=60)
            if r.returncode:
                return None
            info = json.load(open(Path(td) / "dataset-metadata.json"))["info"]
            names = [x.get("name") for x in info.get("licenses", []) if x.get("name")]
            return ", ".join(names) or None
    except Exception:  # noqa: BLE001
        return None


def run(cfg: dict | None = None) -> dict:
    cfg = cfg or load_config()
    raw = cfg_path(cfg, "raw")
    man = Manifest(raw / "MANIFEST.json")
    S = cfg["sources"]
    ok: dict[str, bool] = {}

    # A. Synthetic Hospital -- pinned commit
    s = S["synthetic_hospital"]
    for f in s["files"]:
        url = RAW_BASE.format(repo=s["repo"], commit=s["commit"], path=f)
        nature = "synthetic (LLM-assisted generation from medical-education vignettes + knowledge graph)"
        if f in ("patient_profiles.jsonl", "patient_profiles.db", "benchmark_v1.3.db"):
            ok[f"A/{f}"] = _fetch(man, cfg, source="synthetic_hospital", key=f"synthetic_hospital/{f}", url=url,
                                  dest=raw / "synthetic_hospital" / f,
                                  meta={"version": f"git:{s['commit']}", "license": s["license"], "nature": nature})
        else:
            ok[f"A/{f}"] = _fetch(man, cfg, source="synthetic_hospital", key=f"synthetic_hospital/{f}", url=url,
                                  dest=raw / "synthetic_hospital" / f,
                                  meta={"version": f"git:{s['commit']}", "license": s["license"], "nature": "documentation"})

    # B. Synthea sample data (CSV + FHIR R4)
    s = S["synthea"]
    for fmt, url in s["urls"].items():
        try:
            lm = requests.head(url, timeout=cfg["download"]["timeout_s"], allow_redirects=True).headers.get("Last-Modified")
        except Exception:  # noqa: BLE001
            lm = None
        dest = raw / "synthea" / Path(url).name
        ok[f"B/{fmt}"] = _fetch(man, cfg, source="synthea", key=f"synthea/{dest.name}", url=url, dest=dest,
                                meta={"version": f"'latest' sample-data build; HTTP Last-Modified: {lm or 'unavailable'}",
                                      "license": s["license"], "nature": "synthetic (rule-based Synthea simulator)"})

    # C. MTS-Dialog -- pinned commit
    s = S["mts_dialog"]
    for f in s["files"]:
        url = RAW_BASE.format(repo=s["repo"], commit=s["commit"], path=f)
        ok[f"C/{f}"] = _fetch(man, cfg, source="mts_dialog", key=f"mts_dialog/{f}", url=url,
                              dest=raw / "mts_dialog" / Path(f).name,
                              meta={"version": f"git:{s['commit']}", "license": s["license"],
                                    "nature": "real-style simulated doctor-patient dialogues with human-written section summaries (annotated; not follow-up annotations)"})

    # D. Kaggle no-show
    s = S["noshow"]
    dest = raw / "noshow" / "noshowappointments.zip"
    ok["D/noshow"] = _fetch(man, cfg, source="noshow", key="noshow/noshowappointments.zip",
                            url=f"https://www.kaggle.com/datasets/{s['kaggle']}", dest=dest,
                            downloader=lambda d: _kaggle_download(s["kaggle"], d),
                            meta={"version": kaggle_version(s["kaggle"]) or "kaggle latest at retrieval time (version marker unavailable)",
                                  "license": (lambda l: f"{l} per Kaggle metadata (NonCommercial + ShareAlike: check this fits your use before any redistribution)" if l else
                                              "Kaggle dataset page lists the license; verify terms before redistribution")(kaggle_license(s["kaggle"])),
                                  "nature": "real (de-identified) appointment records"})
    rec_ns = man.get("noshow/noshowappointments.zip")
    if rec_ns and str(rec_ns.get("version", "")).startswith("kaggle latest"):          # backfill version marker for cached downloads
        v = kaggle_version(s["kaggle"])
        if v:
            rec_ns["version"] = v
            man.put("noshow/noshowappointments.zip", rec_ns)
    if rec_ns and str(rec_ns.get("license", "")).startswith("Kaggle dataset page"):
        lic = kaggle_license(s["kaggle"])
        if lic:
            rec_ns["license"] = f"{lic} per Kaggle metadata (NonCommercial + ShareAlike: check this fits your use before any redistribution)"
            man.put("noshow/noshowappointments.zip", rec_ns)
    if dest.exists():
        ex = raw / "noshow"
        with zipfile.ZipFile(dest) as z:
            for n in z.namelist():
                if not (ex / n).exists():
                    z.extract(n, ex)
                    csvp = ex / n
                    man.put(f"noshow/{n}", {"source": "noshow", "url": f"extracted from {dest.name}",
                            "local_path": str(csvp.relative_to(ROOT)),
                            "retrieved_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                            "sha256": sha256_file(csvp), "size_bytes": csvp.stat().st_size, "format": "csv",
                            "record_count": _count_records(csvp), "version": "kaggle latest",
                            "license": "see Kaggle page", "nature": "real (de-identified) appointment records"})

    # Synthea: extract CSVs for use (zip itself remains unmodified)
    zcsv = raw / "synthea" / Path(cfg["sources"]["synthea"]["urls"]["csv"]).name
    if zcsv.exists():
        ex = raw / "synthea" / "csv"
        if not ex.exists():
            ex.mkdir(parents=True)
            with zipfile.ZipFile(zcsv) as z:
                z.extractall(ex)
            for p in sorted(ex.rglob("*.csv")):
                man.put(f"synthea/csv/{p.name}", {"source": "synthea", "url": f"extracted from {zcsv.name}",
                        "local_path": str(p.relative_to(ROOT)), "retrieved_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                        "sha256": sha256_file(p), "size_bytes": p.stat().st_size, "format": "csv",
                        "record_count": _count_records(p), "version": "latest", "license": cfg["sources"]["synthea"]["license"],
                        "nature": "synthetic (rule-based Synthea simulator)"})

    # E. ACI-Bench -- pinned commit
    s = S["aci_bench"]
    for f in s["files"]:
        url = RAW_BASE.format(repo=s["repo"], commit=s["commit"], path=f)
        ok[f"E/{f}"] = _fetch(man, cfg, source="aci_bench", key=f"aci_bench/{f}", url=url,
                              dest=raw / "aci_bench" / Path(f).name,
                              meta={"version": f"git:{s['commit']}", "license": s["license"],
                                    "nature": "simulated (actor-performed) doctor-patient encounters with clinician-authored notes (annotated)"})
    for k, v in list(man.data["files"].items()):       # extracted members inherit provenance from their parent archive
        if "extracted from" in v["url"]:
            parent = "noshow/noshowappointments.zip" if k.startswith("noshow/") else "synthea/synthea_sample_data_csv_latest.zip"
            pr = man.get(parent)
            if pr:
                v.update(license=pr["license"], version=pr["version"], nature=pr["nature"])
    man.save()
    failed = [k for k, v in ok.items() if not v]
    log.info("download complete: %d ok, %d failed %s", len(ok) - len(failed), len(failed), failed)
    return {"ok": ok, "failed": failed}


if __name__ == "__main__":
    run()
