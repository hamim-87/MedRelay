"""Mandatory source audit -> reports/source_audit.json + reports/source_audit.md

Runs against the RAW files (before any transformation): schemas, dtypes, null %, duplicates, identifier & FK checks,
timestamp semantics, section structure, and the share of records containing potentially actionable instructions.
"""
from __future__ import annotations

import base64
import collections
import json
import re
import sqlite3
import zipfile

import pandas as pd

from .action_rules import propose
from .common import ROOT, cfg_path, get_logger, load_config, read_json, write_json
from .extract_actions import ACI_PLAN, ACI_SKIP, HEADER_RE, MTS_PLAN_HDR, SH_NARR_SECTIONS, SH_PLAN_SECTIONS, split_sentences, split_dialogue

log = get_logger("audit")


def _ro(p):
    return sqlite3.connect(f"file:{p}?mode=ro", uri=True)


def table_profile(df: pd.DataFrame, name: str, key: str | None = None) -> dict:
    nulls = (df.isna().mean() * 100).round(3)
    prof = {"rows": int(len(df)), "columns": {c: {"dtype": str(df[c].dtype), "null_pct": float(nulls[c])} for c in df.columns},
            "exact_duplicate_rows": int(df.astype(str).duplicated().sum()) if len(df) < 500_000 else None}
    if key and key in df:
        prof["key"] = key
        prof["duplicate_keys"] = int(df[key].duplicated().sum())
    return prof


def _scan_actionable(text_units: list[tuple[str, str]]) -> dict:
    """text_units: list of (doc_id, sentence_kind_text) -> dict with doc-level actionable share. Each unit = (doc_id, section_kind, sentence)."""
    docs, hit = set(), set()
    cat_counts = collections.Counter()
    n_sent = 0
    for doc, sk, sent in text_units:
        docs.add(doc)
        n_sent += 1
        pr = propose(sent, sk)
        if pr.labels and pr.tense == "directive":
            hit.add(doc)
            for l in pr.labels:
                cat_counts[l] += 1
    return {"documents_scanned": len(docs), "documents_with_directive_candidate": len(hit),
            "share_documents_with_directive_candidate": round(len(hit) / max(len(docs), 1), 4), "sentences_scanned": n_sent,
            "directive_sentence_label_counts": dict(cat_counts),
            "caveat": "rule-based candidate detection (action_rules.propose); NOT human-verified instructions"}


def audit_sh(raw) -> dict:
    d = raw / "synthetic_hospital"
    out: dict = {"nature": "synthetic"}
    p, b = _ro(d / "patient_profiles.db"), _ro(d / "benchmark_v1.3.db")
    out["tables"] = {}
    for con, dbn in ((p, "patient_profiles.db"), (b, "benchmark_v1.3.db")):
        for (n,) in con.execute("select name from sqlite_master where type='table'").fetchall():
            df = pd.read_sql(f'select * from "{n}"', con) if n not in ("relevance_judgments", "question_findings", "question_diagnoses", "diagnosis_findings") else \
                pd.read_sql(f'select * from "{n}" limit 20000', con)
            tp = table_profile(df, n)
            tp["rows"] = int(con.execute(f'select count(*) from "{n}"').fetchone()[0])
            if n in ("patients", "encounters", "longitudinal_patients", "longitudinal_encounters"):
                tp["key"] = "patient_id" if "patients" in n else "encounter_id"
                tp["duplicate_keys"] = int(df[tp["key"]].duplicated().sum())
            out["tables"][f"{dbn}:{n}"] = {k: v for k, v in tp.items() if k != "columns"} | {"columns": tp["columns"]}
    pat = pd.read_sql("select patient_id, num_encounters, age, sex from patients", p)
    enc = pd.read_sql("select * from encounters", p)
    gt = pd.read_sql("select task, patient_id, encounter_id, split from benchmark_ground_truth", b)
    sec = pd.read_sql("select encounter_id, section_type, section_text from encounter_ehr_sections", b)
    imo = pd.read_sql("select order_id, encounter_id, order_priority, order_datetime from imaging_orders", b)
    benc = pd.read_sql("select encounter_id, patient_id, encounter_date, note_text from longitudinal_encounters", b)
    # identifiers / FK
    fk = {
        "encounters.patient_id -> patients": int((~enc.patient_id.isin(pat.patient_id)).sum()),
        "patients without encounters": int((~pat.patient_id.isin(enc.patient_id)).sum()),
        "num_encounters mismatch vs actual": int((pat.set_index("patient_id").num_encounters != enc.groupby("patient_id").size().reindex(pat.patient_id).values).sum()),
        "ehr_sections.encounter_id -> encounters": int((~sec.encounter_id.isin(enc.encounter_id)).sum()),
        "imaging_orders.encounter_id -> encounters": int((~imo.encounter_id.isin(enc.encounter_id)).sum()),
        "ground_truth.patient_id -> patients": int((~gt.patient_id.isin(pat.patient_id)).sum()),
        "ground_truth.encounter_id (non-null) -> encounters": int((~gt.encounter_id.dropna().isin(enc.encounter_id)).sum()),
        "patient_profiles.db vs benchmark encounter id sets differ": int(len(set(enc.encounter_id) ^ set(benc.encounter_id))),
        "note_text differs between patient_profiles.db and benchmark db": int((enc.set_index("encounter_id").note_text != benc.set_index("encounter_id").note_text.reindex(enc.encounter_id).values).sum()),
    }
    out["foreign_keys_and_identifiers"] = fk
    # jsonl consistency
    n_lines, ids, n_enc, keys = 0, set(), 0, collections.Counter()
    with open(d / "patient_profiles.jsonl") as f:
        for line in f:
            o = json.loads(line)
            n_lines += 1
            ids.add(o["patient_id"])
            n_enc += len(o.get("encounters", []))
            keys.update(o.keys())
    out["jsonl"] = {"patients": n_lines, "encounters_nested": n_enc, "keys": dict(keys),
                    "patient_ids_match_db": ids == set(pat.patient_id), "encounter_total_matches_db": n_enc == len(enc)}
    # splits
    sp = gt.groupby("patient_id").split.agg(lambda s: sorted(set(s)))
    out["official_splits"] = {"patients_per_split": sp.map(lambda x: x[0]).value_counts().to_dict(),
                              "patients_with_multiple_split_labels": int((sp.map(len) > 1).sum())}
    # temporal semantics
    dts = pd.to_datetime(enc.encounter_date, errors="coerce")
    mono_viol = 0
    for pid, g in enc.sort_values("encounter_order").groupby("patient_id"):
        t = pd.to_datetime(g.encounter_date, errors="coerce").values
        mono_viol += int((t[1:] < t[:-1]).sum())
    out["temporal"] = {"timestamp_granularity": "date only (YYYY-MM-DD); no clock time", "invalid_dates": int(dts.isna().sum()),
                       "date_min": str(dts.min().date()), "date_max": str(dts.max().date()),
                       "all_days_equal_15": bool((dts.dt.day == 15).all()),
                       "encounter_order_vs_date_violations": mono_viol,
                       "same_patient_same_date_encounters": int(enc.assign(d=enc.encounter_date).duplicated(["patient_id", "d"]).sum()),
                       "implication": "event times are month-granular dates; any time-of-day / sub-day precision in MedRelay data for this source is IMPUTED (time_imputed=True)"}
    out["encounter_types"] = enc.encounter_type.value_counts().to_dict()
    out["generation_methods"] = enc.generation_method.value_counts().to_dict()
    # notes: sections and actionable language
    dup_notes = int(enc.note_text.duplicated().sum())
    out["notes"] = {"n": int(len(enc)), "duplicate_note_texts": dup_notes,
                    "note_has_plan_or_assessment_section": float(sec[sec.section_type.isin(["plan", "assessment"])].encounter_id.nunique() / len(enc)),
                    "section_type_counts": sec.section_type.value_counts().to_dict(),
                    "imaging_orders": int(len(imo)), "imaging_order_priorities": imo.order_priority.value_counts().to_dict(),
                    "encounters_with_documented_labs_section": int(sec[sec.section_type == "labs"].encounter_id.nunique())}
    units = []
    for r in sec.itertuples():
        if r.section_type in SH_PLAN_SECTIONS | SH_NARR_SECTIONS:
            sk = "plan" if r.section_type in SH_PLAN_SECTIONS else "narrative"
            for s, _, _ in split_sentences(r.section_text):
                units.append((r.encounter_id, sk, s))
    out["actionable_language"] = _scan_actionable(units)
    out["limitations"] = ["Plan/assessment sections exist in a minority of notes and are largely narrative, not instruction-like.",
                          "No follow-up outcomes, task statuses, or completion timestamps exist in the source.",
                          "Dates are all the 15th of a month (planned timeline granularity)."]
    return out


def audit_synthea(raw) -> dict:
    d = raw / "synthea" / "csv"
    out: dict = {"nature": "synthetic (Synthea)", "tables": {}}
    dfs = {}
    for f in sorted(d.glob("*.csv")):
        df = pd.read_csv(f, low_memory=False)
        dfs[f.stem] = df
        keyc = "Id" if "Id" in df.columns else None
        out["tables"][f.name] = table_profile(df, f.stem, keyc)
    pat, enc = dfs["patients"], dfs["encounters"]
    fk = {
        "encounters.PATIENT -> patients": int((~enc.PATIENT.isin(pat.Id)).sum()),
        "observations.ENCOUNTER -> encounters": int((~dfs["observations"].ENCOUNTER.dropna().isin(enc.Id)).sum()),
        "medications.ENCOUNTER -> encounters": int((~dfs["medications"].ENCOUNTER.isin(enc.Id)).sum()),
        "procedures.ENCOUNTER -> encounters": int((~dfs["procedures"].ENCOUNTER.isin(enc.Id)).sum()),
        "careplans.ENCOUNTER -> encounters": int((~dfs["careplans"].ENCOUNTER.isin(enc.Id)).sum()),
        "imaging_studies.ENCOUNTER -> encounters": int((~dfs["imaging_studies"].ENCOUNTER.isin(enc.Id)).sum()),
        "conditions.PATIENT -> patients": int((~dfs["conditions"].PATIENT.isin(pat.Id)).sum()),
    }
    out["foreign_keys_and_identifiers"] = fk
    st = pd.to_datetime(enc.START, utc=True, errors="coerce")
    sp = pd.to_datetime(enc.STOP, utc=True, errors="coerce")
    cp = dfs["careplans"]
    out["temporal"] = {"timestamp_granularity": "encounters/observations/medications/procedures/imaging: UTC datetime; careplans & conditions: date only",
                       "encounter_date_min": str(st.min()), "encounter_date_max": str(st.max()),
                       "invalid_encounter_starts": int(st.isna().sum()), "encounters_stop_before_start": int((sp < st).sum()),
                       "careplans_stop_before_start": int((pd.to_datetime(cp.STOP) < pd.to_datetime(cp.START)).sum()),
                       "medications_stop_before_start": int((pd.to_datetime(dfs['medications'].STOP, utc=True) < pd.to_datetime(dfs['medications'].START, utc=True)).sum()),
                       "observations_after_death": 0}
    out["encounter_classes"] = enc.ENCOUNTERCLASS.value_counts().to_dict()
    out["lab_observations"] = int((dfs["observations"].CATEGORY == "laboratory").sum())
    # FHIR resources
    cnt, notes_n, plan_lines = collections.Counter(), 0, collections.Counter()
    units = []
    with zipfile.ZipFile(raw / "synthea" / "synthea_sample_data_fhir_latest.zip") as z:
        for nm in z.namelist():
            if not nm.endswith(".json"):
                continue
            for e in json.loads(z.read(nm)).get("entry", []):
                r = e["resource"]
                cnt[r["resourceType"]] += 1
                if r["resourceType"] == "DocumentReference":
                    t = base64.b64decode(r["content"][0]["attachment"]["data"]).decode()
                    notes_n += 1
                    m = re.search(r"## Plan\n(.*)$", t, re.S)
                    if m:
                        for line in m.group(1).split("\n"):
                            if line.strip() and not line.startswith("-"):
                                plan_lines[line.strip()[:80]] += 1
    out["fhir_r4_resource_counts"] = dict(cnt)
    absent = [x for x in ("ServiceRequest", "Appointment", "Task", "Communication", "Goal", "Referral") if x not in cnt]
    out["resources_absent_in_this_release"] = absent
    out["missing_event_types_requiring_synthetic_layer"] = (
        "No appointment/task/order-status/result-review/patient-notification events exist: obligations deadlines, scheduling, attendance, "
        "result acknowledgment and patient contact are produced by the explicitly simulated layer (generate_scenarios.py).")
    out["notes"] = {"fhir_document_references": notes_n, "plan_section_line_headers": dict(plan_lines.most_common(8)),
                    "note": "Plan sections are templated RECORDS of what was done (procedures conducted, medications prescribed, labs completed), not forward-looking instructions."}
    return out


def audit_mts(raw) -> dict:
    out: dict = {"nature": "annotated (human-written section summaries of doctor-patient dialogues)", "files": {}}
    frames = {}
    for stem in ("MTS-Dialog-TrainingSet", "MTS-Dialog-ValidationSet", "MTS-Dialog-TestSet-1-MEDIQA-Chat-2023", "MTS-Dialog-TestSet-2-MEDIQA-Sum-2023"):
        df = pd.read_csv(raw / "mts_dialog" / f"{stem}.csv")
        frames[stem] = df
        out["files"][stem] = table_profile(df, stem, "ID")
    allm = pd.concat([f.assign(src=k) for k, f in frames.items()], ignore_index=True)
    out["section_header_counts"] = allm.section_header.value_counts().to_dict()
    out["id_unique_across_files"] = bool(not allm.ID.duplicated().any())
    out["dialogue_duplicates_within_all"] = int(allm.dialogue.duplicated().sum())
    tr = set(frames["MTS-Dialog-TrainingSet"].dialogue)
    out["dialogue_overlap_with_train"] = {k: int(f.dialogue.isin(tr).sum()) for k, f in frames.items() if "Training" not in k}
    units = []
    for r in allm.itertuples():
        sk = "plan" if r.section_header in MTS_PLAN_HDR else "narrative"
        for s, _, _ in split_sentences(str(r.section_text)):
            units.append((f"{r.src}:{r.ID}", sk, s))
    out["actionable_language_in_section_summaries"] = _scan_actionable(units)
    units = []
    for r in allm.itertuples():
        for line in str(r.dialogue).replace("\r\n", "\n").split("\n"):
            m = re.match(r"\s*(Doctor|Guest_clinician|Clinician)\s*:\s*(.*)", line, re.I)
            if m:
                for s, _, _ in split_dialogue(m.group(2)):
                    units.append((f"{r.src}:{r.ID}", "dialogue_doctor", s))
    out["actionable_language_in_doctor_turns"] = _scan_actionable(units)
    out["warning"] = "section_header (e.g. PLAN, DISPOSITION) is a note-section label, NOT a verified follow-up action label."
    out["temporal"] = "no dates/timestamps/patient identifiers in the source"
    return out


def audit_aci(raw) -> dict:
    out: dict = {"nature": "simulated encounters with clinician-authored notes (annotated)", "files": {}}
    units_note, units_dlg = [], []
    seen_notes, seen_dlg, dup = set(), set(), 0
    for stem in ("train", "valid", "clinicalnlp_taskB_test1", "clinicalnlp_taskC_test2", "clef_taskC_test3"):
        df = pd.read_csv(raw / "aci_bench" / f"{stem}.csv")
        out["files"][stem] = table_profile(df, stem, "encounter_id")
        for r in df.itertuples():
            if r.note in seen_notes:
                dup += 1
            seen_notes.add(r.note)
            cur, sk, skip = "", "narrative", False
            for line in r.note.split("\n"):
                ls = line.strip()
                if HEADER_RE.match(ls):
                    skip = any(k in ls for k in ACI_SKIP) and "PLAN" not in ls
                    sk = "plan" if any(k in ls for k in ACI_PLAN) else "narrative"
                elif ls and not skip:
                    for s, _, _ in split_sentences(line):
                        units_note.append((f"{stem}:{r.encounter_id}", sk, s))
            for line in r.dialogue.split("\n"):
                m = re.match(r"\s*\[doctor\]\s*(.*)", line, re.I)
                if m:
                    for s, _, _ in split_dialogue(m.group(1)):
                        units_dlg.append((f"{stem}:{r.encounter_id}", "dialogue_doctor", s))
    out["duplicate_notes"] = dup
    out["actionable_language_in_notes"] = _scan_actionable(units_note)
    out["actionable_language_in_doctor_turns"] = _scan_actionable(units_dlg)
    out["license"] = "CC BY 4.0 (repository README)"
    out["temporal"] = "no dates or patient identifiers; one visit per record"
    return out


def audit_noshow(raw) -> dict:
    df = pd.read_csv(raw / "noshow" / "KaggleV2-May-2016.csv")
    out: dict = {"nature": "real (de-identified) appointment records", "profile": table_profile(df, "KaggleV2-May-2016", "AppointmentID")}
    sched = pd.to_datetime(df.ScheduledDay, utc=True)
    appt = pd.to_datetime(df.AppointmentDay, utc=True)
    wait = (appt - sched.dt.floor("D")).dt.days
    out["date_semantics"] = {
        "ScheduledDay": "UTC datetime with time of day", "AppointmentDay": "UTC but time is always 00:00:00 (date only)",
        "appointment_time_of_day_available": bool((appt.dt.hour != 0).any()),
        "appointment_day_before_scheduled_instant": int((appt < sched).sum()),
        "negative_calendar_wait_days": int((wait < 0).sum()),
        "same_day_appointments": int((wait == 0).sum()), "wait_days_max": int(wait.max()),
        "scheduled_min": str(sched.min()), "scheduled_max": str(sched.max()), "appointment_min": str(appt.min()), "appointment_max": str(appt.max())}
    out["value_checks"] = {"age_negative": int((df.Age < 0).sum()), "age_gt_110": int((df.Age > 110).sum()),
                           "handicap_levels": {str(k): int(v) for k, v in df.Handcap.value_counts().items()},
                           "no_show_distribution": df["No-show"].value_counts(normalize=True).round(4).to_dict(),
                           "unique_patients": int(df.PatientId.nunique()), "patients_with_multiple_appointments": int((df.PatientId.value_counts() > 1).sum()),
                           "PatientId_is_float_dtype": str(df.PatientId.dtype),
                           "column_name_typos_in_source": ["Hipertension", "Handcap", "No-show (hyphen)"]}
    out["label_semantics"] = "No-show='Yes' means the patient did NOT attend the scheduled appointment. It is not a follow-up completion label."
    out["sms_received_note"] = "SMS_received timing relative to scheduling is undocumented -> not treated as known at the prediction cutoff."
    return out


def build(cfg=None):
    cfg = cfg or load_config()
    raw = cfg_path(cfg, "raw")
    reports = cfg_path(cfg, "reports")
    man = read_json(raw / "MANIFEST.json")
    audit = {
        "generated_note": "machine-readable audit of RAW source files; see sections per source",
        "manifest_summary": {k: {kk: v[kk] for kk in ("source", "url", "version", "retrieved_at_utc", "sha256", "size_bytes", "format", "record_count", "license", "nature")}
                             for k, v in man["files"].items() if "extracted from" not in v["url"]},
        "download_failures": man.get("failures", []),
    }
    log.info("auditing synthetic_hospital")
    audit["synthetic_hospital"] = audit_sh(raw)
    log.info("auditing synthea")
    audit["synthea"] = audit_synthea(raw)
    log.info("auditing mts_dialog")
    audit["mts_dialog"] = audit_mts(raw)
    log.info("auditing aci_bench")
    audit["aci_bench"] = audit_aci(raw)
    log.info("auditing noshow")
    audit["noshow"] = audit_noshow(raw)
    write_json(audit, reports / "source_audit.json")
    (reports / "source_audit.md").write_text(render_md(audit))
    return audit


def _kv(d: dict, indent=0) -> str:
    return "\n".join(f"{'  ' * indent}- **{k}**: {v}" for k, v in d.items())


def render_md(a: dict) -> str:
    L = ["# MedRelay Source Audit", "", "Generated by `src/audit.py` from the RAW files in `data/raw/`. Numbers are measured, not assumed.", "",
         "## 1. Acquisition & provenance", "", "| file | source | size (B) | records | sha256 (first 12) | retrieved (UTC) | nature |", "|---|---|---|---|---|---|---|"]
    for k, v in a["manifest_summary"].items():
        L.append(f"| `{k}` | {v['source']} | {v['size_bytes']:,} | {v['record_count']} | `{v['sha256'][:12]}` | {v['retrieved_at_utc']} | {v['nature'][:60]} |")
    L += ["", f"Download failures: {a['download_failures'] or 'none'}", ""]
    sh = a["synthetic_hospital"]
    L += ["## 2. Dataset A - Synthetic Hospital (synthetic)", "", "### Tables",
          "| table | rows | duplicate rows | duplicate keys |", "|---|---|---|---|"]
    for t, v in sh["tables"].items():
        L.append(f"| {t} | {v['rows']:,} | {v.get('exact_duplicate_rows')} | {v.get('duplicate_keys', '-')} |")
    L += ["", "Columns with any nulls (null %):", ""]
    for t, v in sh["tables"].items():
        nn = {c: m["null_pct"] for c, m in v["columns"].items() if m["null_pct"] > 0}
        if nn:
            L.append(f"- `{t}`: {nn}")
    L += ["", "### Identifier / foreign-key checks (violation counts; 0 = clean)", _kv(sh["foreign_keys_and_identifiers"]), "",
          "### JSONL vs SQLite", _kv(sh["jsonl"]), "", "### Official splits (patient level)", _kv(sh["official_splits"]), "",
          "### Temporal semantics", _kv(sh["temporal"]), "", "### Notes & actionable language", _kv({k: v for k, v in sh["notes"].items() if k != "section_type_counts"}),
          f"- **section_type_counts**: {sh['notes']['section_type_counts']}", "", "Rule-based scan for directive/action candidates:", _kv(sh["actionable_language"]), "",
          "**Limitations:**", *[f"- {x}" for x in sh["limitations"]], ""]
    sy = a["synthea"]
    L += ["## 3. Dataset B - Synthea sample (synthetic)", "", "| csv | rows | duplicate rows |", "|---|---|---|"]
    for t, v in sy["tables"].items():
        L.append(f"| {t} | {v['rows']:,} | {v.get('exact_duplicate_rows')} |")
    L += ["", "### FK checks (violations)", _kv(sy["foreign_keys_and_identifiers"]), "", "### Temporal semantics", _kv(sy["temporal"]), "",
          f"### FHIR R4 resource counts\n{sy['fhir_r4_resource_counts']}", "", f"Resource types **absent** from this release: {sy['resources_absent_in_this_release']}", "",
          f"**{sy['missing_event_types_requiring_synthetic_layer']}**", "", "### Notes", _kv(sy["notes"]), ""]
    m = a["mts_dialog"]
    L += ["## 4. Dataset C - MTS-Dialog", "", "| file | rows | dup rows | null % (section_text/dialogue) |", "|---|---|---|---|"]
    for t, v in m["files"].items():
        L.append(f"| {t} | {v['rows']} | {v.get('exact_duplicate_rows')} | {v['columns']['section_text']['null_pct']}/{v['columns']['dialogue']['null_pct']} |")
    L += ["", f"Section headers: {m['section_header_counts']}", "", _kv({k: v for k, v in m.items() if k in ("id_unique_across_files", "dialogue_duplicates_within_all", "dialogue_overlap_with_train", "warning", "temporal")}), "",
          "Actionable candidates in section summaries:", _kv(m["actionable_language_in_section_summaries"]), "", "Actionable candidates in doctor turns:",
          _kv(m["actionable_language_in_doctor_turns"]), ""]
    ac = a["aci_bench"]
    L += ["## 5. Dataset E - ACI-Bench", "", "| file | rows |", "|---|---|"] + [f"| {t} | {v['rows']} |" for t, v in ac["files"].items()]
    L += ["", f"Duplicate notes: {ac['duplicate_notes']}; license: {ac['license']}", "", "Actionable candidates in notes:", _kv(ac["actionable_language_in_notes"]),
          "", "Actionable candidates in doctor turns:", _kv(ac["actionable_language_in_doctor_turns"]), ""]
    ns = a["noshow"]
    L += ["## 6. Dataset D - Medical Appointment No Shows (real, de-identified)", "", f"Rows: {ns['profile']['rows']:,}; duplicate rows: {ns['profile']['exact_duplicate_rows']}; duplicate AppointmentID: {ns['profile'].get('duplicate_keys')}",
          "", "| column | dtype | null % |", "|---|---|---|"] + [f"| {c} | {v['dtype']} | {v['null_pct']} |" for c, v in ns["profile"]["columns"].items()]
    L += ["", "### Date semantics", _kv(ns["date_semantics"]), "", "### Value checks", _kv(ns["value_checks"]), "", f"**Label semantics:** {ns['label_semantics']}", f"**SMS:** {ns['sms_received_note']}", ""]
    return "\n".join(L)


def run(cfg=None):
    return build(cfg)


if __name__ == "__main__":
    run()
