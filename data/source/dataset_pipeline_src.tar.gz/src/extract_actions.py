"""Dataset 1 - clinical action classification (silver weak labels, gold ingestion, review queue).

Also emits `obligation_seeds` (documented/extracted obligations used by generate_scenarios).

Label tiers
  gold      only rows present in data/annotations/reviewed/*.csv with reviewer_id + reviewed_at (human review)
  silver    rule-proposed (src/action_rules.py) or structured-order derived; NEVER reviewed
  synthetic explicitly generated text (none produced here; reserved for generate_scenarios)
"""
from __future__ import annotations

import re
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer

from .action_rules import CATEGORY_ORDER, parse_due_days, propose
from .common import ROOT, cfg_path, get_logger, load_config, stable_uniform, write_json, write_table
from .schemas import ACTION_CATEGORIES, ALL_CATEGORIES

log = get_logger("extract_actions")

ABBR = r"(?<!\bDr)(?<!\bMr)(?<!\bMrs)(?<!\bMs)(?<!\bvs)(?<!\bSt)(?<!\bNo)(?<!\bapprox)(?<!\bq\.d)(?<!\b[A-Z])"
SENT_SPLIT = re.compile(ABBR + r"[.!?]+(?=\s+(?:[A-Z0-9•\[\(]|\-\s))|\n+")

SH_PLAN_SECTIONS = {"plan", "assessment"}
SH_NARR_SECTIONS = {"hpi", "imaging", "other_studies", "pathology"}
ACI_SKIP = ("PHYSICAL EXAM", "REVIEW OF SYSTEMS", "VITALS", "ALLERGIES", "FAMILY", "SOCIAL", "MEDICATIONS", "SURGICAL", "PAST MEDICAL", "EXAM")
ACI_PLAN = ("ASSESSMENT", "PLAN", "INSTRUCTIONS", "DISPOSITION")
MTS_PLAN_HDR = {"PLAN", "DISPOSITION", "ASSESSMENT", "EDCOURSE", "PROCEDURES", "DIAGNOSIS"}
HEADER_RE = re.compile(r"^[A-Z][A-Z0-9 &/,\-\(\)]{3,60}$")


def split_sentences(text: str, offset: int = 0):
    """Yield (sentence, start, end) char offsets relative to the original string."""
    pos = 0
    for m in list(SENT_SPLIT.finditer(text)) + [None]:
        end = m.end() if m else len(text)
        seg_end = m.start() + (1 if (m and text[m.start()] in ".!?") else 0) if m else len(text)
        seg = text[pos:seg_end]
        lead = len(seg) - len(seg.lstrip(" \t-•*"))
        s = seg.strip(" \t-•*")
        if len(s) >= 6:
            yield s, offset + pos + lead, offset + pos + lead + len(s)
        pos = end


DIALOGUE_SPLIT = re.compile(r"(?<=[.?!])\s+")


def split_dialogue(text: str, offset: int = 0):
    pos = 0
    for m in list(DIALOGUE_SPLIT.finditer(text)) + [None]:
        end = m.end() if m else len(text)
        seg = text[pos:(m.start() if m else len(text))]
        lead = len(seg) - len(seg.lstrip())
        sg = seg.strip()
        if len(sg) >= 6:
            yield sg, offset + pos + lead, offset + pos + lead + len(sg)
        pos = end


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", "", re.sub(r"\s+", " ", s.lower())).strip()


def _keep_negative(key: str, p: float) -> bool:
    return stable_uniform(key, "neg_sampling") < p


def _emit(rows, *, source, split, official, group, note_id, enc_id, kind, section, sec_kind, sent, s, e, stratum, neg_p):
    pr = propose(sent, sec_kind)
    labeled = bool(pr.labels)
    keep = labeled or pr.tense == "historical" or sec_kind in ("plan",) or pr.needs_review
    if not keep:
        keep = _keep_negative(f"{note_id}:{s}", neg_p)
        if not keep:
            return
    rows.append(dict(
        example_id=f"{note_id}#{section}@{s}", source_dataset=source, split=split, official_split=official, group_id=group,
        patient_id=group, note_id=note_id, encounter_id=enc_id, text_kind=kind, section=section, section_kind=sec_kind,
        text=sent, char_start=s, char_end=e, labels=pr.labels if labeled else ["no_action"], rules=pr.rules,
        evidence_spans={c: [int(a), int(b)] for c, (a, b) in pr.spans.items()}, tense=pr.tense, confidence=pr.confidence,
        due_phrase=pr.due_phrase, needs_review=pr.needs_review, review_reason=pr.review_reason,
        sampling_stratum=stratum, span_basis=("section_text" if source == "synthetic_hospital" else "note_text"), label_tier="silver",
        label_method="rule_v1" if labeled else ("rule_v1_negative_historical" if pr.tense == "historical" else "rule_v1_negative_default"),
    ))


def build_segments(cfg, interim: Path) -> pd.DataFrame:
    notes = pd.read_parquet(interim / "notes.parquet")
    secs = pd.read_parquet(interim / "note_sections.parquet")
    neg_p = 0.06
    rows: list[dict] = []
    # ---- Synthetic Hospital: section-level text
    nn = notes[notes.source_dataset == "synthetic_hospital"].set_index("note_id")
    secs = secs[secs.section_type.isin(SH_PLAN_SECTIONS | SH_NARR_SECTIONS)]
    for r in secs.itertuples():
        n = nn.loc[r.note_id]
        sk = "plan" if r.section_type in SH_PLAN_SECTIONS else "narrative"
        for sent, s, e in split_sentences(r.text):
            _emit(rows, source="synthetic_hospital", split=n.split, official=n.official_split, group=n.patient_id,
                  note_id=r.note_id, enc_id=n.encounter_id, kind="clinical_note", section=r.section_type, sec_kind=sk,
                  sent=sent, s=s, e=e, stratum=f"sh_{sk}", neg_p=neg_p)
    # ---- ACI-Bench: clinician-authored note sections + doctor dialogue turns
    for n in notes[(notes.source_dataset == "aci_bench")].itertuples():
        if n.text_kind == "visit_note":
            cur, sk, skip, pos = "UNSECTIONED", "narrative", False, 0
            for line in n.text.split("\n"):
                ls = line.strip()
                if HEADER_RE.match(ls):
                    cur = ls
                    skip = any(k in ls for k in ACI_SKIP) and "PLAN" not in ls
                    sk = "plan" if any(k in ls for k in ACI_PLAN) else "narrative"
                elif ls and not skip:
                    for sent, s, e in split_sentences(line, pos):
                        _emit(rows, source="aci_bench", split=n.split, official=n.official_split, group=n.patient_id,
                              note_id=n.note_id, enc_id=None, kind="visit_note", section=cur, sec_kind=sk, sent=sent, s=s, e=e,
                              stratum=f"aci_note_{sk}", neg_p=neg_p)
                pos += len(line) + 1
        else:
            pos = 0
            for line in n.text.split("\n"):
                m = re.match(r"\s*\[doctor\]\s*(.*)", line, re.I)
                if m:
                    off = pos + line.lower().index("[doctor]") + len("[doctor]")
                    for sent, s, e in split_dialogue(m.group(1), pos + line.index(m.group(1), line.lower().index("[doctor]") + 8)):
                        _emit(rows, source="aci_bench", split=n.split, official=n.official_split, group=n.patient_id,
                              note_id=n.note_id, enc_id=None, kind="dialogue", section="doctor_turn", sec_kind="dialogue_doctor",
                              sent=sent, s=s, e=e, stratum="aci_doctor_turn", neg_p=0.03)
                pos += len(line) + 1
    # ---- MTS-Dialog: human section summaries + doctor dialogue turns (section labels are NOT action labels)
    for n in notes[notes.source_dataset == "mts_dialog"].itertuples():
        if n.text_kind == "section_summary":
            sk = "plan" if n.section in MTS_PLAN_HDR else "narrative"
            for sent, s, e in split_sentences(n.text):
                _emit(rows, source="mts_dialog", split=n.split, official=n.official_split, group=n.patient_id,
                      note_id=n.note_id, enc_id=None, kind="section_summary", section=n.section, sec_kind=sk, sent=sent, s=s, e=e,
                      stratum=f"mts_summary_{sk}", neg_p=0.25)
        else:
            pos = 0
            for line in n.text.split("\n"):
                m = re.match(r"\s*(Doctor|Guest_clinician|Clinician)\s*:\s*(.*)", line, re.I)
                if m:
                    off = pos + m.start(2)
                    for sent, s, e in split_dialogue(m.group(2), off):
                        _emit(rows, source="mts_dialog", split=n.split, official=n.official_split, group=n.patient_id,
                              note_id=n.note_id, enc_id=None, kind="dialogue", section=n.section, sec_kind="dialogue_doctor",
                              sent=sent, s=s, e=e, stratum="mts_doctor_turn", neg_p=0.10)
                pos += len(line) + 1
    # ---- Synthea: plan lines (record-style statements; unique texts only)
    syn = notes[notes.source_dataset == "synthea"]
    seen: set[str] = set()
    for n in syn.itertuples():
        m = re.search(r"## Plan\n(.*)$", n.text, re.S)
        if not m:
            continue
        header = None
        for line in m.group(1).split("\n"):
            ls = line.strip()
            if not ls:
                continue
            if not ls.startswith("-"):
                header = ls
                continue
            if header is None:
                continue
            stmt = f"{header} {ls[1:].strip()}"
            key = _norm(stmt)
            if key in seen:
                continue
            seen.add(key)
            h = header.lower()
            if "prescribed" in h:
                labels, tense, rule = ["medication_action"], "record", "synthea_prescribed"
            elif "careplan" in h:
                labels, tense, rule = ["other_action"], "record", "synthea_careplan"
            else:
                labels, tense, rule = ["no_action"], "record", "synthea_completed_record"
            rows.append(dict(
                example_id=f"{n.note_id}@{len(seen)}", source_dataset="synthea", split=n.split, official_split=None,
                group_id=n.patient_id, patient_id=n.patient_id, note_id=n.note_id, encounter_id=n.encounter_id,
                text_kind="clinical_note", section="plan", section_kind="synthea_plan", span_basis="derived_statement", text=stmt, char_start=0, char_end=len(stmt),
                labels=labels, rules=[rule] if labels != ["no_action"] else [], evidence_spans={}, tense=tense,
                confidence=0.9 if labels != ["no_action"] else 0.8, due_phrase=None, needs_review=False, review_reason=None,
                sampling_stratum="synthea_plan_record_unique", label_tier="silver", label_method="synthea_template_rule"))
    df = pd.DataFrame(rows)
    log.info("segments: %d  (positives %d)", len(df), int((df.labels.map(lambda x: x != ["no_action"])).sum()))
    return df


def apply_gold(df: pd.DataFrame, reviewed_dir: Path) -> tuple[pd.DataFrame, int]:
    """Overlay human-reviewed labels. Required columns: example_id, labels ('|' separated), reviewer_id, reviewed_at."""
    files = sorted(reviewed_dir.glob("*.csv"))
    n_gold = 0
    df["reviewer_id"] = None
    df["reviewed_at"] = None
    for f in files:
        rv = pd.read_csv(f)
        need = {"example_id", "labels", "reviewer_id", "reviewed_at"}
        if not need.issubset(rv.columns):
            log.warning("skipping %s: missing columns %s", f.name, need - set(rv.columns))
            continue
        rv = rv.dropna(subset=["labels", "reviewer_id", "reviewed_at"])
        rv = rv[rv.labels.str.split("|").map(lambda ls: all(l in ALL_CATEGORIES for l in ls))]
        m = df.example_id.isin(rv.example_id)
        idx = rv.drop_duplicates("example_id", keep="last").set_index("example_id")
        for i in df.index[m]:
            r = idx.loc[df.at[i, "example_id"]]
            df.at[i, "labels"] = r["labels"].split("|")
            df.at[i, "label_tier"] = "gold"
            df.at[i, "label_method"] = f"human_review:{f.name}"
            df.at[i, "reviewer_id"] = r["reviewer_id"]
            df.at[i, "reviewed_at"] = r["reviewed_at"]
        n_gold += int(m.sum())
    return df, n_gold


def flag_duplicates(df: pd.DataFrame, max_cos: float) -> pd.DataFrame:
    """Exact and near-duplicate detection across splits with precedence train > validation > test:
    a row is excluded if its text (exact) or a near-duplicate (TF-IDF cosine >= max_cos) occurs in a higher-precedence split."""
    df["norm_text"] = df.text.map(_norm)
    rank = df.split.map({"train": 0, "validation": 1, "test": 2}).values
    min_rank = df.assign(_r=rank).groupby("norm_text")["_r"].transform("min").values
    df["exact_dup_across_splits"] = df.groupby("norm_text")["split"].transform("nunique").values > 1
    df["exact_dup_of_train"] = (rank > min_rank)          # name kept for backward compat: duplicate of a higher-precedence split
    vec = TfidfVectorizer(ngram_range=(1, 2), min_df=2, sublinear_tf=True)
    X = vec.fit_transform(df.norm_text)
    best = np.zeros(len(df), dtype=np.float32)
    for hi, lo_set in ((0, (1, 2)), (1, (2,))):
        src = np.where(rank == hi)[0]
        tgt = np.where(np.isin(rank, lo_set))[0]
        Xs = X[src].T.tocsr()
        for i in range(0, len(tgt), 2000):
            idx = tgt[i:i + 2000]
            sim = (X[idx] @ Xs).tocsr()
            best[idx] = np.maximum(best[idx], sim.max(axis=1).toarray().ravel())
    df["max_cosine_to_train"] = best          # max cosine to any higher-precedence split
    df["near_dup_of_train"] = (rank > 0) & (best >= max_cos)
    df["excluded_leakage"] = df.exact_dup_of_train | df.near_dup_of_train
    return df


def explode_multi_hot(df: pd.DataFrame) -> pd.DataFrame:
    for c in ALL_CATEGORIES:
        df[f"y_{c}"] = df.labels.map(lambda ls, c=c: int(c in ls))
    return df


def build_review_queue(df: pd.DataFrame, seed: int, n_random: int = 400) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    uncertain = df[(df.needs_review) & (df.label_tier == "silver") & (~df.excluded_leakage)]
    pool = df[(df.label_tier == "silver") & (~df.excluded_leakage) & (~df.example_id.isin(uncertain.example_id))]
    # stratified random audit sample: per (source, label-group) so precision/recall can be estimated per stratum
    pool = pool.assign(_grp=pool.labels.map(lambda l: l[0]))
    samp = pool.groupby(["source_dataset", "_grp"], group_keys=False).apply(
        lambda g: g.sample(min(len(g), max(2, n_random // 24)), random_state=int(rng.integers(1 << 30))))
    q = pd.concat([uncertain.sample(min(len(uncertain), 300), random_state=seed), samp]).drop_duplicates("example_id")
    q = q[["example_id", "source_dataset", "split", "section", "text", "labels", "rules", "confidence", "review_reason"]].copy()
    q["proposed_labels"] = q.labels.map("|".join)
    q = q.drop(columns=["labels"])
    q["rules"] = q.rules.map("|".join)
    q["review_reason"] = q.review_reason.fillna("random_audit_sample")
    for c in ("labels", "reviewer_id", "reviewed_at", "reviewer_comment"):
        q[c] = ""
    return q.sort_values(["review_reason", "example_id"]).reset_index(drop=True)


# ---------------------------------------------------------------------------------------------
# synthetic tier: explicitly generated template sentences (TRAIN-ONLY augmentation, separate file)
# ---------------------------------------------------------------------------------------------
_SLOTS = {
    "lab": ["CBC", "basic metabolic panel", "hemoglobin A1c", "lipid panel", "TSH", "urinalysis", "liver function tests", "INR", "urine culture", "serum creatinine"],
    "img": ["chest x-ray", "CT of the abdomen", "MRI of the brain", "renal ultrasound", "echocardiogram", "screening mammogram", "DEXA scan", "venous doppler"],
    "proc": ["colonoscopy", "skin biopsy", "cardiac catheterization", "upper endoscopy", "knee arthroscopy", "cataract surgery", "lumbar puncture"],
    "spec": ["cardiology", "neurology", "gastroenterology", "endocrinology", "dermatology", "nephrology", "physical therapy", "oncology", "ophthalmology"],
    "drug": ["lisinopril 10 mg daily", "metformin 500 mg twice daily", "atorvastatin 40 mg nightly", "amoxicillin 500 mg three times daily", "prednisone 20 mg daily",
             "insulin glargine 12 units at bedtime", "sertraline 50 mg daily", "furosemide 20 mg daily"],
    "when": ["in 48 hours", "within 1 week", "in 2 weeks", "in 3 months", "next week", "in 6 weeks", "within 24 hours", "in 4 days"],
    "who": ["the patient", "her", "him", "the family"],
    "unit": ["medical floor", "telemetry unit", "intensive care unit", "observation unit"],
    "life": ["a low-sodium diet", "daily walking", "smoking cessation", "weight loss", "regular exercise", "a diabetic diet"],
    "avoid": ["heavy lifting", "alcohol", "NSAIDs", "prolonged standing", "driving"],
}
_SYN = {
    "laboratory_test": ["We will order a {lab} {when}.", "Please have a {lab} drawn {when}.", "Repeat the {lab} {when}.", "I would like to recheck a {lab} {when}.", "Order {lab} and review the results."],
    "imaging": ["Schedule a {img} {when}.", "We will obtain a {img} to evaluate this further.", "Order a {img} before the next visit.", "A {img} is ordered for {when}."],
    "procedure": ["Plan {proc} {when}.", "We recommend proceeding with a {proc}.", "A {proc} will be scheduled {when}.", "Arrange {proc} with the surgical team."],
    "appointment_referral": ["Refer to {spec} for further evaluation.", "I will place a referral to {spec}.", "Schedule an appointment with {spec} {when}.", "Please arrange a {spec} consult."],
    "medication_action": ["Start {drug}.", "Continue {drug} and reassess dosing.", "Increase the dose of {drug}.", "Stop the current medication and begin {drug}.", "Refill {drug}."],
    "patient_communication": ["Call {who} with the test results {when}.", "Notify {who} of the abnormal result.", "Instruct {who} to call us if symptoms worsen.", "Advise {who} to return if the pain persists."],
    "followup_review": ["Follow up {when}.", "Recheck {when} to reassess.", "Return to clinic {when} for review.", "Reassess the response {when}."],
    "other_action": ["Admit to the {unit} for observation.", "Encourage {life}.", "Avoid {avoid} and rest.", "Discharge home with supportive care and instructions to avoid {avoid}.",
                     "We recommend {life} and will admit to the {unit} if she worsens."],
    "no_action": ["The {lab} was normal last year.", "{who} denies any chest pain.", "The {img} showed no acute abnormality.", "What medications are you taking at home?",
                  "The risks of {proc} include bleeding and infection.", "She was previously seen by {spec} and was started on {drug}.", "The patient has a history of hypertension."],
}


def build_synthetic(seed: int, eval_texts: list[str], max_cos: float, per_class: int = 90) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    rows, seen = [], set()
    for cat, temps in _SYN.items():
        tries = 0
        n = 0
        while n < (per_class if cat != "no_action" else per_class * 2) and tries < 5000:
            tries += 1
            t = temps[int(rng.integers(len(temps)))]
            text = re.sub(r"\{(\w+)\}", lambda m: _SLOTS[m.group(1)][int(rng.integers(len(_SLOTS[m.group(1)])))], t)
            text = text[0].upper() + text[1:]
            if _norm(text) in seen:
                continue
            seen.add(_norm(text))
            n += 1
            rows.append(dict(example_id=f"synthetic:{cat}:{n}", source_dataset="synthetic_templates", split="train", official_split=None,
                             group_id=f"synthetic:{cat}:{n}", patient_id=f"synthetic:{cat}:{n}", note_id=None, encounter_id=None, text_kind="template_sentence",
                             section=None, section_kind="synthetic", text=text, char_start=0, char_end=len(text), labels=[cat], rules=[], evidence_spans={},
                             tense="directive" if cat != "no_action" else "record", confidence=1.0, due_phrase=None, needs_review=False, review_reason=None,
                             sampling_stratum="synthetic_template", span_basis="derived_statement", label_tier="synthetic", label_method="template_v1"))
    df = pd.DataFrame(rows)
    # drop any synthetic row that is a near-duplicate of a real evaluation text (never let templates shadow eval data)
    if len(df) and eval_texts:
        vec = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True).fit(list(df.text.map(_norm)) + eval_texts)
        sim = (vec.transform(df.text.map(_norm)) @ vec.transform(eval_texts).T).max(axis=1).toarray().ravel()
        df = df[sim < max_cos].reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------------------------
# obligation seeds
# ---------------------------------------------------------------------------------------------
ROLE_BY_CAT = {
    "laboratory_test": "ordering_clinician", "imaging": "ordering_clinician", "procedure": "specialist",
    "appointment_referral": "scheduler", "medication_action": "ordering_clinician",
    "patient_communication": "nurse", "followup_review": "ordering_clinician", "other_action": "ordering_clinician"}
DEFAULT_DUE_DAYS = {"laboratory_test": 7, "imaging": 14, "procedure": 30, "appointment_referral": 30, "medication_action": 14,
                    "patient_communication": 3, "followup_review": 30, "other_action": 14}


def _desc_from(text: str, cat: str) -> str:
    return re.sub(r"\s+", " ", text).strip()[:280]


def build_seeds(df: pd.DataFrame, interim: Path) -> pd.DataFrame:
    """Obligation seeds: text-extracted (silver), structured SH imaging orders, SH/Synthea documented lab results,
    Synthea care plans & medication starts."""
    enc = pd.read_parquet(interim / "encounters.parquet").set_index("encounter_id")
    pats = pd.read_parquet(interim / "patients.parquet").set_index("patient_id")
    seeds = []

    def seed(**kw):
        kw.setdefault("evidence_text", None)
        kw.setdefault("evidence_span", None)
        seeds.append(kw)

    # (a) text-extracted directive sentences from plan sections / directive narratives
    pos = df[(df.tense == "directive") & (df.confidence >= 0.55) & (df.label_tier != "gold") & (~df.excluded_leakage if "excluded_leakage" in df else True)]
    pos = pos[pos.labels.map(lambda l: l != ["no_action"])]
    for r in pos.itertuples():
        if r.source_dataset == "synthea":
            continue
        cat = r.labels[0] if r.labels else "other_action"
        if cat in ("patient_communication", "other_action") and r.confidence < 0.7:
            continue
        due = parse_due_days(r.due_phrase)
        if r.encounter_id and r.encounter_id in enc.index:
            created = enc.at[r.encounter_id, "event_time_utc"]
            tp = enc.at[r.encounter_id, "time_precision"]
        else:   # MTS / ACI: no timeline in source -> deterministic simulated anchor, flagged
            u = stable_uniform(r.group_id, "visit_anchor")
            created = (pd.Timestamp("2022-01-03T09:00:00Z") + pd.Timedelta(days=int(u * 700))).strftime("%Y-%m-%dT%H:%M:%SZ")
            tp = "simulated"
        seed(source_dataset=r.source_dataset, patient_id=r.patient_id, encounter_id=r.encounter_id, note_id=r.note_id,
             seed_kind="text_extracted", category=cat, secondary_categories=r.labels[1:], description=_desc_from(r.text, cat),
             evidence_text=r.text, evidence_span=[int(r.char_start), int(r.char_end)], created_time_utc=created,
             created_time_precision=tp, due_days=due if due is not None else float(DEFAULT_DUE_DAYS[cat]),
             due_imputed=due is None, responsible_role=ROLE_BY_CAT[cat], extraction_confidence=float(r.confidence),
             annotation_provenance="rule_v1", label_tier="silver", split=r.split, source_ref=r.example_id)

    # (b) structured SH imaging orders (documented in benchmark_v1.3.db.imaging_orders)
    io_path = interim / "sh_imaging_orders.parquet"
    if io_path.exists():
        io = pd.read_parquet(io_path)
        prio_days = {"stat": 0.25, "urgent": 2.0, "routine": 21.0}
        for r in io.itertuples():
            eid = f"sh:E{r.encounter_id}"
            if eid not in enc.index:
                continue
            pid = enc.at[eid, "patient_id"]
            seed(source_dataset="synthetic_hospital", patient_id=pid, encounter_id=eid, note_id=r.note_id, seed_kind="structured_order",
                 category="imaging", secondary_categories=[],
                 description=f"{r.modality} {str(r.body_region).replace('_', ' ')} - {r.clinical_indication}",
                 created_time_utc=f"{str(r.order_datetime)[:10]}T09:00:00Z", created_time_precision="date",
                 due_days=prio_days.get(str(r.order_priority).lower(), 14.0), due_imputed=True, responsible_role="ordering_clinician",
                 extraction_confidence=1.0, annotation_provenance=f"benchmark_imaging_order(priority={r.order_priority})",
                 label_tier="silver", split=pats.at[pid, "split"], source_ref=f"sh:ev:imo{r.order_id}")
    # (c) documented lab results (SH note labs section; Synthea laboratory observations) -> result review obligations
    ev = pd.read_parquet(interim / "source_events.parquet")
    labs = ev[ev.event_type.isin(["lab_result_documented", "lab_result_available"])].copy()
    labs["day"] = labs.timestamp_utc.str[:10]
    g = labs.groupby(["patient_id", "encounter_id"], sort=True).agg(
        n=("event_id", "size"), ts=("timestamp_utc", "min"), first_event=("event_id", "first"),
        desc=("description", lambda s: "; ".join(sorted(set(map(str, s)))[:3])), tp=("time_precision", "first"),
        src=("source_dataset", "first")).reset_index()
    for r in g.itertuples():
        seed(source_dataset=r.src, patient_id=r.patient_id, encounter_id=r.encounter_id, note_id=None, seed_kind="documented_lab_result",
             category="laboratory_test", secondary_categories=[], description=f"Review laboratory results ({r.n} documented): {r.desc}"[:280],
             created_time_utc=r.ts, created_time_precision=r.tp, due_days=7.0, due_imputed=True,
             responsible_role="ordering_clinician", extraction_confidence=1.0, annotation_provenance="documented_result_event",
             label_tier="silver", split=pats.at[r.patient_id, "split"], source_ref=r.first_event)
    # (d) Synthea care plans (follow-up review) -- documented start; due imputed
    cps = ev[ev.event_type == "careplan_started"]
    for r in cps.itertuples():
        # care plan START is date-only: never place it earlier than its encounter
        enc_t = enc.at[r.encounter_id, "event_time_utc"] if r.encounter_id in enc.index else r.timestamp_utc
        seed(source_dataset="synthea", patient_id=r.patient_id, encounter_id=r.encounter_id, note_id=None, seed_kind="documented_careplan",
             category="followup_review", secondary_categories=[], description=f"Care plan follow-up: {r.description}"[:280],
             created_time_utc=max(r.timestamp_utc, enc_t), created_time_precision="date", due_days=30.0, due_imputed=True,
             responsible_role="ordering_clinician", extraction_confidence=1.0, annotation_provenance="documented_careplan_event",
             label_tier="silver", split=pats.at[r.patient_id, "split"], source_ref=r.event_id)
    out = pd.DataFrame(seeds)
    out.insert(0, "seed_id", [f"seed{i:06d}" for i in range(len(out))])
    out["secondary_categories"] = out.secondary_categories.map(lambda x: list(x))
    return out


def run(cfg=None):
    cfg = cfg or load_config()
    interim, out = cfg_path(cfg, "interim"), cfg_path(cfg, "processed") / "action_classification"
    out.mkdir(parents=True, exist_ok=True)
    rev_dir = cfg_path(cfg, "reviewed_annotations")
    seg = build_segments(cfg, interim)
    seg["silver_labels"] = seg.labels.map(list)        # keep the rule proposal; gold review may overwrite `labels`
    seg, n_gold = apply_gold(seg, rev_dir)
    seg = flag_duplicates(seg, cfg["thresholds"]["max_near_dup_cosine"])
    seg = explode_multi_hot(seg)
    seg["evidence_spans"] = seg.evidence_spans.map(lambda d: str(d))
    seg["labels_str"] = seg.labels.map("|".join)
    seg["rules"] = seg.rules.map(lambda x: list(x))
    review = build_review_queue(seg, cfg["seed"])
    review.to_csv(out / "review_queue.csv", index=False)

    keep = seg[~seg.excluded_leakage].copy()
    cols_drop = ["norm_text"]
    for sp in ("train", "validation", "test"):
        write_table(keep[keep.split == sp].drop(columns=cols_drop), out / f"{sp}", csv_sample=200)
    write_table(seg.drop(columns=cols_drop), out / "all_with_exclusions", csv_sample=200)
    syn_df = build_synthetic(cfg["seed"], list(keep.loc[keep.split != "train", "norm_text"]), cfg["thresholds"]["max_near_dup_cosine"])
    syn_df = explode_multi_hot(syn_df.assign(labels=syn_df.labels.map(list)))
    syn_df["labels_str"] = syn_df.labels.map("|".join)
    syn_df["evidence_spans"] = syn_df.evidence_spans.map(str)
    write_table(syn_df, out / "synthetic_train_augmentation", csv_sample=100)
    gold = keep[keep.label_tier == "gold"]
    write_table(gold.drop(columns=cols_drop), out / "gold", csv_sample=None) if len(gold) else None
    seeds = build_seeds(seg, interim)
    write_table(seeds, interim / "obligation_seeds")
    stats = {
        "n_segments_all": int(len(seg)), "n_after_leakage_exclusion": int(len(keep)),
        "n_excluded_exact_dup_of_train": int(seg.exact_dup_of_train.sum()), "n_excluded_near_dup_of_train": int(seg.near_dup_of_train.sum()),
        "n_gold": int(n_gold), "n_synthetic_train_augmentation": int(len(syn_df)), "n_review_queue": int(len(review)), "n_seeds": int(len(seeds)),
        "seeds_by_kind": seeds.seed_kind.value_counts().to_dict(), "seeds_by_source": seeds.source_dataset.value_counts().to_dict(),
        "by_split": keep.split.value_counts().to_dict(),
        "by_source": keep.source_dataset.value_counts().to_dict(),
        "positive_fraction_by_source": {s: float((g.labels_str != "no_action").mean()) for s, g in keep.groupby("source_dataset")},
        "label_counts": {c: int(keep[f"y_{c}"].sum()) for c in ALL_CATEGORIES},
        "label_counts_by_split": {sp: {c: int(g[f"y_{c}"].sum()) for c in ALL_CATEGORIES} for sp, g in keep.groupby("split")},
        "tier_counts": keep.label_tier.value_counts().to_dict(),
    }
    write_json(stats, interim / "action_stats.json")
    log.info("action dataset: %s", {k: v for k, v in stats.items() if k in ("n_segments_all", "n_after_leakage_exclusion", "n_gold", "n_seeds")})
    return stats


if __name__ == "__main__":
    run()
