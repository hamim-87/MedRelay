"""Automated dataset-quality and leakage validation.

Writes reports/dataset_quality.md, reports/leakage_report.md and reports/validation_results.json.
Statuses: PASS / WARN / FAIL. Thresholds come from config.yaml and are never adjusted to force a pass;
known, by-design caveats are reported as WARN with an explanation.
"""
from __future__ import annotations

import json
import re
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import roc_auc_score

from .common import cfg_path, get_logger, load_config, read_json, sha256_file, write_json, ROOT
from .generate_scenarios import COMPLETION_EVENT
from .schemas import ALL_CATEGORIES, ClinicalEvent, EvidenceLink, Obligation, validate_rows

log = get_logger("validate")
RES: list[dict] = []


def rec(cid, name, status, detail, group="quality", metrics=None):
    RES.append(dict(id=cid, name=name, status=status, detail=detail, group=group, metrics=metrics or {}))
    getattr(log, "warning" if status != "PASS" else "info")("%s %-48s %s  %s", cid, name, status, detail[:150])


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9 ]+", "", re.sub(r"\s+", " ", s.lower())).strip()


def load_all(cfg):
    interim = cfg_path(cfg, "interim")
    proc = cfg_path(cfg, "processed")
    D = {}
    D["patients"] = pd.read_parquet(interim / "patients.parquet")
    D["encounters"] = pd.read_parquet(interim / "encounters.parquet")
    D["notes"] = pd.read_parquet(interim / "notes.parquet")
    sc = interim / "scenarios"
    for k in ("obligations", "events", "ground_truth", "evidence_links"):
        D[k] = pd.read_parquet(sc / f"{k}.parquet")
    D["src_events"] = pd.read_parquet(interim / "source_events.parquet")
    g = proc / "evidence_graph"
    D["nodes"] = pd.read_parquet(g / "nodes.parquet")
    D["edges"] = pd.read_parquet(g / "edges.parquet")
    ac = proc / "action_classification"
    D["action"] = {sp: pd.read_parquet(ac / f"{sp}.parquet") for sp in ("train", "validation", "test")}
    D["action_all"] = pd.read_parquet(ac / "all_with_exclusions.parquet")
    fr = proc / "followup_risk"
    D["risk"] = {sp: pd.read_parquet(fr / f"features_{sp}.parquet") for sp in ("train", "validation", "test")}
    D["risk_spec"] = read_json(fr / "feature_spec.json")
    D["risk_hidden"] = pd.read_parquet(fr / "ground_truth_hidden.parquet")
    ns = proc / "appointment_noshow"
    D["noshow"] = pd.read_parquet(ns / "all.parquet")
    es = proc / "event_stream"
    D["stream"] = pd.read_json(es / "event_stream.jsonl", lines=True, dtype=False)
    D["stream_gt"] = pd.read_json(es / "ground_truth_obligations.jsonl", lines=True, dtype=False)
    return D


# ------------------------------------------------------------------------------------------------- checks
def check_required(D, cfg):
    thr = cfg["thresholds"]["max_missing_required_fraction"]
    req = {
        "patients": ["patient_id", "source_dataset", "split", "split_origin"],
        "encounters": ["encounter_id", "patient_id", "source_dataset", "time_precision", "time_imputed", "event_time_utc"],
        "notes": ["note_id", "patient_id", "text", "split", "provenance", "source_dataset"],
        "obligations": ["obligation_id", "patient_id", "category", "description", "responsible_role", "created_time_utc", "due_time_utc",
                        "annotation_provenance", "label_tier", "split", "chain_id"],
        "events": ["event_id", "patient_id", "obligation_id", "event_type", "timestamp_utc", "evidence_source", "status", "provenance"],
        "evidence_links": ["obligation_id", "event_id", "relationship", "match_confidence", "verification_state"],
        "nodes": ["node_id", "node_type", "valid_from_utc", "provenance"], "edges": ["edge_id", "src_id", "dst_id", "edge_type", "valid_from_utc", "provenance"],
        "action_all": ["example_id", "text", "labels", "label_tier", "label_method", "split", "source_dataset"],
        "noshow": [c for c in D["noshow"].columns if c != "days_since_last_appointment"],
    }
    bad = {}
    for t, cols in req.items():
        df = D[t]
        for c in cols:
            frac = float(df[c].isna().mean())
            if frac > thr:
                bad[f"{t}.{c}"] = round(frac, 4)
    rk = pd.concat(D["risk"].values())
    for c in D["risk_spec"]["meta_columns"] + ["outcome_label"]:
        if rk[c].isna().any():
            bad[f"risk.{c}"] = float(rk[c].isna().mean())
    nullable_by_design = {c: round(float(rk[c].isna().mean()), 3) for c in D["risk_spec"]["feature_columns"] if rk[c].isna().any()}
    rec("Q01", "missing required values", "FAIL" if bad else "PASS",
        f"violations: {bad}" if bad else f"all required columns complete in {len(req)} tables; features NaN by design: {nullable_by_design}",
        metrics={"nullable_by_design_risk_features": nullable_by_design})


def check_schemas(D):
    errs = {}
    for name, df, model in (("obligations", D["obligations"], Obligation), ("events", D["events"], ClinicalEvent), ("evidence_links", D["evidence_links"], EvidenceLink)):
        e = validate_rows(df.assign(**({"event_id": df.event_id} if name == "events" else {})), model, sample=3000)
        if e:
            errs[name] = e[:2]
    rec("Q16", "pydantic schema validation (obligations, events, evidence links)", "FAIL" if errs else "PASS", f"errors: {errs}" if errs else "3000-row samples of each table satisfy the canonical schemas")


def check_pk(D):
    keys = {"patients": "patient_id", "encounters": "encounter_id", "notes": "note_id", "obligations": "obligation_id", "events": "event_id",
            "ground_truth": "obligation_id", "nodes": "node_id", "edges": "edge_id", "action_all": "example_id", "noshow": "appointment_id",
            "src_events": "event_id"}
    bad = {t: int(D[t][k].duplicated().sum()) for t, k in keys.items() if D[t][k].duplicated().any()}
    risk = pd.concat(D["risk"].values())
    if risk.obligation_id.duplicated().any():
        bad["risk.obligation_id"] = int(risk.obligation_id.duplicated().sum())
    st = D["stream"]
    if st.delivery_id.duplicated().any():
        bad["stream.delivery_id"] = int(st.delivery_id.duplicated().sum())
    rec("Q02", "unique primary keys", "FAIL" if bad else "PASS", f"duplicates: {bad}" if bad else f"{len(keys) + 2} key sets unique")


def check_fk(D):
    P, E, O, V, L, G = D["patients"], D["encounters"], D["obligations"], D["events"], D["evidence_links"], D["ground_truth"]
    N = D["notes"]
    bad = {
        "encounters->patients": int((~E.patient_id.isin(P.patient_id)).sum()),
        "notes->patients": int((~N.patient_id.isin(P.patient_id)).sum()),
        "notes->encounters(non-null)": int((~N.encounter_id.dropna().isin(E.encounter_id)).sum()),
        "obligations->patients": int((~O.patient_id.isin(P.patient_id)).sum()),
        "obligations->encounters(non-null)": int((~O.encounter_id.dropna().isin(E.encounter_id)).sum()),
        "obligations->notes(non-null)": int((~O.note_id.dropna().isin(N.note_id)).sum()),
        "events->obligations": int((~V.obligation_id.isin(O.obligation_id)).sum()),
        "events->patients": int((~V.patient_id.isin(P.patient_id)).sum()),
        "links->events": int((~L.event_id.isin(V.event_id)).sum()),
        "links->obligations": int((~L.obligation_id.isin(O.obligation_id)).sum()),
        "ground_truth->obligations": int((~G.obligation_id.isin(O.obligation_id)).sum()),
        "obligation split == patient split": int((O.split != O.patient_id.map(dict(zip(P.patient_id, P.split)))).sum()),
    }
    deps = {d for ds in O.depends_on for d in ds}
    bad["depends_on->obligations"] = int(len(deps - set(O.obligation_id)))
    ids = set(D["nodes"].node_id)
    bad["edges->nodes"] = int((~(D["edges"].src_id.isin(ids) & D["edges"].dst_id.isin(ids))).sum())
    risk = pd.concat(D["risk"].values())
    bad["risk->obligations"] = int((~risk.obligation_id.isin(O.obligation_id)).sum())
    bad["risk_hidden->risk"] = int((~D["risk_hidden"].obligation_id.isin(risk.obligation_id)).sum())
    bad["stream obligations->obligations"] = int((~D["stream"].obligation_id.dropna().isin(O.obligation_id)).sum())
    bad = {k: v for k, v in bad.items() if v}
    rec("Q03", "valid foreign keys", "FAIL" if bad else "PASS", f"violations: {bad}" if bad else "all FK relations resolve (incl. depends_on, edges, stream, risk)")


def check_chronology(D):
    O, V, st = D["obligations"], D["events"], D["stream"]
    O = O.assign(c=pd.to_datetime(O.created_time_utc, utc=True), d=pd.to_datetime(O.due_time_utc, utc=True))
    V = V.assign(t=pd.to_datetime(V.timestamp_utc, utc=True))
    bad = {"due<created": int((O.d < O.c).sum())}
    m = V.merge(O[["obligation_id", "c", "d"]], on="obligation_id")
    bad["event before obligation created"] = int((m.t < m.c).sum())
    om = O.set_index("obligation_id")
    pairs = [(o, p) for o, ds in zip(O.obligation_id, O.depends_on) for p in ds]
    bad["child deadline <= parent deadline"] = int(sum(om.at[o, "d"] <= om.at[p, "d"] for o, p in pairs))
    et = pd.to_datetime(st.event_time_utc, utc=True)
    it = pd.to_datetime(st.ingest_time_utc, utc=True)
    bad["stream: ingest before event time"] = int((it < et).sum())
    bad["stream: not sorted by ingest time"] = int((it.diff().dt.total_seconds() < 0).sum())
    bad["stream: seq not contiguous"] = int((st.stream_seq.values != np.arange(len(st))).sum())
    ns = D["noshow"]
    bad["noshow: appointment before schedule date"] = int((pd.to_datetime(ns.appointment_date) < pd.to_datetime(ns.scheduled_time_utc.str[:10])).sum())
    bad = {k: v for k, v in bad.items() if v}
    rec("Q04", "chronological ordering", "FAIL" if bad else "PASS", f"violations: {bad}" if bad else "deadlines, event times, dependency deadlines and stream ordering are consistent")


def _comp_times(D):
    O, V = D["obligations"], D["events"]
    ct = O.set_index("obligation_id").step_type.map(COMPLETION_EVENT)
    V = V.assign(t=pd.to_datetime(V.timestamp_utc, utc=True))
    c = V[V.event_type.values == ct.reindex(V.obligation_id).values].groupby("obligation_id").t.min()
    return c.to_dict()


def check_transitions(D):
    O = D["obligations"]
    comp = _comp_times(D)
    V = D["events"].assign(t=pd.to_datetime(D["events"].timestamp_utc, utc=True))
    child_before_parent = parent_missing = 0
    for o, ds in zip(O.obligation_id, O.depends_on):
        if o not in comp:
            continue
        for p in ds:
            if p not in comp:
                parent_missing += 1
            elif comp[o] < comp[p]:
                child_before_parent += 1
    # scheduled-visit steps must be preceded by a scheduling event on the chain
    sched = V[V.event_type == "appointment_scheduled"].merge(O[["obligation_id", "chain_id"]], on="obligation_id")
    first_sched = sched.groupby("chain_id").t.min().to_dict()
    att = V[V.event_type == "visit_attended"].merge(O[["obligation_id", "chain_id"]], on="obligation_id")
    att_before_sched = int(sum((c in first_sched) and (t < first_sched[c]) for c, t in zip(att.chain_id, att.t)))
    att_unsched_doc = int(sum(c not in first_sched for c in att.chain_id))      # scheduling not documented (documentation gap)
    # acknowledgments must be preceded by opening on the same obligation when an open event exists in the type system
    opened = V[V.event_type.isin(["result_opened", "medication_opened"])].groupby("obligation_id").t.min().to_dict()
    ack = V[V.event_type.isin(["result_acknowledged", "medication_acknowledged"])]
    ack_before_open = int(sum((o in opened and t < opened[o]) or (o not in opened) for o, t in zip(ack.obligation_id, ack.t)))
    hard = {"child completed before parent completed": child_before_parent, "visit attended before its scheduling event": att_before_sched,
            "acknowledgment without/before opening": ack_before_open}
    hard = {k: v for k, v in hard.items() if v}
    if hard:
        rec("Q05", "impossible task transitions", "FAIL", f"violations: {hard}")
    elif parent_missing or att_unsched_doc:
        rec("Q05", "impossible task transitions", "WARN",
            f"no hard violations; {parent_missing} child completions have a parent with NO documented completion and {att_unsched_doc} visits have no documented scheduling event "
            f"(by design: 'missing documentation' scenario; those parents are labelled unverified, not completed)",
            metrics={"child_completion_with_undocumented_parent": parent_missing, "visit_without_documented_scheduling": att_unsched_doc})
    else:
        rec("Q05", "impossible task transitions", "PASS", "no impossible transitions")


def check_evidence_before_cause(D):
    O, V = D["obligations"], D["events"]
    V = V.assign(t=pd.to_datetime(V.timestamp_utc, utc=True))
    O2 = O.assign(c=pd.to_datetime(O.created_time_utc, utc=True))
    m = V.merge(O2[["obligation_id", "c"]], on="obligation_id")
    pre = int((m.t < m.c).sum())
    # attended before scheduled appointment time
    appt = {}
    for r in V[V.event_type.isin(["appointment_scheduled", "appointment_rescheduled"])].sort_values("t").itertuples():
        pl = json.loads(r.payload or "{}")
        if "appointment_time" in pl:
            appt[r.obligation_id] = pd.Timestamp(pl["appointment_time"])
    chain = dict(zip(O.obligation_id, O.chain_id))
    appt_by_chain = {}
    for o, t in appt.items():
        appt_by_chain[chain[o]] = t
    early = 0
    for r in V[V.event_type == "visit_attended"].itertuples():
        a = appt_by_chain.get(chain[r.obligation_id])
        if a is not None and r.t < a - pd.Timedelta(minutes=1):
            early += 1
    bad = {"evidence before obligation creation": pre, "visit attended before appointment time": early}
    bad = {k: v for k, v in bad.items() if v}
    rec("Q06", "completion evidence before its cause", "FAIL" if bad else "PASS", f"violations: {bad}" if bad else "no evidence precedes its cause")


def check_graph(D):
    E, N, O = D["edges"], D["nodes"], D["obligations"]
    ntype = dict(zip(N.node_id, N.node_type))
    allowed = {
        "EXTRACTED_FROM": {("ClinicalObligation", "ClinicalNote"), ("ClinicalObligation", "Encounter"), ("EvidenceRecord", "ClinicalEvent")},
        "BELONGS_TO": {("Encounter", "Patient"), ("ClinicalNote", "Encounter"), ("ClinicalNote", "Patient"), ("ClinicalObligation", "Patient"), ("ClinicalEvent", "Patient")},
        "DEPENDS_ON": {("ClinicalObligation", "ClinicalObligation")}, "ASSIGNED_TO": {("ClinicalObligation", "ResponsibleRole")},
        "EVIDENCED_BY": {("ClinicalObligation", "EvidenceRecord"), ("ClinicalObligation", "Encounter")},
        "COMPLETED_BY": {("ClinicalObligation", "ClinicalEvent")}, "CONTRADICTS": {("ClinicalEvent", "ClinicalEvent")},
        "REQUIRES_REVIEW": {("ClinicalObligation", "ResponsibleRole")}}
    st = E.src_id.map(ntype)
    dt = E.dst_id.map(ntype)
    invalid = int(sum((e, s, d) and ((s, d) not in allowed.get(e, set())) for e, s, d in zip(E.edge_type, st, dt)))
    unknown_types = sorted(set(E.edge_type) - set(allowed))
    selfloops = int((E.src_id == E.dst_id).sum())
    # cycle detection on DEPENDS_ON (Kahn)
    dep = E[E.edge_type == "DEPENDS_ON"]
    indeg = Counter()
    adj = defaultdict(list)
    for s, d in zip(dep.src_id, dep.dst_id):
        adj[d].append(s)
        indeg[s] += 1
    nodes = set(dep.src_id) | set(dep.dst_id)
    q = [n for n in nodes if indeg[n] == 0]
    seen = 0
    while q:
        n = q.pop()
        seen += 1
        for m in adj[n]:
            indeg[m] -= 1
            if indeg[m] == 0:
                q.append(m)
    cyc = len(nodes) - seen
    # edge valid_from earlier than its source/target node knowledge time
    vf = dict(zip(N.node_id, pd.to_datetime(N.valid_from_utc, utc=True)))
    ev_ = pd.to_datetime(E.valid_from_utc, utc=True)
    src_v = E.src_id.map(vf)
    dst_v = E.dst_id.map(vf)
    early = int(((ev_ < src_v) | ((ev_ < dst_v) & ~E.edge_type.isin(["BELONGS_TO"]))).sum())
    # multi-step dependency depth
    depth = {}
    par = {o: list(d) for o, d in zip(O.obligation_id, O.depends_on)}

    def dp(o):
        if o in depth:
            return depth[o]
        depth[o] = 1 + max((dp(p) for p in par[o]), default=0)
        return depth[o]
    depths = Counter(dp(o) for o in par)
    bad = {"invalid edge type/endpoint combos": invalid, "unknown edge types": unknown_types, "self loops": selfloops, "cycles (nodes in cycles)": cyc}
    bad = {k: v for k, v in bad.items() if v}
    # downstream-not-implied check: completed edges exist only for obligations with their own completion event
    comp_edges = E[E.edge_type == "COMPLETED_BY"].src_id
    comp_ob = set(_comp_times(D))
    implied = int((~comp_edges.isin(comp_ob)).sum())
    if implied:
        bad["COMPLETED_BY edges without own completion event"] = implied
    status = "FAIL" if bad else ("WARN" if early else "PASS")
    rec("Q07", "graph validity (cycles, edge types, no implied completion)", status,
        (f"violations: {bad}" if bad else "no cycles/invalid edges") + (f"; {early} edges are valid_from-earlier than an endpoint's knowledge time (date-level timestamp imputation)" if early else "")
        + f"; dependency depth histogram {dict(sorted(depths.items()))}", metrics={"depth_histogram": dict(sorted(depths.items()))})


def check_contradictions(D):
    A = D["action_all"]
    A = A.assign(n=A.text.map(_norm), ls=A.labels.map(lambda l: "|".join(sorted(l))))
    g = A.groupby("n").ls.nunique()
    contra = int((g > 1).sum())
    tot = int((A.groupby("n").size() > 1).sum())
    # outcome consistency with events
    G, O, V = D["ground_truth"], D["obligations"], D["events"]
    comp = _comp_times(D)
    dl = dict(zip(G.obligation_id, pd.to_datetime(G.deadline, utc=True)))
    conflict = set(V[V.event_type == "conflicting_record"].obligation_id)
    snap = set(V[V.event_type == "task_status_snapshot"].obligation_id)
    mism = 0
    for r in G.itertuples():
        if r.documented_root:
            continue
        c = comp.get(r.obligation_id)
        if r.outcome_label == "completed" and (c is None or c > dl[r.obligation_id] or r.obligation_id in conflict or r.obligation_id in snap):
            mism += 1
        if r.outcome_label == "overdue_unresolved" and c is not None and c <= dl[r.obligation_id]:
            mism += 1
    st = "FAIL" if mism else ("WARN" if tot and contra / max(tot, 1) > 0.05 else "PASS")
    rec("Q08", "contradictory labels", st,
        f"outcome-vs-event inconsistencies: {mism}; action text groups with conflicting label sets: {contra}/{tot} duplicated-text groups "
        f"(templated duplicates may legitimately differ by section context)", metrics={"conflicting_text_groups": contra, "duplicated_text_groups": tot})


def check_duplicates(D, cfg):
    A = D["action"]
    allr = pd.concat([a.assign(_s=k) for k, a in A.items()], ignore_index=True)
    allr["n"] = allr.text.map(_norm)
    sp = allr.groupby("n")._s.nunique()
    exact = int((sp > 1).sum())
    # near-duplicates (independent re-computation on final files)
    tr = allr[allr._s == "train"]
    ev = allr[allr._s != "train"]
    vec = TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True).fit(allr.n)
    Xtr, Xev = vec.transform(tr.n), vec.transform(ev.n)
    mx = np.zeros(Xev.shape[0])
    XtrT = Xtr.T.tocsr()
    for i in range(0, Xev.shape[0], 2000):
        mx[i:i + 2000] = (Xev[i:i + 2000] @ XtrT).max(axis=1).toarray().ravel()
    thr = cfg["thresholds"]["max_near_dup_cosine"]
    near = int((mx >= thr).sum())
    rec("Q09a", "action examples: exact/near duplicates across splits", "FAIL" if exact else ("WARN" if near else "PASS"),
        f"exact-duplicate texts spanning splits: {exact}; eval rows with cosine>={thr} to a train row: {near} (excluded rows were removed before writing)",
        group="leakage", metrics={"exact": exact, "near": near, "max_cosine_p99": float(np.quantile(mx, 0.99))})
    # notes
    N = D["notes"]
    N = N.assign(n=N.text.map(_norm))
    dn = N.groupby("n").split.nunique()
    by_src = {s: int((g.groupby("n").split.nunique() > 1).sum()) for s, g in N.groupby("source_dataset")}
    ex = int((dn > 1).sum())
    dup_note_groups_by_src = {s: int((g.groupby("n").size() > 1).sum()) for s, g in N.groupby("source_dataset")}
    rec("Q09b", "notes: identical note text across splits", "WARN" if ex else "PASS",
        f"{ex} identical normalized note texts appear in more than one split (by source: {by_src}); duplicated-text groups by source: {dup_note_groups_by_src}. "
        f"Synthea/MTS/ACI short or templated notes are expected to repeat; they are in the source as-is and splits are patient/official-level.",
        group="leakage", metrics={"by_source": by_src})
    ns = D["noshow"]
    cols = [c for c in ns.columns if c not in ("appointment_id", "split", "split_chrono", "patient_key")]
    dup = ns.assign(k=ns[cols].astype(str).agg("|".join, axis=1) if len(ns) < 5000 else pd.util.hash_pandas_object(ns[cols].astype(str), index=False))
    g = dup.groupby("k").split.nunique()
    rec("Q09c", "no-show: duplicate rows spanning splits", "WARN" if (g > 1).any() else "PASS", f"{int((g > 1).sum())} duplicate feature-vectors span splits (patient-grouped: same patient never in 2 splits)", group="leakage")
    # cross-source sentence overlap
    full = D["action_all"]
    full = full.assign(n=full.text.map(_norm))
    x = full.groupby("n").source_dataset.nunique()
    cross = int((x > 1).sum())
    pairs = Counter()
    for n_, g in full[full.n.isin(x[x > 1].index)].groupby("n"):
        pairs[tuple(sorted(set(g.source_dataset)))] += 1
    rec("Q09d", "cross-source sentence overlap (ACI/MTS/SH/Synthea)", "WARN" if cross else "PASS",
        f"{cross} normalized sentences occur in >1 source dataset: {dict(pairs)}", group="leakage")


def _recompute_features(D, sample_n=400):
    risk = pd.concat(D["risk"].values())
    s = risk.sample(min(sample_n, len(risk)), random_state=0)
    V = D["events"].assign(t=pd.to_datetime(D["events"].timestamp_utc, utc=True))
    O = D["obligations"].set_index("obligation_id")
    parents = {k: list(v) for k, v in O.depends_on.to_dict().items()}

    def anc(o):
        out = []
        for p in parents[o]:
            out += [p] + anc(p)
        return out
    byob = {k: g for k, g in V.groupby("obligation_id")}
    mism = Counter()
    for r in s.itertuples():
        A = pd.Timestamp(r.assessment_time_utc)
        ids = [r.obligation_id] + anc(r.obligation_id)
        ev = pd.concat([byob[i] for i in ids if i in byob]) if any(i in byob for i in ids) else V.iloc[0:0]
        ev = ev[ev.t <= A]
        if len(ev) != r.n_events_so_far:
            mism["n_events_so_far"] += 1
        if int((ev.event_type == "reminder_sent").sum()) != r.n_reminders:
            mism["n_reminders"] += 1
        if int((ev.event_type == "contact_attempt").sum()) != r.n_contact_attempts:
            mism["n_contact_attempts"] += 1
        if int(ev.event_type.isin(["appointment_scheduled", "appointment_rescheduled"]).any()) != r.has_scheduled_appointment:
            mism["has_scheduled_appointment"] += 1
        if int((ev.event_type == "conflicting_record").any()) != r.has_conflicting_record:
            mism["has_conflicting_record"] += 1
        if A >= pd.Timestamp(r.deadline_utc):
            mism["assessment_not_before_deadline"] += 1
    return dict(mism), len(s)


def check_future_leakage(D, cfg):
    spec = D["risk_spec"]
    cols_all = set().union(*[set(df.columns) for df in D["risk"].values()])
    forb = sorted(set(spec["forbidden_in_model_input"]) & (cols_all - {"outcome_label", "label_binary"}))
    feat_forb = sorted(set(spec["forbidden_in_model_input"]) & set(spec["feature_columns"]))
    extra = sorted(cols_all - set(spec["meta_columns"]) - set(spec["feature_columns"]) - set(spec["label_columns"]))
    mism, n = _recompute_features(D)
    # no completion evidence at/before assessment time for included obligations
    comp = _comp_times(D)
    risk = pd.concat(D["risk"].values())
    leak_rows = int(sum((o in comp) and (comp[o] <= pd.Timestamp(a)) for o, a in zip(risk.obligation_id, risk.assessment_time_utc)))
    bad = {"forbidden columns in model-input files": forb or feat_forb, "unexpected columns": extra, "feature recomputation mismatches": mism,
           "rows already completed at assessment time": leak_rows}
    bad = {k: v for k, v in bad.items() if v}
    rec("L01", "future-information leakage (features vs events <= assessment time)", "FAIL" if bad else "PASS",
        f"violations: {bad}" if bad else f"features recomputed independently for {n} sampled rows match; no forbidden/generator columns; all rows open at assessment_time and assessment_time < deadline",
        group="leakage")
    # no-show: history features recomputed by brute force on a sample
    ns = D["noshow"]
    s = ns.sample(min(300, len(ns)), random_state=1)
    bad_ns = 0
    by_p = {k: g for k, g in ns.groupby("patient_key")}
    for r in s.itertuples():
        g = by_p[r.patient_key]
        sched_date = pd.Timestamp(r.scheduled_time_utc[:10])
        known = g[pd.to_datetime(g.appointment_date) < sched_date]
        if len(known) != r.prior_appointments or int(known.no_show.sum()) != r.prior_noshows:
            bad_ns += 1
    rec("L02", "no-show history features use only earlier appointments", "FAIL" if bad_ns else "PASS", f"{bad_ns}/{len(s)} sampled rows mismatch brute-force recomputation", group="leakage")
    sms = [c for c in ns.columns if "timing_uncertain" in c]
    rec("L03", "no-show: timing-uncertain column kept out of primary features", "PASS" if not (set(sms) & set(read_json(cfg_path(cfg, "processed") / "appointment_noshow" / "noshow_stats.json")["features"])) else "FAIL",
        f"{sms} present only as clearly-labelled optional column", group="leakage")


def check_graph_leakage(D):
    E, O = D["edges"], D["obligations"]
    risk = pd.concat(D["risk"].values()).sample(300, random_state=2)
    comp_edges = E[E.edge_type == "COMPLETED_BY"][["src_id", "valid_from_utc"]].copy()
    comp_edges["t"] = pd.to_datetime(comp_edges.valid_from_utc, utc=True)
    first = comp_edges.groupby("src_id").t.min().to_dict()
    leak = sum((o in first) and (first[o] <= pd.Timestamp(a)) for o, a in zip(risk.obligation_id, risk.assessment_time_utc))
    rev = E[E.edge_type == "REQUIRES_REVIEW"].copy()
    rev["t"] = pd.to_datetime(rev.valid_from_utc, utc=True)
    rv = rev.groupby("src_id").t.min().to_dict()
    hidden_trig = 0
    V = D["events"].set_index("event_id")
    rev["reason"] = rev["attrs"].map(lambda x: json.loads(x).get("reason"))
    overdue_edge = rev[rev.reason == "open_past_deadline"].groupby("src_id").t.min().to_dict()
    snap_leak = sum((o in overdue_edge) and (overdue_edge[o] <= pd.Timestamp(a)) for o, a in zip(risk.obligation_id, risk.assessment_time_utc))
    rec("L04", "graph edges created after assessment time are excluded from snapshots", "FAIL" if (leak or snap_leak) else "PASS",
        f"{leak} sampled obligations have a COMPLETED_BY edge at/before assessment_time; {snap_leak} have an overdue-trigger review edge before assessment",
        group="leakage")


def check_patient_independence(D):
    P = D["patients"]
    sp = dict(zip(P.patient_id, P.split))
    bad = {}
    for name, df in (("notes", D["notes"]), ("obligations", D["obligations"]), ("events", D["events"]), ("action_all", D["action_all"].rename(columns={"patient_id": "patient_id"}))):
        m = df.patient_id.map(sp)
        bad[name] = int((m != df.split).sum()) if "split" in df else 0
    for k, df in D["risk"].items():
        bad[f"risk_{k}"] = int((df.patient_id.map(sp) != k).sum())
    for k, df in D["action"].items():
        bad[f"action_{k}"] = int((df.patient_id.map(sp) != k).sum())
    st = D["stream"]
    bad["stream"] = int((st.patient_id.map(sp) != st.split).sum())
    nodes = D["nodes"]
    pn = nodes[nodes.node_type == "Patient"]
    bad["graph_patient_nodes"] = int((pn.node_id.map(sp) != pn.split).sum())
    multi = int((D["noshow"].groupby("patient_key").split.nunique() > 1).sum())
    bad["noshow_patients_in_multiple_splits"] = multi
    bad = {k: v for k, v in bad.items() if v}
    rec("L05", "patient-level split independence & reuse across all artefacts", "FAIL" if bad else "PASS", f"violations: {bad}" if bad else "every patient has one split reused in notes/obligations/events/action/risk/graph/stream; no-show patients never span splits", group="leakage")


def check_split_preservation(D, cfg):
    raw = cfg_path(cfg, "raw")
    import sqlite3
    b = sqlite3.connect(f"file:{raw / 'synthetic_hospital' / 'benchmark_v1.3.db'}?mode=ro", uri=True)
    gt = pd.read_sql("select distinct patient_id, split from benchmark_ground_truth", b)
    P = D["patients"]
    sh = P[P.source_dataset == "synthetic_hospital"].copy()
    sh["pid"] = sh.source_patient_id.astype(int)
    m = sh.merge(gt, left_on="pid", right_on="patient_id", suffixes=("", "_gt"))
    full = cfg["mode"] == "full"
    wrong = int((m.official_split != m.split_gt).sum())
    mapping_wrong = int((m.split != m.split_gt.map({"train": "train", "public": "validation", "heldout": "test"})).sum())
    heldout_in_train = int(((m.official_split == "heldout") & (m.split == "train")).sum())
    mts = P[P.source_dataset == "mts_dialog"].groupby("official_split").size().to_dict()
    aci = P[P.source_dataset == "aci_bench"].groupby("official_split").size().to_dict()
    expect_mts = {"train": 1201, "validation": 100, "test1_mediqa_chat": 200, "test2_mediqa_sum": 200}
    expect_aci = {"train": 67, "valid": 20, "test1": 40, "test2": 40, "test3": 40}
    bad = {}
    if wrong or mapping_wrong or heldout_in_train:
        bad["SH split mismatch"] = [wrong, mapping_wrong, heldout_in_train]
    if mts != expect_mts:
        bad["MTS partition sizes"] = mts
    if aci != expect_aci:
        bad["ACI partition sizes"] = aci
    rec("Q13", "preservation of source-provided splits", "FAIL" if bad else "PASS",
        f"violations: {bad}" if bad else f"SH official splits kept ({sh.official_split.value_counts().to_dict()}), SH heldout only in test; MTS {mts}; ACI {aci}")
    # heldout is never in a training file
    ho = set(P[P.official_split == "heldout"].patient_id)
    leaks = sum(int(df.patient_id.isin(ho).sum()) for df in (D["action"]["train"], D["risk"]["train"]))
    rec("L06", "SH held-out patients never appear in training files", "FAIL" if leaks else "PASS", f"{leaks} rows", group="leakage")


def check_labels(D, cfg):
    thr = cfg["thresholds"]
    warn = []
    A = D["action"]
    counts = {sp: {c: int(df.labels.map(lambda l, c=c: c in l).sum()) for c in ALL_CATEGORIES} for sp, df in A.items()}
    low = [(sp, c, n) for sp, d in counts.items() for c, n in d.items() if n < 30]
    if low:
        warn.append(f"action classes with <30 examples: {low}")
    gold = int((pd.concat(A.values()).label_tier == "gold").sum())
    if gold < thr["min_gold_for_eval"]:
        warn.append(f"gold-reviewed action examples = {gold} (< {thr['min_gold_for_eval']}): precision/recall against GENUINE reviewed labels cannot be computed")
    for sp, df in D["risk"].items():
        b = df[df.label_binary.notna()].label_binary.astype(int)
        frac = float(min(b.mean(), 1 - b.mean())) if len(b) else 0
        if frac < thr["min_class_fraction_binary"]:
            warn.append(f"risk {sp}: minority class fraction {frac:.3f}")
    ns = D["noshow"]
    for sp, g in ns.groupby("split"):
        if g.no_show.mean() < thr["min_class_fraction_binary"]:
            warn.append(f"no-show {sp}: minority fraction {g.no_show.mean():.3f}")
    rk = pd.concat(D["risk"].values())
    pos = rk[rk.label_binary.notna()].label_binary.astype(int).mean()
    warn.append(f"risk binary base rate (overdue) = {pos:.2f}: a simulation parameter (open-at-assessment population), NOT an epidemiological estimate")
    nb = (D["action_all"].labels.map(lambda l: list(l) == ["no_action"])).mean()
    warn.append(f"action 'no_action' share = {nb:.2f} (heavy majority class)")
    rec("Q11", "label distribution & class imbalance", "WARN" if warn else "PASS", " | ".join(warn) or "balanced enough",
        metrics={"action_counts": counts, "gold": gold})


def check_diversity(D):
    G, O = D["ground_truth"], D["obligations"]
    G2 = G[~G.documented_root]
    prof = G2.scenario_profile.value_counts(normalize=True)
    root_cat = O.sort_values("chain_position").drop_duplicates("chain_id")[["chain_id", "category"]]       # category of the chain's first step
    chains = G2.merge(O[["obligation_id", "chain_id"]], on="obligation_id").drop_duplicates("chain_id").merge(root_cat, on="chain_id")
    ent = float(-(prof * np.log(prof)).sum() / np.log(len(prof)))
    cat = chains.category.value_counts(normalize=True)
    per_cat = chains.groupby("category").scenario_profile.nunique().to_dict()
    warn = []
    if prof.min() < 0.01:
        warn.append(f"rarest profile share {prof.min():.3f}")
    if cat.max() > 0.5:
        warn.append(f"category '{cat.idxmax()}' dominates chains ({cat.max():.2f})")
    rk = pd.concat(D["risk"].values())
    cs = rk.category.value_counts(normalize=True)
    if cs.max() > 0.5:
        warn.append(f"risk rows dominated by '{cs.idxmax()}' ({cs.max():.2f}); rare: {cs[cs < 0.02].to_dict()}")
    rec("Q12", "synthetic scenario diversity", "WARN" if warn else "PASS",
        f"{len(prof)} behaviour profiles, normalised entropy {ent:.2f}; profiles per category {per_cat}; " + "; ".join(warn), metrics={"profile_share": prof.round(4).to_dict(), "entropy": ent})


def check_provenance(D, cfg):
    raw = cfg_path(cfg, "raw")
    man = read_json(raw / "MANIFEST.json")
    bad = []
    for k, v in man["files"].items():
        p = ROOT / v["local_path"]
        for f in ("source", "url", "retrieved_at_utc", "sha256", "size_bytes", "format", "license", "nature", "version"):
            if v.get(f) in (None, ""):
                bad.append(f"{k}:{f} missing")
        if p.exists() and sha256_file(p) != v["sha256"]:
            bad.append(f"{k}: sha256 mismatch")
        if not p.exists():
            bad.append(f"{k}: file missing")
    O, V = D["obligations"], D["events"]
    prov = {"obligations.annotation_provenance": int(O.annotation_provenance.isna().sum()), "events.provenance": int(V.provenance.isna().sum()),
            "edges.provenance": int(D["edges"].provenance.isna().sum()), "stream.provenance": int(D["stream"].provenance.isna().sum()),
            "stream.is_simulated": int(D["stream"].is_simulated.isna().sum())}
    prov = {k: v for k, v in prov.items() if v}
    rec("Q14", "provenance completeness", "FAIL" if (bad or prov) else "PASS",
        f"manifest problems: {bad[:5]} {prov}" if (bad or prov) else f"{len(man['files'])} raw files have url/version/license/sha256 (re-verified on disk); all derived rows carry provenance")


def check_graph_stream(D):
    nodes, st, V, O = D["nodes"], D["stream"], D["events"], D["obligations"]
    ev_nodes = set(nodes[nodes.node_type == "ClinicalEvent"].node_id)
    ob_nodes = set(nodes[nodes.node_type == "ClinicalObligation"].node_id)
    s_ev = set(st[st.event_type.isin(set(V.event_type))].event_id) & set(V.event_id)
    s_ob = set(st.obligation_id.dropna())
    bad = {"graph events missing in stream": len(ev_nodes - set(st.event_id)),
           "stream clinical events missing in graph": len(s_ev - ev_nodes),
           "graph obligations missing in stream": len(ob_nodes - s_ob),
           "stream obligation ids missing in graph": len(s_ob - ob_nodes),
           "logical event count mismatch": int(len(ev_nodes) != len(s_ev))}
    nodes_events_sim = nodes[nodes.node_type == "ClinicalEvent"].provenance.value_counts().to_dict()
    sp = st[st.delivery_attempt == 1]
    live_cols_bad = [c for c in ("outcome_label", "scenario_profile", "latent_completed", "doc_lost", "final_status") if c in st.columns]
    payload_text = st.payload.astype(str)
    leak = int(payload_text.str.contains("outcome_label|scenario_profile|latent_|doc_lost|overdue_unresolved", regex=True).sum())
    if live_cols_bad or leak:
        bad["hidden fields exposed in live stream"] = [live_cols_bad, leak]
    bad = {k: v for k, v in bad.items() if v}
    rec("Q15", "graph <-> event stream referential consistency (and no hidden fields in stream)", "FAIL" if bad else "PASS",
        f"violations: {bad}" if bad else f"{len(ev_nodes)} graph event nodes == stream logical events; {len(ob_nodes)} obligations aligned; payloads contain no outcome/generator fields")


def check_generator_leakage(D, cfg):
    risk = D["risk"]
    spec = D["risk_spec"]
    F = spec["feature_columns"]
    cat = spec["categorical_columns"]
    val = pd.concat([risk["train"], risk["validation"]])
    val = val[val.label_binary.notna()]
    y = val.label_binary.astype(int).values
    res = {}
    for c in F:
        x = val[c]
        x = x.astype("category").cat.codes if c in cat else pd.to_numeric(x, errors="coerce").fillna(-999)
        try:
            a = roc_auc_score(y, x)
            res[c] = round(max(a, 1 - a), 3)
        except Exception:  # noqa: BLE001
            pass
    top = sorted(res.items(), key=lambda kv: -kv[1])[:5]
    mx = top[0][1]
    st = "FAIL" if mx > 0.90 else ("WARN" if mx > 0.75 else "PASS")
    rec("L07", "single-feature AUC scan for generator/template leakage", st,
        f"max single-feature AUC (train+val) = {mx} ({top[0][0]}); top5 {top}. Thresholds: >0.90 FAIL, >0.75 WARN. Note: events/features are produced by a seeded generator, so even a "
        f"sub-threshold model score reflects the generator's causal structure, NOT real-world predictability.", group="leakage", metrics={"top": top})
    bp = cfg_path(cfg, "reports") / "baseline_results.json"
    if bp.exists():
        b = read_json(bp)
        used = b.get("test_used_for_model_selection")
        rec("L08", "test split not used for tuning", "FAIL" if used else "PASS", f"baseline_check recorded test_used_for_model_selection={used}; hyper-parameters fixed a priori, validation only for early stopping", group="leakage")
    else:
        rec("L08", "test split not used for tuning", "WARN", "baseline_results.json missing; run baseline_check first", group="leakage")


def write_reports(cfg):
    rep = cfg_path(cfg, "reports")
    order = {"FAIL": 0, "WARN": 1, "PASS": 2}
    cnt = Counter(r["status"] for r in RES)

    def table(items):
        L = ["| id | check | status | detail |", "|---|---|---|---|"]
        for r in items:
            L.append(f"| {r['id']} | {r['name']} | **{r['status']}** | {r['detail'].replace('|', '/')} |")
        return "\n".join(L)

    q = [r for r in RES if r["group"] == "quality"]
    lk = [r for r in RES if r["group"] == "leakage"]
    (rep / "dataset_quality.md").write_text(
        "# MedRelay Dataset Quality Report\n\nGenerated by `src/validate.py` (mode=" + cfg["mode"] + "). Thresholds are in `config.yaml` and were not tuned to pass.\n\n"
        f"Summary: {dict(cnt)}\n\n" + table(q) + "\n\n"
        "## Reading WARN items\nWARN means a limitation was measured and is disclosed, not hidden. FAIL would mean a defect that blocks use.\n")
    (rep / "leakage_report.md").write_text(
        "# MedRelay Leakage Report\n\nCategories: repeated notes, paraphrased/near-duplicate text, future events, final status/generator columns, graph edges after "
        "assessment time, patient identity, source-document overlap, generator-specific templates, test-set use during tuning.\n\n" + table(lk) + "\n")
    write_json({"summary": dict(cnt), "checks": RES}, rep / "validation_results.json")
    return dict(cnt)


def run(cfg=None):
    cfg = cfg or load_config()
    RES.clear()
    D = load_all(cfg)
    check_required(D, cfg)
    check_pk(D)
    check_schemas(D)
    check_fk(D)
    check_chronology(D)
    check_transitions(D)
    check_evidence_before_cause(D)
    check_graph(D)
    check_contradictions(D)
    check_duplicates(D, cfg)
    check_future_leakage(D, cfg)
    check_graph_leakage(D)
    check_patient_independence(D)
    check_split_preservation(D, cfg)
    check_labels(D, cfg)
    check_diversity(D)
    check_provenance(D, cfg)
    check_graph_stream(D)
    check_generator_leakage(D, cfg)
    summ = write_reports(cfg)
    log.info("validation summary: %s", summ)
    return summ


if __name__ == "__main__":
    s = run()
    raise SystemExit(1 if s.get("FAIL") else 0)
