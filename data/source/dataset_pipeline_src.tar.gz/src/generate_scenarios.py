"""Seeded, explicit-event follow-up scenario generator.

Takes obligation seeds (documented / rule-extracted from real-synthetic sources; see extract_actions.py) and
expands each into a dependency chain of obligations (e.g. lab collected -> result available -> result reviewed ->
patient notified) with a *simulated event history*. Every outcome is derived downstream from the emitted event
sequence by `label_node` -- never drawn directly.

EVERYTHING produced here after the seed's own source event is SIMULATED (provenance="simulated") unless it re-uses a
documented source event id (provenance="documented_source"). Behaviour profiles ("scenarios") only change the event
generating probabilities; they are recorded in the hidden ground-truth table and never leave it.

Determinism: each chain uses an RNG seeded from (global seed, seed_id), so output is independent of iteration order.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy.stats import norm

from .common import cfg_path, get_logger, load_config, stable_hash, stable_uniform, write_json, write_table

log = get_logger("scenarios")

H = 3600.0
STEP_SPEC = {  # step_type: (category, responsible_role)
    "lab_collected": ("laboratory_test", "patient"), "result_available": ("laboratory_test", "laboratory"),
    "result_reviewed": ("followup_review", "ordering_clinician"), "patient_notified": ("patient_communication", "nurse"),
    "imaging_scheduled": ("appointment_referral", "scheduler"), "imaging_performed": ("imaging", "radiology"),
    "report_available": ("imaging", "radiology"), "report_reviewed": ("followup_review", "ordering_clinician"),
    "appointment_scheduled": ("appointment_referral", "scheduler"), "appointment_attended": ("appointment_referral", "patient"),
    "consult_report_received": ("followup_review", "specialist"),
    "followup_scheduled": ("appointment_referral", "scheduler"), "followup_visit_completed": ("followup_review", "patient"),
    "procedure_scheduled": ("appointment_referral", "scheduler"), "procedure_performed": ("procedure", "specialist"),
    "post_procedure_review": ("followup_review", "ordering_clinician"),
    "medication_dispensed": ("medication_action", "pharmacy"), "medication_reviewed": ("medication_action", "ordering_clinician"),
    "patient_contacted": ("patient_communication", "nurse"), "action_completed": ("other_action", "ordering_clinician"),
}
CHAINS = {
    "laboratory_test": ["lab_collected", "result_available", "result_reviewed", "patient_notified"],
    "imaging": ["imaging_scheduled", "imaging_performed", "report_available", "report_reviewed", "patient_notified"],
    "appointment_referral": ["appointment_scheduled", "appointment_attended", "consult_report_received"],
    "followup_review": ["followup_scheduled", "followup_visit_completed"],
    "procedure": ["procedure_scheduled", "procedure_performed", "post_procedure_review"],
    "medication_action": ["medication_dispensed", "medication_reviewed"],
    "patient_communication": ["patient_contacted"],
    "other_action": ["action_completed"],
}
OPTIONAL_STEP_P = {"patient_notified": 0.75, "consult_report_received": 0.6}
# documented source events cover the leading step(s) for these seed kinds
DOCUMENTED_ROOT = {"documented_lab_result": "result_available", "structured_order": "report_available"}
COMPLETION_EVENT = {
    "lab_collected": "lab_collected", "result_available": "result_posted", "result_reviewed": "result_acknowledged",
    "patient_notified": "patient_notified", "imaging_scheduled": "appointment_scheduled", "imaging_performed": "imaging_performed",
    "report_available": "report_posted", "report_reviewed": "result_acknowledged", "appointment_scheduled": "appointment_scheduled",
    "appointment_attended": "visit_attended", "consult_report_received": "consult_report_received",
    "followup_scheduled": "appointment_scheduled", "followup_visit_completed": "visit_attended",
    "procedure_scheduled": "appointment_scheduled", "procedure_performed": "procedure_performed",
    "post_procedure_review": "result_acknowledged", "medication_dispensed": "medication_dispensed",
    "medication_reviewed": "medication_acknowledged", "patient_contacted": "patient_notified", "action_completed": "action_documented",
}
EVIDENCE_SOURCE = {
    "lab_collected": "lab_information_system", "result_posted": "lab_information_system", "result_acknowledged": "clinician_inbox",
    "result_opened": "clinician_inbox", "patient_notified": "nurse_documentation", "contact_attempt": "nurse_documentation",
    "appointment_scheduled": "scheduling_system", "appointment_rescheduled": "scheduling_system", "visit_attended": "registration_adt",
    "visit_no_show": "registration_adt", "appointment_cancelled": "scheduling_system", "imaging_performed": "radiology_information_system",
    "report_posted": "radiology_information_system", "consult_report_received": "document_inbox", "procedure_performed": "or_scheduling",
    "medication_dispensed": "pharmacy_system", "medication_opened": "clinician_inbox", "medication_acknowledged": "clinician_inbox",
    "action_documented": "clinician_note", "reminder_sent": "patient_portal", "task_status_snapshot": "task_tracker",
    "conflicting_record": "secondary_clinic_log",
}

# scenario profiles: logit/probability modifiers only (no outcome is specified).  Weights per root kind.
PROFILES = {
    "timely": {},
    "unacknowledged_result": {"ack_logit": -3.6},
    "scheduled_pending": {"appt_after_deadline_p": 0.85},
    "missed_appointment": {"att_logit": -3.2},
    "unscheduled_referral": {"sched_logit": -3.4},
    "contacted_early": {"contact_events": True, "patient_logit": 0.9},
    "late_completion": {"delay_mult": 2.6},
    "missing_documentation": {"doc_loss_p": 0.9},
    "conflicting_evidence": {"conflict_p": 0.9},
    "upstream_failure": {"patient_logit": -3.0, "att_logit": -2.5, "sched_logit": -2.0},
    "notification_failure": {"notify_logit": -3.0},
}
PROFILE_WEIGHTS = {
    "laboratory_test": {"timely": .30, "unacknowledged_result": .14, "contacted_early": .10, "late_completion": .08,
                        "missing_documentation": .06, "conflicting_evidence": .04, "upstream_failure": .18, "notification_failure": .10},
    "imaging": {"timely": .30, "unacknowledged_result": .12, "scheduled_pending": .12, "missed_appointment": .08, "contacted_early": .08,
                "late_completion": .08, "missing_documentation": .05, "conflicting_evidence": .04, "upstream_failure": .08, "notification_failure": .05},
    "appointment_referral": {"timely": .28, "scheduled_pending": .14, "missed_appointment": .14, "unscheduled_referral": .14,
                             "contacted_early": .08, "late_completion": .08, "missing_documentation": .05, "conflicting_evidence": .05, "upstream_failure": .04},
    "followup_review": {"timely": .30, "scheduled_pending": .14, "missed_appointment": .14, "unscheduled_referral": .08,
                        "contacted_early": .10, "late_completion": .08, "missing_documentation": .05, "conflicting_evidence": .05, "upstream_failure": .06},
    "procedure": {"timely": .30, "scheduled_pending": .14, "missed_appointment": .12, "unscheduled_referral": .10, "contacted_early": .08,
                  "late_completion": .08, "missing_documentation": .06, "conflicting_evidence": .06, "unacknowledged_result": .06},
    "medication_action": {"timely": .34, "unacknowledged_result": .20, "contacted_early": .10, "late_completion": .10,
                          "missing_documentation": .08, "conflicting_evidence": .06, "upstream_failure": .12},
    "patient_communication": {"timely": .40, "contacted_early": .14, "late_completion": .12, "missing_documentation": .10,
                              "conflicting_evidence": .06, "notification_failure": .18},
    "other_action": {"timely": .45, "late_completion": .15, "missing_documentation": .12, "conflicting_evidence": .08, "upstream_failure": .20},
}
DOCUMENTED_ROOT_WEIGHTS = {  # for chains whose first step is already documented
    "laboratory_test": {"timely": .34, "unacknowledged_result": .26, "contacted_early": .06, "late_completion": .12,
                        "missing_documentation": .08, "conflicting_evidence": .05, "notification_failure": .09},
    "imaging": {"timely": .34, "unacknowledged_result": .26, "contacted_early": .06, "late_completion": .12,
                "missing_documentation": .08, "conflicting_evidence": .05, "notification_failure": .09},
}


def sigmoid(x):
    return 1.0 / (1.0 + np.exp(-x))


def logn(rng, median_h, sigma=0.7):
    return float(np.exp(np.log(max(median_h, 0.05)) + sigma * rng.standard_normal()))


@dataclass
class Ctx:
    adherence: float
    dept: str
    workload_of: callable = None


@dataclass
class Node:
    step: str
    obligation_id: str
    category: str
    role: str
    created: pd.Timestamp
    deadline: pd.Timestamp
    parents: list = field(default_factory=list)       # parent Node objects
    events: list = field(default_factory=list)
    done: pd.Timestamp | None = None                  # true completion time (latent) -- hidden
    documented_done: pd.Timestamp | None = None       # time of completion evidence, if documented
    meta: dict = field(default_factory=dict)


def _ts(t0: pd.Timestamp, hours: float) -> pd.Timestamp:
    return t0 + pd.Timedelta(seconds=hours * H)


class Chain:
    def __init__(self, seed, cfg, ctx: Ctx, rng: np.random.Generator, profile: str):
        self.seed, self.ctx, self.rng, self.profile = seed, ctx, rng, profile
        self.P = PROFILES[profile]
        self.nodes: list[Node] = []
        self.ev_counter = 0
        self.grace_h = cfg["scenarios"]["observation_grace_days"] * 24.0
        self.t0 = pd.Timestamp(seed["created_time_utc"])

    # ----- helpers
    def emit(self, node: Node, etype: str, ts: pd.Timestamp, status: str, verification: str = "verified",
             source: str | None = None, provenance: str = "simulated", payload: dict | None = None, src_event: str | None = None):
        self.ev_counter += 1
        node.events.append(dict(
            event_id=f"sim:ev:{node.obligation_id.split(':', 2)[2]}:{self.ev_counter}", patient_id=self.seed["patient_id"],
            encounter_id=self.seed["encounter_id"], obligation_id=node.obligation_id, event_type=etype, timestamp_utc=ts,
            evidence_source=source or EVIDENCE_SOURCE.get(etype, "ehr"), status=status, verification=verification,
            provenance=provenance, payload=json.dumps(payload or {}), source_event_id=src_event))

    def workload(self, ts: pd.Timestamp) -> float:
        wk = ts.strftime("%G-%V")
        return 2.0 * stable_uniform(f"{self.ctx.dept}|{wk}", "workload") - 1.0

    def p_patient(self, node: Node, start: pd.Timestamp, window_h: float, extra=0.0) -> float:
        z = (2.0 + 0.8 * self.ctx.adherence - 0.5 * self.workload(start) + self.P.get("patient_logit", 0.0) + extra
             - (0.7 if window_h < 48 else 0.0))
        return float(sigmoid(z))

    # ----- per step simulation. Each returns nothing; sets node.done / node.documented_done and emits events.
    def sim(self, node: Node):
        step = node.step
        starts = [p.done for p in node.parents]
        if any(s is None for s in starts):          # a prerequisite genuinely did not complete -> nothing can happen
            node.meta["blocked"] = True
            return
        start = max(starts) if starts else node.created
        start = max(start, node.created)
        window_h = max((node.deadline - start).total_seconds() / H, 0.5)
        rng, P = self.rng, self.P
        dm = P.get("delay_mult", 1.0)

        for p_ in node.parents:
            if "appt_time" in p_.meta:
                node.meta["appt_time"] = p_.meta["appt_time"]
        if step.endswith("_scheduled"):
            self._schedule(node, start, window_h)
        elif step in ("appointment_attended", "followup_visit_completed", "procedure_performed", "imaging_performed") \
                and node.meta.get("appt_time"):
            self._attend(node, start, window_h)
        elif step in ("lab_collected", "medication_dispensed", "action_completed", "patient_contacted", "imaging_performed"):
            self._walkin(node, start, window_h, dm)
        elif step in ("result_available", "report_available"):
            if rng.random() < 0.985:
                lat = logn(rng, 20 if step == "result_available" else 30) * dm
                t = _ts(start, lat)
                self._complete(node, "result_posted" if step == "result_available" else "report_posted", t)
        elif step in ("result_reviewed", "report_reviewed", "post_procedure_review", "medication_reviewed"):
            self._review(node, start, window_h, dm)
        elif step == "patient_notified":
            self._notify(node, start, window_h, dm)
        elif step == "consult_report_received":
            if rng.random() < 0.8:
                self._complete(node, "consult_report_received", _ts(start, logn(rng, 6 * 24, 0.6) * dm))
        else:  # procedure_performed / attended without a scheduled appointment (scheduling node absent or failed)
            self._walkin(node, start, window_h, dm)

    def _complete(self, node: Node, etype: str, t: pd.Timestamp, status="completed", payload=None):
        """Genuine completion at t. Documentation may be lost (-> latent completion without evidence)."""
        node.done = t
        lost = self.rng.random() < (self.P.get("doc_loss_p", 0.0) + 0.02)
        node.meta["doc_lost"] = bool(lost)
        if not lost:
            self.emit(node, etype, t, status, payload=payload)
            node.documented_done = t
            if self.rng.random() < self.P.get("conflict_p", 0.0) * 0.8:   # a secondary record disagrees
                self.emit(node, "conflicting_record", t + pd.Timedelta(hours=float(self.rng.uniform(1, 30))), "conflicting", "unverified")
                node.meta["conflict"] = True

    def _walkin(self, node, start, window_h, dm):
        rng = self.rng
        extra = 0.0
        if self.P.get("contact_events") and node.role in ("patient", "pharmacy", "radiology", "nurse", "ordering_clinician"):
            for k in range(int(rng.integers(1, 3))):
                self.emit(node, "contact_attempt", _ts(start, float(rng.uniform(0.05, 0.4)) * window_h), "attempted", "verified")
            extra += 0.0
        if rng.random() < 0.35 or self.P.get("contact_events"):
            self.emit(node, "reminder_sent", _ts(start, float(rng.uniform(0.15, 0.6)) * window_h), "sent", "verified")
            extra += 0.4
        if rng.random() < self.p_patient(node, start, window_h, extra):
            t = _ts(start, logn(rng, 0.35 * window_h, 0.6) * dm)
            et = COMPLETION_EVENT[node.step]
            self._complete(node, et, t)

    def _schedule(self, node, start, window_h):
        rng, P = self.rng, self.P
        p = sigmoid(3.0 - 0.4 * self.workload(start) + P.get("sched_logit", 0.0))
        if rng.random() < p:
            t = _ts(start, logn(rng, 36) * P.get("delay_mult", 1.0) ** 0.5)
            main_deadline = node.meta["main_deadline"]
            if rng.random() < P.get("appt_after_deadline_p", 0.0):
                appt = main_deadline + pd.Timedelta(days=float(rng.uniform(2, 12)))
            else:
                lead_h = max((main_deadline - t).total_seconds() / H * float(rng.uniform(0.25, 0.95)), 6.0)
                appt = _ts(t, lead_h)
            appt = max(appt, t + pd.Timedelta(hours=6))      # an appointment can never precede the scheduling event
            self._complete(node, "appointment_scheduled", t, payload={"appointment_time": appt.strftime("%Y-%m-%dT%H:%M:%SZ")})
            node.meta["appt_time"] = appt
            if rng.random() < 0.12:           # reschedule moves the appointment later
                t2 = _ts(t, float(rng.uniform(6, 72)))
                appt = appt + pd.Timedelta(days=float(rng.uniform(3, 14)))
                self.emit(node, "appointment_rescheduled", t2, "rescheduled", "verified",
                          payload={"appointment_time": appt.strftime("%Y-%m-%dT%H:%M:%SZ")})
                node.meta["appt_time"] = appt

    def _attend(self, node, start, window_h):
        rng, P = self.rng, self.P
        appt = node.meta["appt_time"]
        contact_bonus = 0.5 if P.get("contact_events") else 0.0
        if P.get("contact_events"):
            self.emit(node, "contact_attempt", _ts(start, float(rng.uniform(0.05, 0.3)) * window_h), "attempted", "verified")
        if rng.random() < 0.3:
            rem = max(appt - pd.Timedelta(hours=float(rng.uniform(20, 72))), start + pd.Timedelta(hours=1))
            if rem < appt:
                self.emit(node, "reminder_sent", rem, "sent", "verified")
                contact_bonus += 0.4
        if rng.random() < 0.04:
            self.emit(node, "appointment_cancelled", appt - pd.Timedelta(hours=float(rng.uniform(2, 48))), "cancelled", "verified")
            node.meta["cancelled"] = True
            return
        z = 2.2 + 0.9 * self.ctx.adherence + contact_bonus + P.get("att_logit", 0.0) + P.get("patient_logit", 0.0) * 0.5
        if rng.random() < sigmoid(z):
            self._complete(node, COMPLETION_EVENT[node.step], appt + pd.Timedelta(hours=float(rng.uniform(0, 2))))
        else:
            self.emit(node, "visit_no_show", appt + pd.Timedelta(hours=1), "missed", "verified")
            node.meta["no_show"] = True

    def _review(self, node, start, window_h, dm):
        rng, P = self.rng, self.P
        step = node.step
        open_et = "medication_opened" if step == "medication_reviewed" else "result_opened"
        ack_et = COMPLETION_EVENT[step]
        w = self.workload(start)
        if rng.random() < sigmoid(3.0 - 0.8 * w):
            t_open = _ts(start, logn(rng, 12) * dm)
            self.emit(node, open_et, t_open, "viewed", "verified")
            node.meta["opened"] = True
            if rng.random() < sigmoid(2.6 - 0.8 * w + P.get("ack_logit", 0.0)):
                self._complete(node, ack_et, _ts(t_open, logn(rng, 18) * dm))

    def _notify(self, node, start, window_h, dm):
        rng, P = self.rng, self.P
        z = 1.9 - 0.5 * self.workload(start) + P.get("notify_logit", 0.0) + (0.9 if P.get("contact_events") else 0.0)
        t = start
        n_att = int(rng.integers(1, 4))
        for k in range(n_att):
            t = _ts(t, logn(rng, 30) * dm)
            if t > node.deadline + pd.Timedelta(days=14):
                break
            if rng.random() < sigmoid(z):
                self._complete(node, "patient_notified", t)
                return
            self.emit(node, "contact_attempt", t, "unanswered", "verified")


def label_node(node: Node, t_end: pd.Timestamp, grace_h: float, rng) -> dict:
    """Derive outcome from the observed event list only (events after t_end were already dropped)."""
    d = node.deadline
    ev = node.events
    ctype = COMPLETION_EVENT[node.step]
    comp = [e for e in ev if e["event_type"] == ctype]
    conflict = any(e["event_type"] == "conflicting_record" for e in ev)
    miss = [e for e in ev if e["event_type"] in ("visit_no_show", "appointment_cancelled")]
    out = {"outcome_label": None, "outcome_reason": None, "resolved_late": False, "completion_event_time": None}
    if comp:
        out["completion_event_time"] = comp[0]["timestamp_utc"]
    if conflict and comp:
        out.update(outcome_label="unverified", outcome_reason="conflicting_completion_evidence")
        return out
    if comp and comp[0]["timestamp_utc"] <= d:
        out.update(outcome_label="completed", outcome_reason="completion_documented_by_deadline")
        return out
    if comp:
        out.update(outcome_label="overdue_unresolved", outcome_reason="completion_documented_after_deadline", resolved_late=True)
        return out
    # no completion evidence in the observed window
    snap_t = d + pd.Timedelta(hours=1)
    fully_obs = t_end >= d + pd.Timedelta(hours=grace_h)
    if node.meta.get("doc_lost") or rng.random() < node.meta.get("snapshot_gap_p", 0.08):
        has_snapshot = False                    # tracker could not observe this task
    else:
        has_snapshot = snap_t <= t_end
    if has_snapshot or (miss and miss[-1]["timestamp_utc"] <= t_end and t_end >= d):
        if has_snapshot:
            node.events.append(dict(
                event_id=f"sim:ev:{node.obligation_id.split(':', 2)[2]}:snap", patient_id=node.meta["pid"],
                encounter_id=node.meta["eid"], obligation_id=node.obligation_id,
                event_type="task_status_snapshot", timestamp_utc=snap_t, evidence_source="task_tracker", status="open",
                verification="verified", provenance="simulated", payload=json.dumps({"status": "open"}), source_event_id=None))
        out.update(outcome_label="overdue_unresolved",
                   outcome_reason="documented_miss" if miss else "open_at_deadline_confirmed_by_tracker")
        return out
    if fully_obs:
        out.update(outcome_label="unverified", outcome_reason="no_completion_or_status_evidence")
    else:
        out.update(outcome_label="censored_or_unknown", outcome_reason="observation_window_ended_before_deadline_resolved")
    return out


def _weights(cat, documented):
    w = (DOCUMENTED_ROOT_WEIGHTS if documented and cat in DOCUMENTED_ROOT_WEIGHTS else PROFILE_WEIGHTS)[cat]
    names = list(w)
    p = np.array([w[n] for n in names], float)
    return names, p / p.sum()


def run(cfg=None):
    cfg = cfg or load_config()
    interim = cfg_path(cfg, "interim")
    out_dir = cfg_path(cfg, "interim") / "scenarios"
    out_dir.mkdir(parents=True, exist_ok=True)
    seeds = pd.read_parquet(interim / "obligation_seeds.parquet")
    enc = pd.read_parquet(interim / "encounters.parquet").set_index("encounter_id")
    sev = pd.read_parquet(interim / "source_events.parquet")
    gseed = cfg["seed"]
    sc = cfg["scenarios"]
    # documented source event ids to reuse as verified evidence of the documented-root step
    doc_by_enc: dict[tuple[str, str], str] = {}
    for r in sev[sev.event_type.isin(["lab_result_documented", "lab_result_available", "imaging_result_documented"])].itertuples():
        doc_by_enc.setdefault((r.encounter_id, "lab" if "lab" in r.event_type else "img"), r.event_id)
    obl_rows, ev_rows, gt_rows, link_rows = [], [], [], []
    by_enc_chain: dict[tuple, dict[str, Node]] = {}
    # chronological processing per patient so cross-chain dependencies point backwards
    seeds = seeds.assign(_t=pd.to_datetime(seeds.created_time_utc, utc=True))
    prio = {"laboratory_test": 0, "imaging": 0, "medication_action": 1, "procedure": 1, "appointment_referral": 2, "followup_review": 3,
            "patient_communication": 4, "other_action": 5}
    seeds["_p"] = seeds.category.map(prio)
    seeds = seeds.sort_values(["patient_id", "encounter_id", "_p", "_t", "seed_id"], na_position="last")
    for s in seeds.to_dict("records"):
        rng = np.random.default_rng(stable_hash(s["seed_id"], str(gseed)))
        pid = s["patient_id"]
        dept = (enc.at[s["encounter_id"], "department"] if s["encounter_id"] in enc.index and pd.notna(enc.at[s["encounter_id"], "department"])
                else (enc.at[s["encounter_id"], "encounter_type"] if s["encounter_id"] in enc.index else "unspecified"))
        a = float(norm.ppf(min(max(stable_uniform(pid, "adherence"), 1e-4), 1 - 1e-4))) * 0.9
        ctx = Ctx(adherence=a, dept=str(dept))
        documented = s["seed_kind"] in DOCUMENTED_ROOT
        names, p = _weights(s["category"], documented)
        profile = str(rng.choice(names, p=p))
        ch = Chain(s, cfg, ctx, rng, profile)
        t0 = ch.t0
        steps = list(CHAINS[s["category"]])
        if documented:
            steps = steps[steps.index(DOCUMENTED_ROOT[s["seed_kind"]]):]
        steps = [st for st in steps if st not in OPTIONAL_STEP_P or rng.random() < OPTIONAL_STEP_P[st]]
        D0 = float(s["due_days"])
        main_deadline = t0 + pd.Timedelta(days=D0)
        prev: Node | None = None
        chain_nodes: list[Node] = []
        for i, st in enumerate(steps):
            cat, role = STEP_SPEC[st]
            if s["category"] == "laboratory_test" and st in ("result_reviewed", "patient_notified"):
                pass
            if documented and i == 0:
                dl = t0
            elif st.endswith("_scheduled"):
                dl = t0 + pd.Timedelta(days=max(min(7.0, 0.4 * D0), 0.25))
            elif st in ("lab_collected", "medication_dispensed", "action_completed", "patient_contacted", "imaging_performed",
                        "appointment_attended", "followup_visit_completed", "procedure_performed"):
                dl = main_deadline
                if prev is not None and dl <= prev.deadline:
                    dl = prev.deadline + pd.Timedelta(days=0.5)
            else:
                off = {"result_available": 2, "report_available": 3, "result_reviewed": 3, "report_reviewed": 3, "patient_notified": 3,
                       "consult_report_received": 14, "post_procedure_review": 7, "medication_reviewed": 5}[st]
                dl = (prev.deadline if prev is not None else main_deadline) + pd.Timedelta(days=off)
            oid = f"sim:ob:{s['seed_id']}:{i}"
            node = Node(step=st, obligation_id=oid, category=cat, role=role, created=t0, deadline=dl,
                        parents=[prev] if prev is not None else [],
                        meta={"main_deadline": main_deadline, "pid": pid, "eid": s["encounter_id"]})
            # cross-chain dependency: follow-up/referral/procedure visits wait for lab/imaging results of the same encounter
            if i == 0 and s["category"] in ("followup_review", "appointment_referral", "procedure") and (pid, s["encounter_id"]) in by_enc_chain \
                    and rng.random() < 0.5:
                cand = [n for k, n in by_enc_chain[(pid, s["encounter_id"])].items() if n.step in ("result_available", "report_available")
                        and n.deadline < main_deadline and n.created <= t0]
                if cand:
                    node.parents.append(cand[0])
                    node.meta["cross_chain_parent"] = cand[0].obligation_id
                    node.deadline = max(node.deadline, cand[0].deadline + pd.Timedelta(days=0.5))
            chain_nodes.append(node)
            prev = node
        # ---- simulate (documented roots first)
        for i, node in enumerate(chain_nodes):
            if documented and i == 0:
                node.done = t0
                node.documented_done = t0
                node.meta["documented_root"] = True
                key = "lab" if s["seed_kind"] == "documented_lab_result" else "img"
                srcid = s["source_ref"] if s["seed_kind"] == "documented_lab_result" else doc_by_enc.get((s["encounter_id"], "img"), s["source_ref"])
                ch.emit(node, COMPLETION_EVENT[node.step], t0, "completed", "verified", source="source_dataset",
                        provenance="documented_source", src_event=srcid)
                if s["seed_kind"] == "structured_order":   # also keep the order itself as documented evidence
                    ch.emit(node, "imaging_order_documented", t0, "ordered", "verified", source="source_dataset",
                            provenance="documented_source", src_event=s["source_ref"])
                continue
            ch.sim(node)
        # ---- censoring of the observation window, then outcome labels from observed events only
        final_dl = max(n.deadline for n in chain_nodes)
        if rng.random() < sc["censor_probability"]:
            t_end = t0 + pd.Timedelta(seconds=float(rng.uniform(0.3, 1.05)) * (final_dl - t0).total_seconds())
        else:
            t_end = final_dl + pd.Timedelta(days=sc["observation_grace_days"] + 1)
        for node in chain_nodes:
            node.events = [e for e in node.events if e["timestamp_utc"] <= t_end or e["provenance"] == "documented_source"]
            node.meta["snapshot_gap_p"] = sc["documentation_gap_probability"]
        for node in chain_nodes:
            if node.meta.get("documented_root"):
                lab = dict(outcome_label="completed", outcome_reason="documented_source_event", resolved_late=False,
                           completion_event_time=node.created)
            else:
                lab = label_node(node, t_end, ch.grace_h, rng)
            by_enc_chain.setdefault((pid, s["encounter_id"]), {})[node.obligation_id] = node
            obl_rows.append(dict(
                obligation_id=node.obligation_id, patient_id=pid, encounter_id=s["encounter_id"], note_id=s["note_id"],
                source_dataset=s["source_dataset"], category=node.category, step_type=node.step,
                description=(s["description"] if node is chain_nodes[0] else f"{node.step.replace('_', ' ').capitalize()} - {s['description']}"[:300]),
                responsible_role=node.role, created_time_utc=node.created, due_time_utc=node.deadline,
                due_time_imputed=bool(s["due_imputed"]) if node.step in ("lab_collected", "imaging_performed", "appointment_attended", "followup_visit_completed", "medication_dispensed", "procedure_performed", "action_completed", "patient_contacted") else True,
                depends_on=[p_.obligation_id for p_ in node.parents], evidence_text=s["evidence_text"] if node is chain_nodes[0] else None,
                evidence_span=s["evidence_span"] if node is chain_nodes[0] else None,
                extraction_confidence=float(s["extraction_confidence"]), annotation_provenance=s["annotation_provenance"],
                label_tier=s["label_tier"], split=s["split"], chain_id=f"sim:ch:{s['seed_id']}", chain_position=steps.index(node.step),
                seed_id=s["seed_id"], seed_kind=s["seed_kind"], created_time_precision=s["created_time_precision"]))
            gt_rows.append(dict(
                obligation_id=node.obligation_id, patient_id=pid, split=s["split"], scenario_profile=profile,
                latent_completion_time=node.done, latent_completed=node.done is not None, doc_lost=bool(node.meta.get("doc_lost", False)),
                blocked_by_upstream=bool(node.meta.get("blocked", False)), observation_end=t_end, deadline=node.deadline,
                documented_root=bool(node.meta.get("documented_root", False)), **lab))
            ev_rows.extend(node.events)
    obl = pd.DataFrame(obl_rows)
    ev = pd.DataFrame(ev_rows)
    gt = pd.DataFrame(gt_rows)
    # evidence links
    ob_split = dict(zip(obl.obligation_id, obl.split))
    ctypes = obl.set_index("obligation_id").step_type.map(COMPLETION_EVENT)
    for e in ev.itertuples():
        oid = e.obligation_id
        if e.event_type == ctypes.get(oid):
            rel, conf, ver = "COMPLETED_BY", 0.95 if e.verification == "verified" else 0.5, e.verification
        elif e.event_type == "conflicting_record":
            rel, conf, ver = "CONTRADICTS", 0.6, "contradicted"
        elif e.event_type in ("visit_no_show", "appointment_cancelled", "task_status_snapshot"):
            rel, conf, ver = "EVIDENCED_BY", 0.9, "verified"
        else:
            rel, conf, ver = "EVIDENCED_BY", 0.8, e.verification
        link_rows.append(dict(obligation_id=oid, event_id=e.event_id, relationship=rel, match_confidence=conf, verification_state=ver,
                              link_time_utc=e.timestamp_utc, provenance=e.provenance))
    links = pd.DataFrame(link_rows)
    for df in (obl,):
        for c in ("created_time_utc", "due_time_utc"):
            df[c] = pd.to_datetime(df[c], utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    ev["timestamp_utc"] = pd.to_datetime(ev.timestamp_utc, utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    links["link_time_utc"] = pd.to_datetime(links.link_time_utc, utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    for c in ("latent_completion_time", "observation_end", "deadline", "completion_event_time"):
        gt[c] = pd.to_datetime(gt[c], utc=True).dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    write_table(obl, out_dir / "obligations")
    write_table(ev, out_dir / "events")
    write_table(gt, out_dir / "ground_truth")
    write_table(links, out_dir / "evidence_links")
    summ = {
        "n_seeds": int(len(seeds)), "n_obligations": int(len(obl)), "n_events": int(len(ev)), "n_links": int(len(links)),
        "profile_counts_per_chain": gt.drop_duplicates(subset=["patient_id"]).shape[0],
        "outcome_counts": gt.outcome_label.value_counts().to_dict(),
        "outcome_by_split": {k: v.outcome_label.value_counts().to_dict() for k, v in gt.groupby("split")},
        "profile_counts": gt[~gt.documented_root].scenario_profile.value_counts().to_dict(),
    }
    write_json(summ, out_dir / "scenario_summary.json")
    log.info("scenarios: %d obligations, %d events; outcomes %s", len(obl), len(ev), summ["outcome_counts"])
    return summ


if __name__ == "__main__":
    run()
