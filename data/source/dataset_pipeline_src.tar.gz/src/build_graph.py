"""Dataset 4 - temporal evidence graph (nodes/edges tables).

Node types : Patient, Encounter, ClinicalNote, ClinicalObligation, ClinicalEvent, ResponsibleRole, EvidenceRecord
Edge types : EXTRACTED_FROM, BELONGS_TO, DEPENDS_ON, ASSIGNED_TO, EVIDENCED_BY, COMPLETED_BY, CONTRADICTS, REQUIRES_REVIEW

Every node/edge carries `valid_from_utc` (when it becomes knowable) and `provenance`
(documented_source | extracted_rule | simulated | inferred) so a snapshot at any assessment time can be reconstructed with
`snapshot(nodes, edges, t)`. A completed upstream step does NOT mark downstream obligations completed: completion is
only asserted by an explicit COMPLETED_BY edge from that obligation's own completion event.
"""
from __future__ import annotations

import hashlib
import json

import pandas as pd

from .common import cfg_path, get_logger, load_config, write_json, write_table
from .generate_scenarios import COMPLETION_EVENT

log = get_logger("graph")
NODE_TYPES = ["Patient", "Encounter", "ClinicalNote", "ClinicalObligation", "ClinicalEvent", "ResponsibleRole", "EvidenceRecord"]
EDGE_TYPES = ["EXTRACTED_FROM", "BELONGS_TO", "DEPENDS_ON", "ASSIGNED_TO", "EVIDENCED_BY", "COMPLETED_BY", "CONTRADICTS", "REQUIRES_REVIEW"]


def _eid(*parts) -> str:
    return "edge:" + hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:16]


def snapshot(nodes: pd.DataFrame, edges: pd.DataFrame, t) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Graph as knowable at time t (nodes and edges with valid_from_utc <= t)."""
    t = pd.Timestamp(t, tz="UTC") if not isinstance(t, pd.Timestamp) else t
    nv = pd.to_datetime(nodes.valid_from_utc, utc=True)
    ev_ = pd.to_datetime(edges.valid_from_utc, utc=True)
    return nodes[nv <= t], edges[ev_ <= t]


def build(cfg=None):
    cfg = cfg or load_config()
    interim = cfg_path(cfg, "interim")
    sc = interim / "scenarios"
    out = cfg_path(cfg, "processed") / "evidence_graph"
    obl = pd.read_parquet(sc / "obligations.parquet")
    ev = pd.read_parquet(sc / "events.parquet")
    links = pd.read_parquet(sc / "evidence_links.parquet")
    pats = pd.read_parquet(interim / "patients.parquet")
    enc = pd.read_parquet(interim / "encounters.parquet")
    notes = pd.read_parquet(interim / "notes.parquet", columns=["note_id", "encounter_id", "patient_id", "source_dataset", "text_kind", "section", "split"])
    t0 = "1900-01-01T00:00:00Z"
    nodes, edges = [], []

    def node(nid, ntype, label, patient_id, split, valid_from, prov, **attrs):
        nodes.append(dict(node_id=nid, node_type=ntype, label=label, patient_id=patient_id, split=split, valid_from_utc=valid_from,
                          provenance=prov, attrs=json.dumps(attrs, default=str)))

    def edge(src, dst, etype, valid_from, prov, verification="verified", conf=1.0, **attrs):
        edges.append(dict(edge_id=_eid(src, dst, etype), src_id=src, dst_id=dst, edge_type=etype, valid_from_utc=valid_from, provenance=prov,
                          verification_state=verification, confidence=conf, attrs=json.dumps(attrs, default=str)))

    used_p = set(obl.patient_id)
    used_e = set(obl.encounter_id.dropna()) | set(ev.encounter_id.dropna())
    used_n = set(obl.note_id.dropna())
    # inferred (low-confidence) candidate evidence from DOCUMENTED subsequent encounters for visit-type steps
    visit = obl[obl.step_type.isin(["appointment_attended", "followup_visit_completed"]) & obl.encounter_id.notna()]
    enc_by_pat = {p: g.sort_values("event_time_utc") for p, g in enc.groupby("patient_id")}
    inferred = []
    for r in visit.itertuples():
        g = enc_by_pat.get(r.patient_id)
        if g is None:
            continue
        later = g[(g.event_time_utc > r.created_time_utc) & (g.event_time_utc <= r.due_time_utc)]
        if len(later):
            inferred.append((r.obligation_id, later.iloc[0].encounter_id, later.iloc[0].event_time_utc))
    used_e |= {x[1] for x in inferred}
    P = pats[pats.patient_id.isin(used_p)]
    for r in P.itertuples():
        node(r.patient_id, "Patient", r.patient_id, r.patient_id, r.split, t0, "documented_source", source_dataset=r.source_dataset,
             is_pseudo_patient=bool(r.is_pseudo_patient))
    E = enc[enc.encounter_id.isin(used_e)]
    for r in E.itertuples():
        node(r.encounter_id, "Encounter", f"{r.encounter_type}", r.patient_id, None, r.event_time_utc, "documented_source",
             department=r.department, time_precision=r.time_precision, time_imputed=bool(r.time_imputed))
        edge(r.encounter_id, r.patient_id, "BELONGS_TO", r.event_time_utc, "documented_source")
    N = notes[notes.note_id.isin(used_n)]
    enc_t = dict(zip(enc.encounter_id, enc.event_time_utc))
    for r in N.itertuples():
        vf = enc_t.get(r.encounter_id, t0)
        node(r.note_id, "ClinicalNote", r.text_kind, r.patient_id, r.split, vf, "documented_source", source_dataset=r.source_dataset)
        edge(r.note_id, r.encounter_id if r.encounter_id in enc_t else r.patient_id, "BELONGS_TO", vf, "documented_source")
    for role in sorted(obl.responsible_role.unique()):
        node(f"role:{role}", "ResponsibleRole", role, None, None, t0, "documented_source")
    for r in obl.itertuples():
        prov = "documented_source" if r.seed_kind in ("documented_lab_result", "structured_order", "documented_careplan") and r.chain_position == 0 \
            else ("extracted_rule" if r.seed_kind == "text_extracted" and r.chain_position == 0 else "simulated")
        node(r.obligation_id, "ClinicalObligation", r.step_type, r.patient_id, r.split, r.created_time_utc, prov, category=r.category,
             due_time_utc=r.due_time_utc, chain_id=r.chain_id, chain_position=int(r.chain_position), label_tier=r.label_tier,
             extraction_confidence=float(r.extraction_confidence), source_dataset=r.source_dataset)
        edge(r.obligation_id, r.patient_id, "BELONGS_TO", r.created_time_utc, prov)
        edge(r.obligation_id, f"role:{r.responsible_role}", "ASSIGNED_TO", r.created_time_utc, "simulated" if prov == "simulated" else prov)
        if r.note_id is not None and pd.notna(r.note_id):
            edge(r.obligation_id, r.note_id, "EXTRACTED_FROM", r.created_time_utc, prov, confidence=float(r.extraction_confidence))
        elif r.encounter_id is not None and pd.notna(r.encounter_id):
            edge(r.obligation_id, r.encounter_id, "EXTRACTED_FROM", r.created_time_utc, prov)
        for p in r.depends_on:
            edge(r.obligation_id, p, "DEPENDS_ON", r.created_time_utc, "simulated")
    # events
    ctype = obl.set_index("obligation_id").step_type.map(COMPLETION_EVENT)
    for r in ev.itertuples():
        node(r.event_id, "ClinicalEvent", r.event_type, r.patient_id, None, r.timestamp_utc, r.provenance, status=r.status,
             evidence_source=r.evidence_source, verification=r.verification, source_event_id=r.source_event_id)
        edge(r.event_id, r.patient_id, "BELONGS_TO", r.timestamp_utc, r.provenance)
    # evidence links -> EvidenceRecord nodes + typed edges
    ev_i = ev.set_index("event_id")
    comp_event_of: dict[str, tuple[str, str]] = {}
    for r in links.itertuples():
        rec = "evrec:" + hashlib.sha1(f"{r.obligation_id}|{r.event_id}".encode()).hexdigest()[:14]
        node(rec, "EvidenceRecord", r.relationship, ev_i.at[r.event_id, "patient_id"], None, r.link_time_utc, r.provenance,
             verification_state=r.verification_state, match_confidence=float(r.match_confidence), relationship=r.relationship)
        edge(r.obligation_id, rec, "EVIDENCED_BY", r.link_time_utc, r.provenance, r.verification_state, float(r.match_confidence))
        edge(rec, r.event_id, "EXTRACTED_FROM", r.link_time_utc, r.provenance, r.verification_state, float(r.match_confidence))
        if r.relationship == "COMPLETED_BY":
            edge(r.obligation_id, r.event_id, "COMPLETED_BY", r.link_time_utc, r.provenance, r.verification_state, float(r.match_confidence))
            comp_event_of.setdefault(r.obligation_id, (r.event_id, r.link_time_utc))
    # contradictions + review requirements (time-stamped at the triggering event)
    for r in ev[ev.event_type == "conflicting_record"].itertuples():
        tgt = comp_event_of.get(r.obligation_id)
        if tgt:
            edge(r.event_id, tgt[0], "CONTRADICTS", r.timestamp_utc, "simulated", "contradicted", 0.6)
        edge(r.obligation_id, "role:ordering_clinician", "REQUIRES_REVIEW", r.timestamp_utc, "simulated", "unverified", 1.0,
             reason="conflicting_completion_evidence", trigger_event_id=r.event_id)
    for r in ev[ev.event_type.isin(["task_status_snapshot", "visit_no_show"])].itertuples():
        edge(r.obligation_id, "role:ordering_clinician", "REQUIRES_REVIEW", r.timestamp_utc, "simulated", "verified", 1.0,
             reason="open_past_deadline" if r.event_type == "task_status_snapshot" else "documented_no_show", trigger_event_id=r.event_id)
    for r_oid, e0_id, e0_t in inferred:
        edge(r_oid, e0_id, "EVIDENCED_BY", e0_t, "inferred", "inferred", 0.3,
             note="next documented encounter inside the window; NOT proof of attendance")
    n_inf = len(inferred)
    nodes_df = pd.DataFrame(nodes).drop_duplicates("node_id")
    edges_df = pd.DataFrame(edges).drop_duplicates("edge_id")
    # referential integrity
    ids = set(nodes_df.node_id)
    bad = edges_df[~(edges_df.src_id.isin(ids) & edges_df.dst_id.isin(ids))]
    if len(bad):
        log.warning("dropping %d edges with dangling endpoints", len(bad))
        edges_df = edges_df.drop(bad.index)
    write_table(nodes_df, out / "nodes")
    write_table(edges_df, out / "edges")
    stats = {"n_nodes": int(len(nodes_df)), "n_edges": int(len(edges_df)),
             "nodes_by_type": nodes_df.node_type.value_counts().to_dict(), "edges_by_type": edges_df.edge_type.value_counts().to_dict(),
             "edges_by_provenance": edges_df.provenance.value_counts().to_dict(), "inferred_visit_evidence_edges": int(n_inf),
             "dangling_edges_dropped": int(len(bad))}
    write_json(stats, out / "graph_stats.json")
    log.info("graph: %d nodes, %d edges", len(nodes_df), len(edges_df))
    return stats


def run(cfg=None):
    return build(cfg)


if __name__ == "__main__":
    run()
