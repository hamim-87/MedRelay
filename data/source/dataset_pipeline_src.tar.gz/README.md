# MedRelay dataset pipeline

Reproducible, leakage-checked datasets for **MedRelay** (detecting unresolved clinical follow-up obligations). Everything is generated from
real downloads in `data/raw/` by one command. **Synthetic / simulated data only for the follow-up layer; nothing here is clinically validated.**

```bash
python3 -m venv --system-site-packages .venv && .venv/bin/pip install -r requirements.txt   # Python 3.12
.venv/bin/python -m src.pipeline --config config.yaml --all                 # download -> audit -> build -> baselines -> validate -> reports (~4-5 min)
.venv/bin/python -m src.pipeline --config config.yaml --all --mode dev      # small representative subset into dev_run/ (~2 min)
.venv/bin/python -m pytest -q tests                                          # unit, fault-injection and determinism tests (~4 min)
```
Downloads are cached/idempotent (SHA-256 checked, retries + timeouts, provenance in `data/raw/MANIFEST.json`). Kaggle needs `~/.kaggle/access_token`
(or `KAGGLE_USERNAME`/`KAGGLE_KEY`). Single steps: `--steps normalize,extract_actions` (see `src/pipeline.py`).

## Layout
| path | content |
|---|---|
| `config.yaml` | seed, mode (dev/full), source pins (git commits), thresholds (never relaxed to force a pass) |
| `src/download.py` | downloader + manifest | `src/audit.py` | raw-source schema/quality audit -> `reports/source_audit.{md,json}` |
| `src/normalize.py` | canonical `patients/encounters/notes/note_sections/source_events` -> `data/interim/` |
| `src/extract_actions.py`, `src/action_rules.py` | Dataset 1 (silver labels, review queue, gold ingestion, synthetic tier) + obligation seeds |
| `src/generate_scenarios.py` | seeded event-level follow-up simulator -> `data/interim/scenarios/{obligations,events,evidence_links,ground_truth}.parquet` |
| `src/build_risk_dataset.py` | Dataset 2 `data/processed/followup_risk/` |
| `src/build_noshow_dataset.py` | Dataset 3 `data/processed/appointment_noshow/` |
| `src/build_graph.py` | Dataset 4 `data/processed/evidence_graph/` (`nodes`, `edges`, `snapshot()`) |
| `src/build_event_stream.py` | Dataset 5 `data/processed/event_stream/` |
| `src/baseline_check.py`, `src/validate.py`, `src/make_reports.py` | baselines, 26 automated quality/leakage checks, statistics + docs |
| `reports/` | `source_audit`, `dataset_quality`, `leakage_report`, `dataset_statistics.json`, `baseline_results`, `validation_results.json` |
| `docs/` | `DATASET_CARD`, `LABEL_DEFINITIONS`, `PROVENANCE`, `ANNOTATION_GUIDE` |

Each tabular output is Parquet plus a `*.sample.csv` (first 200 rows).

## Loading datasets
```python
import json, pandas as pd
P = "data/processed"

# 1. Action classification (multi-label; silver labels, 0 gold) --------------------------------------------
A = {sp: pd.read_parquet(f"{P}/action_classification/{sp}.parquet") for sp in ("train", "validation", "test")}
Y = [c for c in A["train"].columns if c.startswith("y_")]          # 9 columns incl. y_no_action
X_train, y_train = A["train"].text, A["train"][Y].values
# optional, TRAIN-ONLY template augmentation (label_tier == "synthetic"):
aug = pd.read_parquet(f"{P}/action_classification/synthetic_train_augmentation.parquet")
# evidence span: text[start:end] of the matched cue -> json/ast of `evidence_spans`; offsets into the source note: char_start/char_end (+ span_basis)

# 2. Follow-up failure risk -----------------------------------------------------------------------------------
spec = json.load(open(f"{P}/followup_risk/feature_spec.json"))
tr, va, te = (pd.read_parquet(f"{P}/followup_risk/binary_{s}.parquet") for s in ("train", "validation", "test"))
X, y = tr[spec["feature_columns"]], tr.label_binary.astype(int)     # categorical: spec["categorical_columns"]
# 4-way outcome (completed / overdue_unresolved / unverified / censored_or_unknown): features_<split>.parquet -> outcome_label
# hidden generator fields (never features): followup_risk/ground_truth_hidden.parquet

# 3. Appointment no-show ------------------------------------------------------------------------------------
from src.build_noshow_dataset import FEATURES
ns = pd.read_parquet(f"{P}/appointment_noshow/train.parquet")        # patient-grouped split; chrono_<split>.parquet = chronological split
X, y = ns[FEATURES], ns.no_show

# 4. Evidence graph --------------------------------------------------------------------------------------------
from src.build_graph import snapshot
nodes, edges = (pd.read_parquet(f"{P}/evidence_graph/{n}.parquet") for n in ("nodes", "edges"))
n_t, e_t = snapshot(nodes, edges, "2022-03-01T00:00:00Z")            # graph as knowable at that time
# networkx: nx.from_pandas_edgelist(edges, "src_id", "dst_id", ["edge_type", "valid_from_utc"], create_using=nx.MultiDiGraph)

# 5. Event stream (consume in file order = ingest-time order; de-duplicate by event_id, handle late events) -----------
with open(f"{P}/event_stream/event_stream.jsonl") as f:
    for line in f:
        ev = json.loads(line)   # stream_seq, delivery_id, event_id, obligation_id, event_time_utc, ingest_time_utc, event_type, payload, provenance, is_simulated, split
# evaluation labels live ONLY in event_stream/ground_truth_obligations.jsonl and ground_truth_delivery_anomalies.jsonl
```

## Read this before using the data
* **No gold labels.** All action labels are rule-proposed silver labels. Fill `data/annotations/reviewed/` from `review_queue.csv` (see `docs/ANNOTATION_GUIDE.md`) to get gold + real precision/recall.
* **Follow-up outcomes are simulated** (the sources contain no appointments/tasks/result-review events). Rates and model scores describe the generator, not clinical reality.
* **Splits**: Synthetic Hospital official splits kept (train->train, public->validation, heldout->test, never trained on); MTS/ACI official partitions; Synthea & No-Show hash-assigned by patient.
* **No-show** data is real but non-commercial/share-alike licensed (CC-BY-NC-SA-4.0 per Kaggle) and must not be used to deny care; it is independent of the synthetic EHR data.
* Details: `docs/DATASET_CARD.md`, `reports/dataset_quality.md`, `reports/leakage_report.md`.
