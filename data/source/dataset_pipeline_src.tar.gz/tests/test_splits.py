from collections import Counter

from src.common import hash_split, stable_uniform

FR = {"train": 0.7, "validation": 0.15, "test": 0.15}


def test_hash_split_is_deterministic_and_roughly_proportional():
    ids = [f"patient-{i}" for i in range(20000)]
    a = [hash_split(i, FR, "s") for i in ids]
    assert a == [hash_split(i, FR, "s") for i in ids]
    c = Counter(a)
    for k, v in FR.items():
        assert abs(c[k] / len(ids) - v) < 0.02


def test_salt_changes_assignment():
    ids = [f"p{i}" for i in range(500)]
    assert [hash_split(i, FR, "a") for i in ids] != [hash_split(i, FR, "b") for i in ids]


def test_stable_uniform_range():
    assert all(0 <= stable_uniform(str(i)) < 1 for i in range(1000))
