import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))


def _have_outputs():
    return (ROOT / "reports" / "validation_results.json").exists() and (ROOT / "data/processed/followup_risk/feature_spec.json").exists()


requires_outputs = pytest.mark.skipif(not _have_outputs(), reason="run `python -m src.pipeline --all` first")


@pytest.fixture(scope="session")
def cfg():
    from src.common import load_config
    return load_config()


@pytest.fixture(scope="session")
def D(cfg):
    from src import validate
    return validate.load_all(cfg)
