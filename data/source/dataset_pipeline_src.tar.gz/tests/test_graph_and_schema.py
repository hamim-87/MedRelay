import pandas as pd
import pytest
from pydantic import ValidationError

from src.build_graph import snapshot
from src.schemas import Encounter, EvidenceLink, Obligation, Patient


def test_snapshot_filters_by_time():
    nodes = pd.DataFrame({"node_id": ["a", "b"], "valid_from_utc": ["2024-01-01T00:00:00Z", "2024-02-01T00:00:00Z"]})
    edges = pd.DataFrame({"edge_id": ["e1", "e2"], "valid_from_utc": ["2024-01-02T00:00:00Z", "2024-02-02T00:00:00Z"]})
    n, e = snapshot(nodes, edges, "2024-01-15")
    assert list(n.node_id) == ["a"] and list(e.edge_id) == ["e1"]


def test_schema_rejects_bad_values():
    with pytest.raises(ValidationError):
        Patient(patient_id="x", source_dataset="synthea", source_patient_id="x", split="holdout", split_origin="official")
    with pytest.raises(ValidationError):
        EvidenceLink(obligation_id="o", event_id="e", relationship="MAYBE", match_confidence=0.5, verification_state="verified")
    with pytest.raises(ValidationError):
        Encounter(encounter_id="e", patient_id="p", source_dataset="synthea", source_encounter_id="e", time_precision="date", time_imputed=True,
                  unexpected_field=1)


def test_obligation_requires_known_category():
    base = dict(obligation_id="o", patient_id="p", source_dataset="synthea", description="d", responsible_role="nurse", created_time_utc="2024-01-01T00:00:00Z",
                due_time_utc="2024-01-02T00:00:00Z", due_time_imputed=True, extraction_confidence=0.9, annotation_provenance="rule_v1",
                label_tier="silver", split="train")
    Obligation(category="imaging", **base)
    with pytest.raises(ValidationError):
        Obligation(category="telepathy", **base)
    with pytest.raises(ValidationError):
        Obligation(category="imaging", **{**base, "label_tier": "platinum"})
