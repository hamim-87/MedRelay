"""Assertions on the artefacts produced by `python -m src.pipeline --all`."""
import json

import pandas as pd
import pytest

from src.common import ROOT
from tests.conftest import requires_outputs

pytestmark = requires_outputs
P = ROOT / "data" / "processed"


def test_validation_has_no_failures():
    r = json.load(open(ROOT / "reports" / "validation_results.json"))
    assert r["summary"].get("FAIL", 0) == 0, [c for c in r["checks"] if c["status"] == "FAIL"]
    assert r["summary"].get("PASS", 0) >= 15


def test_required_files_exist():
    for rel in ["reports/source_audit.md", "reports/source_audit.json", "reports/dataset_quality.md", "reports/leakage_report.md",
                "reports/dataset_statistics.json", "docs/DATASET_CARD.md", "docs/LABEL_DEFINITIONS.md", "docs/PROVENANCE.md",
                "data/processed/event_stream/event_stream.jsonl", "data/processed/event_stream/ground_truth_obligations.jsonl",
                "data/processed/evidence_graph/nodes.parquet", "data/processed/evidence_graph/edges.parquet",
                "data/processed/action_classification/train.parquet", "data/processed/action_classification/review_queue.csv",
                "data/processed/followup_risk/binary_train.parquet", "data/processed/appointment_noshow/train.parquet"]:
        assert (ROOT / rel).exists(), rel


def test_risk_split_files_contain_only_allowed_columns():
    spec = json.load(open(P / "followup_risk" / "feature_spec.json"))
    allowed = set(spec["meta_columns"] + spec["feature_columns"] + spec["label_columns"])
    for sp in ("train", "validation", "test"):
        cols = set(pd.read_parquet(P / "followup_risk" / f"features_{sp}.parquet").columns)
        assert cols <= allowed and not (cols & set(spec["forbidden_in_model_input"]) - {"outcome_label", "label_binary"})


def test_binary_labels_exclude_unverified_and_censored():
    for sp in ("train", "validation", "test"):
        b = pd.read_parquet(P / "followup_risk" / f"binary_{sp}.parquet")
        assert set(b.outcome_label) <= {"completed", "overdue_unresolved"} and b.label_binary.notna().all()


def test_assessment_precedes_deadline_and_split_is_patient_level():
    f = pd.concat([pd.read_parquet(P / "followup_risk" / f"features_{sp}.parquet") for sp in ("train", "validation", "test")])
    assert (pd.to_datetime(f.assessment_time_utc) < pd.to_datetime(f.deadline_utc)).all()
    assert (f.groupby("patient_id").split.nunique() == 1).all()


def test_action_gold_tier_is_only_human_reviewed():
    for sp in ("train", "validation", "test"):
        a = pd.read_parquet(P / "action_classification" / f"{sp}.parquet")
        gold = a[a.label_tier == "gold"]
        assert gold.reviewer_id.notna().all() and gold.reviewed_at.notna().all()
        assert set(a.label_tier) <= {"gold", "silver"}


def test_synthetic_examples_are_train_only_and_separate():
    s = pd.read_parquet(P / "action_classification" / "synthetic_train_augmentation.parquet")
    assert (s.label_tier == "synthetic").all() and (s.split == "train").all()


def test_stream_is_ordered_and_has_duplicates_and_late_events():
    st = pd.read_json(P / "event_stream" / "event_stream.jsonl", lines=True, dtype=False)
    assert (pd.to_datetime(st.ingest_time_utc).diff().dt.total_seconds().dropna() >= 0).all()
    assert (st.delivery_attempt == 2).any()
    assert (pd.to_datetime(st.ingest_time_utc) - pd.to_datetime(st.event_time_utc) > pd.Timedelta(hours=2)).any()
