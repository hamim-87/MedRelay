"""Edge cases for outcome derivation: labels must follow from the event list alone."""
import json

import pandas as pd
import pytest

from src.generate_scenarios import COMPLETION_EVENT, Node, label_node

import numpy as np

T0 = pd.Timestamp("2024-01-01T09:00:00Z")
DL = T0 + pd.Timedelta(days=10)


def mk(step="lab_collected", events=(), meta=None):
    n = Node(step=step, obligation_id="sim:ob:x:0", category="laboratory_test", role="patient", created=T0, deadline=DL, meta=dict(meta or {}, pid="p", eid="e"))
    for et, dt in events:
        n.events.append(dict(event_id=f"e{len(n.events)}", patient_id="p", encounter_id="e", obligation_id=n.obligation_id, event_type=et,
                             timestamp_utc=T0 + pd.Timedelta(days=dt), evidence_source="x", status="s", verification="verified", provenance="simulated",
                             payload="{}", source_event_id=None))
    return n


def lab(node, end_days=40, grace_h=168, gap_p=0.0):
    node.meta["snapshot_gap_p"] = gap_p
    return label_node(node, T0 + pd.Timedelta(days=end_days), grace_h, np.random.default_rng(0))


def test_completed_on_time():
    assert lab(mk(events=[("lab_collected", 5)]))["outcome_label"] == "completed"


def test_completed_exactly_at_deadline_counts_as_on_time():
    assert lab(mk(events=[("lab_collected", 10)]))["outcome_label"] == "completed"


def test_late_completion_is_unresolved_at_deadline():
    o = lab(mk(events=[("lab_collected", 12)]))
    assert o["outcome_label"] == "overdue_unresolved" and o["resolved_late"]


def test_conflicting_evidence_is_unverified_not_completed():
    assert lab(mk(events=[("lab_collected", 5), ("conflicting_record", 6)]))["outcome_label"] == "unverified"


def test_open_with_tracker_snapshot_is_confirmed_overdue():
    n = mk(events=[])
    o = lab(n)
    assert o["outcome_label"] == "overdue_unresolved"
    assert any(e["event_type"] == "task_status_snapshot" for e in n.events)


def test_no_evidence_and_tracker_gap_is_unverified_never_failure():
    assert lab(mk(events=[]), gap_p=1.0)["outcome_label"] == "unverified"


def test_lost_documentation_is_unverified():
    assert lab(mk(events=[], meta={"doc_lost": True}))["outcome_label"] == "unverified"


def test_observation_ends_before_deadline_is_censored():
    assert lab(mk(events=[]), end_days=5, gap_p=0.0)["outcome_label"] == "censored_or_unknown"


def test_documented_no_show_is_overdue_without_snapshot():
    o = lab(mk(step="appointment_attended", events=[("visit_no_show", 9)]), gap_p=1.0)
    assert o["outcome_label"] == "overdue_unresolved"


def test_each_step_has_a_completion_event_type():
    from src.generate_scenarios import STEP_SPEC
    assert set(STEP_SPEC) == set(COMPLETION_EVENT)
