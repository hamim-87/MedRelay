"""The validators must actually detect the defects they claim to detect (fault injection on real pipeline outputs)."""
import copy

import numpy as np
import pandas as pd
import pytest

from src import validate
from tests.conftest import requires_outputs

pytestmark = requires_outputs


def status(cid):
    return next(r["status"] for r in validate.RES if r["id"] == cid)


@pytest.fixture(autouse=True)
def _clear():
    validate.RES.clear()
    yield
    validate.RES.clear()


def test_clean_data_passes_hard_checks(D, cfg):
    validate.check_pk(D)
    validate.check_fk(D)
    validate.check_chronology(D)
    validate.check_evidence_before_cause(D)
    validate.check_graph(D)
    assert all(r["status"] != "FAIL" for r in validate.RES), validate.RES


def test_detects_dependency_cycle(D):
    D2 = dict(D)
    E = D["edges"]
    dep = E[E.edge_type == "DEPENDS_ON"].iloc[0]
    back = dep.copy()
    back["edge_id"] = "edge:injected"
    back["src_id"], back["dst_id"] = dep.dst_id, dep.src_id
    D2["edges"] = pd.concat([E, back.to_frame().T], ignore_index=True)
    validate.check_graph(D2)
    assert status("Q07") == "FAIL"


def test_detects_invalid_edge_endpoint_types(D):
    D2 = dict(D)
    E = D["edges"].copy()
    i = E.index[E.edge_type == "ASSIGNED_TO"][0]
    E.loc[i, "dst_id"] = E.loc[i, "src_id"]            # obligation -> obligation is not a valid ASSIGNED_TO
    D2["edges"] = E
    validate.check_graph(D2)
    assert status("Q07") == "FAIL"


def test_detects_future_event_in_features(D, cfg):
    D2 = dict(D)
    risk = {k: v.copy() for k, v in D["risk"].items()}
    t = risk["train"]
    t.loc[t.index[:200], "n_events_so_far"] += 1        # pretend a future event leaked into the features
    D2["risk"] = risk
    validate.check_future_leakage(D2, cfg)
    assert status("L01") == "FAIL"


def test_detects_forbidden_column_in_model_input(D, cfg):
    D2 = dict(D)
    risk = {k: v.copy() for k, v in D["risk"].items()}
    risk["test"]["scenario_profile"] = "timely"
    D2["risk"] = risk
    validate.check_future_leakage(D2, cfg)
    assert status("L01") == "FAIL"


def test_detects_patient_in_two_splits(D):
    D2 = dict(D)
    risk = {k: v.copy() for k, v in D["risk"].items()}
    leaked = risk["train"].iloc[[0]].copy()
    risk["test"] = pd.concat([risk["test"], leaked], ignore_index=True)       # same patient, wrong split file
    D2["risk"] = risk
    validate.check_patient_independence(D2)
    assert status("L05") == "FAIL"


def test_detects_duplicate_primary_key(D):
    D2 = dict(D)
    D2["obligations"] = pd.concat([D["obligations"], D["obligations"].iloc[[0]]], ignore_index=True)
    validate.check_pk(D2)
    assert status("Q02") == "FAIL"


def test_detects_dangling_foreign_key(D):
    D2 = dict(D)
    ev = D["events"].copy()
    ev.loc[ev.index[0], "obligation_id"] = "sim:ob:does-not-exist"
    D2["events"] = ev
    validate.check_fk(D2)
    assert status("Q03") == "FAIL"


def test_detects_impossible_transition_child_before_parent(D):
    D2 = dict(D)
    O, V = D["obligations"], D["events"].copy()
    from src.generate_scenarios import COMPLETION_EVENT
    ct = O.set_index("obligation_id").step_type.map(COMPLETION_EVENT)
    V["is_c"] = V.event_type.values == ct.reindex(V.obligation_id).values
    comp = V[V.is_c].set_index("obligation_id")
    pair = next((o, p) for o, ds in zip(O.obligation_id, O.depends_on) for p in ds if o in comp.index and p in comp.index)
    child_event = V[(V.obligation_id == pair[0]) & V.is_c].index[0]
    V.loc[child_event, "timestamp_utc"] = "1900-01-01T00:00:00Z"
    D2["events"] = V
    validate.check_transitions(D2)
    assert status("Q05") == "FAIL"


def test_detects_split_label_mismatch_for_heldout(D, cfg):
    D2 = dict(D)
    P = D["patients"].copy()
    i = P.index[(P.official_split == "heldout")][0]
    P.loc[i, "split"] = "train"
    D2["patients"] = P
    D2["action"] = {k: v.copy() for k, v in D["action"].items()}
    D2["risk"] = {k: v.copy() for k, v in D["risk"].items()}
    validate.check_split_preservation(D2, cfg)
    assert status("Q13") == "FAIL"


def test_detects_hidden_fields_in_stream(D):
    D2 = dict(D)
    st = D["stream"].copy()
    st["payload"] = st["payload"].astype(object)
    st.at[st.index[0], "payload"] = "{'outcome_label': 'completed'}"
    D2["stream"] = st
    validate.check_graph_stream(D2)
    assert status("Q15") == "FAIL"
