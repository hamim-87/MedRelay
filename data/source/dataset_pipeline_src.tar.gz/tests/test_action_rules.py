import pytest

from src.action_rules import parse_due_days, propose


@pytest.mark.parametrize("text,expected", [
    ("Order a repeat CBC in 2 weeks.", "laboratory_test"),
    ("We will obtain an MRI of the brain next week.", "imaging"),
    ("Refer to cardiology for further evaluation.", "appointment_referral"),
    ("Schedule a colonoscopy next month.", "procedure"),
    ("Start lisinopril 10 mg daily.", "medication_action"),
    ("The patient will follow up in 3 months.", "followup_review"),
    ("Please call us if the pain worsens.", "patient_communication"),
])
def test_positive_directives(text, expected):
    p = propose(text, "plan")
    assert expected in p.labels, (text, p)
    assert p.tense == "directive"
    assert 0 < p.confidence <= 0.95


@pytest.mark.parametrize("text", [
    "She denies any chest pain.",                                       # negated history
    "Can you tell me what medications you take at home?",               # question
    "The MRI shows a 2 cm mass in the left lobe.",                      # result record
    "The risks of surgery include bleeding and infection.",             # risk statement
    "He has a history of hypertension.",
    "Hello, how are you today?",
])
def test_negatives_have_no_labels(text):
    assert propose(text, "narrative").labels == []
    assert propose(text, "plan").labels == []


def test_past_narrative_not_directive():
    p = propose("She was referred to cardiology last year and was started on metoprolol.", "narrative")
    assert p.labels == [] and p.tense == "historical"


def test_overlong_asr_runon_is_not_labelled():
    assert propose("so " * 200 + "order a cbc", "dialogue_doctor").labels == []


def test_spans_point_into_text():
    t = "We will order a lipid panel today."
    p = propose(t, "plan")
    a, b = p.spans["laboratory_test"]
    assert "lipid" in t[a:b]


@pytest.mark.parametrize("phrase,days", [("in 2 weeks", 14), ("within 48 hours", 2), ("in 3 months", 90), ("tomorrow", 1),
                                         ("ASAP", 0.25), ("in 1-2 weeks", 10.5), ("next week", 7), ("in one year", 365)])
def test_parse_due_days(phrase, days):
    assert parse_due_days(phrase) == pytest.approx(days)


@pytest.mark.parametrize("bad", [None, float("nan"), "", "sometime"])
def test_parse_due_days_unparseable_is_none(bad):
    assert parse_due_days(bad) is None
