"""Edge cases for the appointment no-show builder using a tiny hand-made CSV (no network, no real data)."""
import pandas as pd
import pytest

from src import build_noshow_dataset as B

ROWS = [  # PatientId, AppointmentID, Gender, ScheduledDay, AppointmentDay, Age, Neighbourhood, Scholarship, Hipertension, Diabetes, Alcoholism, Handcap, SMS_received, No-show
    (1.0, 100, "F", "2016-04-01T10:00:00Z", "2016-04-05T00:00:00Z", 30, "A", 0, 0, 0, 0, 0, 0, "Yes"),
    (1.0, 101, "F", "2016-04-06T10:00:00Z", "2016-04-10T00:00:00Z", 30, "A", 0, 0, 0, 0, 0, 1, "No"),   # prior #100 (date 04-05) is known
    (1.0, 102, "F", "2016-04-05T08:00:00Z", "2016-04-12T00:00:00Z", 30, "A", 0, 0, 0, 0, 0, 1, "No"),   # prior #100 is NOT yet known (same day as its appt)
    (2.0, 103, "M", "2016-04-08T10:00:00Z", "2016-04-05T00:00:00Z", 40, "B", 0, 0, 0, 0, 0, 0, "No"),   # appointment before scheduling -> dropped
    (3.0, 104, "M", "2016-04-01T10:00:00Z", "2016-04-01T00:00:00Z", -1, "B", 0, 0, 0, 0, 0, 0, "No"),   # negative age -> dropped
    (4.0, 105, "F", "2016-04-01T10:00:00Z", "2016-04-01T00:00:00Z", 20, "C", 1, 0, 0, 0, 2, 0, "No"),   # same-day appointment, wait 0
]


@pytest.fixture()
def out(tmp_path, cfg):
    raw = tmp_path / "raw" / "noshow"
    raw.mkdir(parents=True)
    pd.DataFrame(ROWS, columns=["PatientId", "AppointmentID", "Gender", "ScheduledDay", "AppointmentDay", "Age", "Neighbourhood", "Scholarship",
                                "Hipertension", "Diabetes", "Alcoholism", "Handcap", "SMS_received", "No-show"]).to_csv(raw / "KaggleV2-May-2016.csv", index=False)
    c = dict(cfg, paths=dict(cfg["paths"], raw=str(tmp_path / "raw"), processed=str(tmp_path / "proc")), mode="full")
    stats = B.build(c)
    return pd.read_parquet(tmp_path / "proc" / "appointment_noshow" / "all.parquet"), stats


def test_invalid_rows_dropped_and_counted(out):
    df, stats = out
    assert set(df.appointment_id) == {100, 101, 102, 105}
    assert stats["audit"]["dropped_invalid_rows"] == 2


def test_wait_days_and_same_day(out):
    df, _ = out
    r = df.set_index("appointment_id")
    assert r.at[100, "wait_days"] == 4 and r.at[105, "wait_days"] == 0 and r.at[105, "same_day"] == 1


def test_history_uses_only_earlier_appointment_dates(out):
    r = out[0].set_index("appointment_id")
    assert (r.at[101, "prior_appointments"], r.at[101, "prior_noshows"]) == (1, 1)
    assert (r.at[102, "prior_appointments"], r.at[102, "prior_noshows"]) == (0, 0)
    assert r.at[100, "prior_appointments"] == 0


def test_sms_excluded_from_features_and_ids_not_numeric_features(out):
    assert not any("sms" in f for f in B.FEATURES)
    assert "appointment_id" not in B.FEATURES and "patient_key" not in B.FEATURES


def test_patient_never_spans_splits(out):
    df, _ = out
    assert (df.groupby("patient_key").split.nunique() == 1).all()
