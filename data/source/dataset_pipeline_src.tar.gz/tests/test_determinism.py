"""Same seed + same inputs => identical derived tables (dev-mode run into two separate temp trees)."""
import copy

import pandas as pd
import pytest

from src import extract_actions, generate_scenarios, build_risk_dataset, normalize
from src.common import ROOT


def _run(cfg, tmp):
    c = copy.deepcopy(cfg)
    c["mode"] = "dev"
    c["paths"] = dict(c["paths"], interim=str(tmp / "interim"), processed=str(tmp / "processed"), reports=str(tmp / "reports"), docs=str(tmp / "docs"))
    normalize.run(c)
    extract_actions.run(c)
    generate_scenarios.run(c)
    build_risk_dataset.run(c)
    return tmp


@pytest.mark.skipif(not (ROOT / "data/raw/MANIFEST.json").exists(), reason="raw data not downloaded")
def test_pipeline_core_is_deterministic(cfg, tmp_path):
    a = _run(cfg, tmp_path / "a")
    b = _run(cfg, tmp_path / "b")
    for rel in ["interim/scenarios/obligations.parquet", "interim/scenarios/events.parquet", "interim/scenarios/ground_truth.parquet",
                "processed/followup_risk/features_train.parquet", "processed/action_classification/train.parquet"]:
        pd.testing.assert_frame_equal(pd.read_parquet(a / rel), pd.read_parquet(b / rel), check_exact=True)


@pytest.mark.skipif(not (ROOT / "data/raw/MANIFEST.json").exists(), reason="raw data not downloaded")
def test_different_seed_changes_scenarios(cfg, tmp_path):
    a = _run(cfg, tmp_path / "a")
    c2 = copy.deepcopy(cfg)
    c2["seed"] = cfg["seed"] + 1
    b = _run(c2, tmp_path / "b")
    ga = pd.read_parquet(a / "interim/scenarios/ground_truth.parquet")
    gb = pd.read_parquet(b / "interim/scenarios/ground_truth.parquet")
    assert not ga.scenario_profile.equals(gb.scenario_profile)
