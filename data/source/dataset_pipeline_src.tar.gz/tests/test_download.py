import http.server
import threading
from functools import partial

import pytest

from src.common import sha256_file
from src.download import Manifest, _fetch


@pytest.fixture()
def server(tmp_path):
    d = tmp_path / "srv"
    d.mkdir()
    (d / "a.csv").write_text("x,y\n1,2\n3,4\n")
    hits = []

    class H(http.server.SimpleHTTPRequestHandler):
        def log_message(self, *a):
            hits.append(self.path)
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), partial(H, directory=str(d)))
    t = threading.Thread(target=srv.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{srv.server_port}", hits
    srv.shutdown()


CFG = {"download": {"retries": 2, "timeout_s": 5, "backoff_s": 0.01}}


def test_download_is_idempotent_and_checksummed(server, tmp_path):
    base, hits = server
    man = Manifest(tmp_path / "m.json")
    dest = tmp_path / "raw" / "a.csv"
    meta = {"version": "t", "license": "test", "nature": "synthetic"}
    assert _fetch(man, CFG, source="t", key="t/a.csv", url=f"{base}/a.csv", dest=dest, meta=meta)
    n1 = len(hits)
    rec = man.get("t/a.csv")
    assert rec["sha256"] == sha256_file(dest) and rec["record_count"] == 2 and rec["size_bytes"] == dest.stat().st_size
    assert _fetch(man, CFG, source="t", key="t/a.csv", url=f"{base}/a.csv", dest=dest, meta=meta)
    assert len(hits) == n1            # cached: no second request


def test_corrupted_file_is_refetched(server, tmp_path):
    base, hits = server
    man = Manifest(tmp_path / "m.json")
    dest = tmp_path / "raw" / "a.csv"
    meta = {"version": "t", "license": "test", "nature": "synthetic"}
    _fetch(man, CFG, source="t", key="k", url=f"{base}/a.csv", dest=dest, meta=meta)
    dest.write_text("tampered")
    _fetch(man, CFG, source="t", key="k", url=f"{base}/a.csv", dest=dest, meta=meta)
    assert dest.read_text().startswith("x,y")


def test_failure_is_recorded_not_silenced(server, tmp_path):
    base, _ = server
    man = Manifest(tmp_path / "m.json")
    ok = _fetch(man, CFG, source="t", key="missing", url=f"{base}/nope.csv", dest=tmp_path / "raw" / "nope.csv", meta={})
    assert ok is False and man.data["failures"] and man.data["failures"][0]["url"].endswith("nope.csv")
    assert not (tmp_path / "raw" / "nope.csv").exists()
